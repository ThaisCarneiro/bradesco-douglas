# OCP - Probe Check

Esta playbook percorre todos os `Deployments`, `DeploymentConfigs`, `Daemonsets` e `Statefulsets` a procura daqueles que não possuem os "health checks" de `Liveness` e `Readiness`.

## Variáveis

Existem quatro variáveis, o usuário e senha do Openshift além de uma lista com os clusters disponíveis e uma outra variável que define qual destes clusters deverá ser utilizado.

```yml
# variaveis genaricas para usar como custom credential
openshift_user: kubeadmin
openshift_password: mEYbG-kYeZb-TgMhB-LuLo8
# enderecos de clusters disponiveis
ocp_debug_clusters:
  local: https://api.crc.testing:6443 
ocp_debug_cluster: local
```

## Exemplo

```bash
ansible-playbook -i localhost, -e @vars.yml playbook.yml 
```
