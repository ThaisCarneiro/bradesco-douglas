# Directory Verify

Esta playbook extrai os hashes md5 dos arquivos de vários hosts e os compara, exibindo os arquivos e os hosts em que estão diferentes.
Os hosts são especificados no próprio inventário.

Ao final da execução um título e corpo de email são criados para serem enviados através do workflow.

## Variáveis

- `path` - uma string, define o caminho com o coringa a ser analisado, ex `C:\deploy\*.txt`.

## Exemplos

```bash
ansible-playbook -i 192.168.122.104,192.168.122.155 \
-e ansible_connection=winrm \
-e ansible_user=Administrator \
-e ansible_password=Zaq1Xsw2 \
-e ansible_winrm_transport=ntlm \
-e ansible_port=5985 \
-e awx_job_id=1 \
-e awx_job_template_name=Teste \
-e path='C:\\deploy\\*.txt' \
-v playbook.yml
```
