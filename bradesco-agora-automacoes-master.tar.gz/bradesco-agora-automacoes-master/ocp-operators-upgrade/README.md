# OCP - Operators Upgrade

Esta playbook percorre todos os `Operators` e informa por email quais estão disponíveis para atualização.

## Variáveis

Existem quatro variáveis, o usuário e senha do Openshift além de uma lista com os clusters disponíveis e uma outra variável que define qual destes clusters deverá ser utilizado.

```yml
# variaveis genaricas para usar como custom credential
openshift_user: kubeadmin
openshift_password: mEYbG-kYeZb-TgMhB-LuLo8
# enderecos de clusters disponiveis
ocp_debug_clusters:
  local: https://api.crc.testing:6443 
ocp_debug_cluster: local
```

## Exemplo

```bash
ansible-navigator run playbook.yml --eei registry.redhat.io/ansible-automation-platform-24/ee-supported-rhel8:latest -e @vars.yml -v
```
