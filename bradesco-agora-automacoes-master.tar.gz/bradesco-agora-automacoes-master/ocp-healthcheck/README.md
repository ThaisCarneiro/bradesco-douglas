# OCP Health Check

Esta playbook foi criada baseada na **execute**, porém, sua única intenção é execute um script de verificação da saúde do Openshift.
O script `healthcheck.sh` na raíz do repositório será copiado para dentro do contêiner/máquina e executado e sua saída será enviada como anexo por email.

Existem 4 clusters a serem utilizados:

- tutihofix
- dr
- acm
- producao

## Variáveis

- `healthcheck_temp_folder` o diretório em que o arquivo a ser anexado deverá estar para ser coletado pelo próximo passo do workflow, ex: `/opt/ansiblefiles/files`.
- `healthcheck_cluster` o cluster a ser verificado, ex: `dr`.

## Exemplo

```bash
ansible-playbook -i localhost, \
  -e healthcheck_temp_folder='/opt/ansiblefiles/files' \
  -e healthcheck_cluster=dr \
  -e awx_job_id=1 \
  -e awx_job_template_name=1 \
  -v playbook.yml
```
