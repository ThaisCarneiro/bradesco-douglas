# Openshift - Certificates

Esta playbook exibe o vencimento da CA dos kubelets e uma lista de certificados ordenados pelo dia em que expirarão.

Uma explicação sobre o vencimento da CA pode ser lida em [https://access.redhat.com/articles/5651701](https://access.redhat.com/articles/5651701).

## Variáveis

Existem algumas variáveis, a maioria é autoexplicativa. A variável `ocp_must_gather_clusters` contém uma lista de clusters disponíveis e o cluster a ser utilizado é definido na variável `ocp_must_gather_cluster`.

```yaml
ocp_must_gather_clusters:
  local: https://api.crc.testing:6443
ocp_must_gather_cluster: local
ocp_must_gather_user: kubeadmin
ocp_must_gather_password: mEYbG-kYeZb-TgMhB-LuLo8
```

## Exemplo

```bash
ansible-playbook \
  -i localhost, \
  -e @vars.yml \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v playbook.yml
```
