# Restart Autra

Esta playbook verifica se existem arquivos com mais do que 5 minutos em uma determinada pasta, caso existam o processo `Autra Servidor` é parado e iniciado.
Este processo não é um serviço, é um binário comum, para que o processo continue rodando após o Ansible iniciá-lo foi preciso utilizar `async` e `pool` no módulo.

## Variáveis

- `restart_astra_exe`, uma string, o caminho do executável, exemplo: `D:\Autra Servidor\Autra Servidor.exe`;
- `restart_astra_dir`, uma string, o diretório dos arquivos, exemplo: `\\mz-vv-fs-065.corp.bradesco.com.br\USUARIO\SYSTER_C\Attivo\trans\SAIDA`;
- `restart_astra_max_time`, um inteiro, o tempo em segundos a ser considerado um arquivo antigo, exemplo: `300`.

## Exemplo


```bash
ansible-playbook -i 192.168.122.104, \
-e ansible_connection=winrm \
-e ansible_user=Administrator \
-e ansible_password=Zaq1Xsw2 \
-e ansible_winrm_transport=ntlm \
-e ansible_port=5985 \
-e restart_astra_exe='C:\\windows\\system32\\notepad.exe' \
-e restart_astra_dir='C:\dir1' \
-v playbook.yml
```
