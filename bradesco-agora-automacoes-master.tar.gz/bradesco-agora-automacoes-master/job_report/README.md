# Job Report

Esta playbook recebe uma lista com os nomes dos templates do AAP para serem analisados em um relatório em formato de tabela enviado por email.
Os jobs considerados são sempre os últimos executados mas com `status` diferente de `running`.

## Variáveis

```yml
job_report_names:
- iis-restart
- dns
```

## Exemplo

```bash
ansible-playbook -i localhost, \
  -e aap_username=admin \
  -e aap_password=redhat \
  -e '{"job_report_names" : ["iis-restart", "dns"]}' \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v playbook.yml
```
