# Network Execute

Esta playbook executa uma serie de comandos em equipamentos de rede.
Diferente das playbooks convencionais, esta playbook não utiliza o `hosts` para se conectar a estes dispositivos e sim um loop e um `ansible.builtin.shell` para executar os comandos a partir de `localhost`.

Ao final das execuções um corpo de email é gerado para ser enviado na próxima tarefa do workflow.

Os equipamentos e comandos são consultados em um arquivo de variáveis com o seguinte formato e de nome padrão `vars.yml`:

```yaml
equipments:
- host: equip1
  ip: 192.168.122.100
  commands:
  - hostname
- host: equip2
  ip: 192.168.122.101
  commands:
  - ip neigh
  - hostname
  - df -h
- host: equip3
  ip: 192.168.122.102
  commands:
  - hostname
```

**Atenção:** Os comandos são todos executados entre 'aspas simples', sendo assim, caso queira utilizar aspas no comando, utilize "aspas duplas".

## Exemplo

O exemplo utiliza o parâmetro `-k` ou `--ask-pass` pois está será a senha dos equipamentos.

```bash
ansible-playbook -i localhost, -e awx_job_id=1 -e awx_job_template_name=Teste playbook.yml -v -k
```
