# Win Compress Logs

Esta playbook compacta **apenas** os arquivos de um diretório e grava o arquivo compactado em um destino específico. Ela nunca compactará o diretório especificado, tão pouco seus subdiretórios, apenas seus arquivos no primeiro level.

Para comprimir apenas os arquivos presentes no momento da execução da playbook e evitar arquivos novas, ou arquivos pela metade, uma lista dos arquivos existentes é criada e a compactação atua com base nesta lita.
Por conta de limitações no tamanho máximo de um parâmetro do Powershell, a compactação é feita de 100 em 100 items.

## Variáveis

- `win_compress_folder_glob`, uma string, o diretório com os arquivos a serem compactados, exemplo: `C:\logs\*`, `C:\logs`.
  - Caso apenas o caminho do diretório seja informado, o `powershell` compactará todos os arquivos do diretório, mas não o diretório em si;
  - Caso um exista um asterisco ou um padrão com `*.txt` no final do caminho do diretório, o `powershell` compactará os arquivos correspondentes dentro do diretório.
- `win_compress_filename_prefix`, uma string, um prefixo para o nome do arquivo, exemplo: `logs-`.
  - O nome final do arquivo será `<prefixo>yyyymmdd.zip`, exemplo: `logs-20230101.zip`.
- `win_compress_destination`, uma string, o diretório de destino do arquivo compactado, pode ser o mesmo diretório informado acima, ex: `C:\logs`.

## Exemplos

```bash
ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=123 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e win_compress_folder_glob='C:\\logs\\*' \
  -e win_compress_filename_prefix=logs \
  -e win_compress_destination='C:\\logs' \
  -v playbook.yml
```

> Lembre-se de escapar o caractere `\` nas variáveis utilzando duas barras invertidas.
