# OCP - Debug Pods

Esta playbook percorre todos os pods do cluster e expõe todos os pods que tenham uma variável `loglevel` com valor `debug` ou com a palavra "debug" nos logs. Essa verificação acontece dentro do pod com `env | grep LOGLEVEL=DEBUG` ao invés da verificação mais simples apenas do `Deployment`. Está desta forma pois os desenolvedores colocaram a variável dentro do `Containerfile` da imagem.

## Dependências

Esta playbook depende da collection `community.general.json_query`.

## Variáveis

Existem quatro variáveis, o usuário e senha do Openshift além de uma lista com os clusters disponíveis e uma outra variável que define qual destes clusters deverá ser utilizado.

```yml
# variaveis genaricas para usar como custom credential
openshift_user: kubeadmin
openshift_password: mEYbG-kYeZb-TgMhB-LuLo8
# enderecos de clusters disponiveis
ocp_debug_clusters:
  local: https://api.crc.testing:6443 
ocp_debug_cluster: local
```

## Exemplo

```bash
ansible-navigator run playbook.yml -e @vars.yml -v --eei localhost/ee-supported-community
```
