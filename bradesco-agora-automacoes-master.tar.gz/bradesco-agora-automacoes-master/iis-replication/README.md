# IIS Replication

Esta playbook executa dois comandos para copiar os arquivos e as configurações de IIS entre servidores Windows:

```
robocopy C:\site \\SERVIDORDESTINO\site /MIR /COPYALL

msdeploy.exe -verb:sync -source:appHostConfig,computername=SERVIDORATUAL -dest:appHostConfig,computername=SERVIDORDESTINO -disablelink:ContentExtension -enableLink:AppPoolExtension
```

Ambos comandos são executados em forma de loop, o `robocopy` recebe uma lista de origem/destino enquanto que o `msdeploy` recebe uma lista de servidores que receberão a cópia das configurações do IIS.

## Variáveis

Existem três variáveis:

- `iis_replication_msdeploy_path`, uma string, o diretório onde está o `msdeploy.exe`, exemplo: `C:\Program Files\IIS\Microsoft Web Deploy V3`;
- `iis_replication_paths`, uma lista de dicionários com `src` e `dest`. Esta variável indica os vários diretórios diferentes que serão copiados da máquina origem para a máquina destino, exemplo: `[{"src" : "C:\site", "dest" : "\\WINDOWS2\site"]}`;
- `iis_replication_hosts`, uma lista de servires para receberem as configurações do IIS, exemplo: `["WINDOWS2"]`.

### robocopy

```
/MIR mirror (equivalente a /E junto com /PURGE)
/NP no progress
/NDL no directory list
/R number of retries
/W wait time between retries
/COPYALL copy all file info
```

```bash
ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=123 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -v playbook.yml
```
