# Azure DevOps

Esta playbook atualiza o valor de duas variáveis presentes no Azure Devops - (Pipelines, Library, Variable Groups, AG_PRD) - `OC_TOKEN_DR_48` e `OC_TOKEN_PRD_48`.
Estas variáveis armazenam os tokens de acesso aos clusters de Openshift de uma conta de usuário. Uma conta de usuário é utilizada, ao invés de uma conta de serviço, justamente para se aproveitar do tempo de vida limitado deste token.

Para obter os tokens de acesso ao Openshift, a playbook utiliza-se do usuário e senha fornecidos pelo executor para se logar em cada cluster (dr e prd) e guarda o resultado do comando `oc whoami -t`. 

**Atenção:** Para atualizar uma única variável é necessário enviar todas as variáveis já definidas no `Variable Groups` juntamente com as modificações, pois a atualização de uma única parte do objeto não é possível.

## Variáveis

Existem muitas variáveis nesta playbook, todas elas, com exceção de duas, devem ser definidas:

- `azure_devops_ocp_user`, uma string, o usuário que se conecta ao Openshift, ex: `kubeadmin`;
- `azure_devops_ocp_password`, uma string, a senha do usuário que se conecta ao Openshift, ex: `mEYbG-kYeZb-TgMhB-LuLo8`;
- `azure_devops_ocp_oauth_dr_url`, uma string, o endereço de autenticação do openshift de dr, ex: `https://oauth-openshift.apps-crc.testing`;
- `azure_devops_ocp_oauth_prd_url`, uma string, o endereçco de autenticação do openshift de prd, ex `https://oauth-openshift.apps-crc.testing`;
- `azure_devops_user`, uma string, o usuário do Azure Devops, ex: `Administrator`;
- `azure_devops_token`, uma string, o **Personal Access Token** do usuário da Azure Devops, ex: `ueha33kqm7r5wqzmylpd4et37nhwhjxgox4fan3xusoskmqz26ea`;
- `azure_devops_organization`, uma string, a organização do Azure Devops, ex: `DefaultCollection`;
- `azure_devops_project`, uma string, o projeto do Azure Devops, ex: `Redhat`;
- `azure_devops_groupname`, uma string, o grupo de variáveis do Azure Devops, ex: `AG_PRD`;
- `azure_devops_url`, uma string, o endereço do Azure Devops, ex: `http://192.168.122.103:80`;

```bash
ansible-playbook -i localhost, playbook.yml
```
