# Execution Environment

Os execution environments das bases de dados contém as `collections` necessárias para executar operações em bancos de dados remotamente. Ao utilizar `localhost` e evitar a conexão com as máquinas dos bancos, podemos utilizar de collections que dependam de módulos do python como `psycopg2` pois estes módulos estão instalados dentro do contêiner.

Este repositório trabalha com as imagens base do AAP, sendo assim temos duas categorias de `execution environment`:

- `minimal` representa as imagens `minimal` do AAP, possui apenas as collectons `ansible.builtin`.
- `supported` representa as imagens `supported` do AAP, possui todas as collections suportadas pela Red Hat.

Cada containerfile executa a construção em `multi stage build`, ou seja, todos os artefatos utilizados para instalação e compilação dos módulos python são descartados no processo final. É possível detectar uma construção deste tipo com a presença de duas ou mais cláusulas `FROM`.

## Construir um EE

Existem várias formas de construir um EE:

- `podman commit` - *[Não recomendado]* em um contêiner que está rodando para transformá-lo em imagem;
- `podman build` - *[Recomendado]* para construir uma imagem baseada em um `Containerfile`;
- `ansible-builder` - *[Recomendado]* para construir uma imagem baseada em um arquivo chamado `execution-environment.yml`;

> *[Não recomendado]* indica um EE criado por um método não reproduzível.

Neste repositório os `Containerfiles` possuem três variáveis que podem ser utilizadas durante a etapa de `build` para modificar a imagem final:

- `EE_TYPE` define o tipo de imagem base a ser utilizado, `minimal` ou `supported`.
- `AAP_VERSION` define a versão do AAP, por exemplo: `22`, `23`, `24`.
- `PYTHON_VERSION` define a versão do python, por exemplo: `38`, `39`, `3.11`.

### podman build

A construição de um EE através de `podman build` é o mesmo processo para construir uma imagem qualquer, a diferença está na imagem base indicada pela diretiva `FROM` que, para evitar muitas customizações, baseamos quase sempre nas imagens da própria Red Hat:

- `registry.redhat.io/ansible-automation-platform-23/ee-minimal-rhel8:latest` - não possuem outras collections além de `ansible.builtin`.
- `registry.redhat.io/ansible-automation-platform-23/ee-supported-rhel8:latest` - possui as collections suportadas pela Red Hat.

Note que as versões da imagem são baseadas nas versões do AAP, `ansible-automation-platform-23` representam as imagens da versão `23` assim como `ansible-automation-platform-24` representam as imagens da versão `24`. É possível utilizar imagens de versões diferentes no mesmo AAP mas não há garantia de compatibilidade. 

Tudo o que precisamos fazer é instruir o podman a construir a imagem com base em um arquivo `Containerfile` ou `Dockerfile`, pois são a mesma coisa.

Para facilitar a leitura e o exemplo, o nome da imagem já terá em si o endereço do registry, que será atribuido a uma variáel. Neste exemplo o registry é o próprio Private Hub e vamos utilizar o endereço IP **192.168.122.101** para referência:

```bash
REGISTRY=192.168.122.101
podman build -f Containerfile.minimal -t $REGISTRY/ee-minimal-db
```

Agora basta fazer o upload da imagem para um registry.

#### Build arguments

É possível utilizar-se de parâmetros para modificar a imagem final dependendo da forma como o `Containerfile` foi desenvolvido. Neste repositório existem três variáveis que podem ser informadas pelo parâmetro `--build-arg`:

```bash
podman build -t ee-minimal-db \
--build-arg EE_TYPE=supported \
--build-arg AAP_VERSION=24 \
--build-arg PYTHON_VERSION=3.11 \
-f Containerfile .
```

Neste caso estamos trocando a versão do EE para **suported**, a versão do AAP para **24** e a versão do python para **3.11**, gerando uma imagem diferente da que seria gerada sem parâmetro algum.

#### Multi-stage Build

Um multi-stage build pode ser utilizado quando há necessidade de compilar algum pacote dentro da imagem, através desse técnica podemos descartar todos os objetos necessários para a compilação e manter na imagem final apenas os objetos compilados.

Notamos a presença de um multi-stage build quando existem mais de duas cláusulas `FROM` dentro de um `Containerfile`, a última específicação após o `FROM` é aquela que formará a imagem final. Veja no exemplo abaixo que a cláusula `COPY` utiliza um parâmetro `--from=0` que faz referência ao `FROM` anterior, desta forma, copiando tudo o que foi gerado no diretório `/usr/local/lib64/python3.9` da camada da imagem anterior para o mesmo diretório na camada atual.

```dockerfile
FROM registry.redhat.io/ansible-automation-platform-23/ee-minimal-rhel8:latest

RUN microdnf install libpq-devel python39-devel gcc
RUN pip3.9 install psycopg2

FROM registry.redhat.io/ansible-automation-platform-23/ee-minimal-rhel8:latest

RUN microdnf install libpq && microdnf clean all

COPY --from=0 /usr/local/lib64/python3.9 /usr/local/lib64/python3.9
```

## Publicar um EE

Tudo o que precisamos fazer é enviar a imagem para algum registry que, no caso do AAP, normalmente é o **Private Automation Hub**.

Para facilitar a leitura e o exemplo, o nome da imagem já está no formato ideal para upload, e neste exemplo o endereço do Private Hub é **192.168.122.101**:

```bash
REGISTRY=192.168.122.101
podman login -u admin $REGISTRY
# faça o login
podman push $REGISTRY/ee-minimal-db
```

Nos casos em que a imagem não tenha o nome do registry de destino, é possível executar o `push` com dois parâmetros, o nome atual da imagem e o novo nome:

```bash
podman push localhost/ee-minimal-db 192.168.122.101/ee-minimal-db # private hub
podman push localhost/ee-minimal-db 192.168.122.200/user/ee-minimal-db # quay, openshift, etc
```

Feito isso, basta acessar o AAP e adicionar este novo EE na lista.
