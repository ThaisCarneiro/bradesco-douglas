Database
========

Este `Containerfile` instala as dependências do python para que o Ansible possa executar comandos remotamente em alguns bancos de dados utilizando os módulos da comunidade.

Atualmente os bancos suportados são:

- PostgreSQL
- MySQL

Build
-----

Durante a construção da imagem, certifique-se de utilizar as versões corretas para o AAP em questão e a versão do python utilizada pelo ansible. Para ter certeza da versão do python utilizada pelo ansible, execute a playbook com modo `More Verbose` no AAP ou `-vv` na linha de comando.

```bash
podman build -t ee-minimal-db \
--build-arg EE_TYPE=minimal \
--build-arg AAP_VERSION=23 \
--build-arg PYTHON_VERSION=39 \
-f Containerfile .
```
