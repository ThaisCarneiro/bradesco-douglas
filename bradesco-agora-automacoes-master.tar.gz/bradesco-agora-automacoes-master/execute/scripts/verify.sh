#!/bin/bash

free -h
df -h
