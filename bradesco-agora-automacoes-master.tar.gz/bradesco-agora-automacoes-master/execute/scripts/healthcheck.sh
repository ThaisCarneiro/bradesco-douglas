#!/bin/bash +x

####################################
### VERSION 0.8.0 - Para Ansible ###
####################################

clusterversion() {
    echo -e "\n\n#### OCP - Cluster Version ####\n"
    oc get clusterversion
}

etcd_tests () {

    echo -e "\n\n#### ETCD - HEALTH ####\n"
    oc rsh -n openshift-etcd  etcd-$(oc get pods -n openshift-etcd -l app=etcd -o=jsonpath='{.items[0].spec.nodeName}') etcdctl endpoint health --cluster

    echo -e "\n\n#### ETCD - MEMBER LIST ####\n"
    oc rsh -n openshift-etcd  etcd-$(oc get pods -n openshift-etcd -l app=etcd -o=jsonpath='{.items[0].spec.nodeName}') etcdctl member list -w table

    echo -e "\n\n#### ETCD - ENDPOINT STATUS ####\n"
    oc rsh -n openshift-etcd  etcd-$(oc get pods -n openshift-etcd -l app=etcd -o=jsonpath='{.items[0].spec.nodeName}') etcdctl endpoint status  -w table

}

node_tests () {
    echo -e "\n\n#### NODES - Não disponiveis ####\n"
    oc get nodes --no-headers | egrep  'Sch|Not'

    echo -e "\n\n#### NODES - TOP 10 CPU% USE ####\n"
    oc adm top nodes --use-protocol-buffers | head -n1
    oc adm top nodes --use-protocol-buffers | sort -k3 -hr | head -n 11

    echo -e "\n\n#### NODES - TOP 10 MEM% USE ####\n"
    oc adm top nodes --use-protocol-buffers | head -n1
    oc adm top nodes --use-protocol-buffers | sort -k5 -hr | head -n 11

    echo -e "\n\n#### MACHINE CONFIG POOL ####\n"
    oc get mcp
}

pod_tests () {
    echo -e "\n\n#### PODS - DIFFERENT OF RUNNING | COMPLETED ####\n"
    oc get pods -A | grep -viE 'Runn|Comp'

    echo -e "\n\n#### PODS - MORE TIMES RESTARTED ####\n"
    oc get pods -A | sort  -hr -k5 | head -n 11
}


other_tests () {
    echo -e "\n\n#### EVENTS - DIFFERENT OF NORMAL ####\n"
    oc get events -A --field-selector type!=Normal --sort-by='lastTimestamp'

    echo -e "\n\n#### CLUSTRER OPERATORS - DEGRADED ####\n"
    oc get co -o json | jq -r '.items[] | select((.status.conditions[] | select(.type == "Degraded")).status == "True") | .metadata.name'

    echo -e "\n\n#### PV - DIFFERENT BOUND ####\n"
    oc get pv -A --no-headers | grep -iv 'Bound'

    echo -e "\n\n#### PVC - DIFFERENT BOUND ####\n"
    oc get pvc -A --no-headers| grep -v 'Bound'

    echo -e "\n\n#### FLUENTD - PODS ####\n"
    oc get pods -n openshift-logging | grep collector | grep -v Running

    echo -e "\n\n#### LOGGING - DISK USED SPACE ####\n"
    for i in $(oc get pods -n openshift-logging --no-headers | awk '/-cdm-/ {print $1}'); do
        echo "# $i #" && oc rsh -c elasticsearch -n openshift-logging $i df -h | awk '/persistent/ {print "Used:", $5}'
    done

    echo -e "\n\n#### MONITORING - DISK USED SPACE ####\n"
    for i in $(oc get pods -n openshift-monitoring --no-headers | awk '/prometheus-k8s/ {print $1}'); do
        echo "# $i #" && oc rsh -n openshift-monitoring $i df -h | awk '/\ \/prometheus/ {print "Used:", $5}'
    done
}

oc login --token='{{ openshift_token }}' --insecure-skip-tls-verify=true '{{ openshift_host }}:6443' > /dev/null

clusterversion
etcd_tests
node_tests
pod_tests
other_tests
