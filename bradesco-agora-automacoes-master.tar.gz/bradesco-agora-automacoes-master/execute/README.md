# Execute

Esta playbook executa um comando ou um script qualquer em uma quantidade arbitrária de máquinas e envia a saída por email.
Caso o script seja definido, o comando será ignorado.

## Variáveis

- `execute_command` o comando a ser executado, ex: `ls /`, caso `execute_script` seja definido, esta variável será ignorada.
- `execute_script` o script a ser executado, tem precedência sobre o parâmetro `execute_command`. O script precisa iniciar com o "shebang", ex: `#!/bin/bash`, `#!/usr/bin/perl`.
- `execute_output_mode` recebe dois valores, `body` deixa o resultado do comando no corpo do email, `attachment` anexa o resultado em um arquivo.
- `execute_temp_folder` o diretório em que o arquivo a ser anexado deverá estar para ser coletado pelo próximo passo do workflow, ex: `/opt/ansiblefiles/files`.

## Exemplo

```bash
ansible-playbook -i localhost, \
  -e execute_command='df -h' \
  -e execute_output_mode=body \
  -e execute_temp_folder='/opt/ansiblefiles/files' \
  -e awx_job_id=1 \
  -e awx_job_template_name=1 \
  -v linux.yml
```
