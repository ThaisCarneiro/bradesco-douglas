# As perguntas são realizadas ao contrário do que se espera.
# Lê-se: se CMD1 == CMD2, faça nada, caso contrário exiba o erro.

CMD1=`awk '!/^#|\snfs\s|\scifs\s/ {print $2 " " $3}' /etc/fstab | sort`
CMD2=`lsblk -o MOUNTPOINT,FSTYPE | awk '!/FSTYPE|^\s*$/' | tr -s ' ' | sort`
[ "$CMD1" == "$CMD2" ] || (echo 'Os pontos de montagem atuais possuem sistemas de arquivos diferentes dos de /etc/fstab'; false)

CMD1=`mount | awk '/^\/dev/ {print $3}' | sort`
CMD2=`awk '!/^#|^\s*$/ {print $2}' /etc/fstab | sort`
[ "$CMD1" == "$CMD2" ] || (echo 'Dispositivos montados não presentes em /etc/fstab'; false)

CMD1=`mount | awk '/\snfs[0-9]?\s|\scifs\s/ {print $3}' | sort`
CMD2=`awk '/\snfs[0-9]?\s|\scifs\s/ {print $2}' /etc/fstab | sort`
[ "$CMD1" == "$CMD2" ] || (echo 'NFS/CIFS montados mas não presentes em /etc/fstab'; false)

while read LINE; do
    mount | grep -E "\s$LINE\s" > /dev/null
    if [ "$?" -ne 0 ]; then
        echo "A entrada $LINE em /etc/fstab não está montada"
        MOUNT_NOT_FOUND=1
        break
    fi
done <<< `awk '!/^#|^\s*$|\/proc|\/sys|\sswap\s/ {print $2}' /etc/fstab`
[ "$MOUNT_NOT_FOUND" != '1' ]

CMD1=`ip route | awk '/via/ {print $1 " " $3}' | grep -v default | sort`
CMD2=`sed -n 's/route[0-9]*=//p' /etc/NetworkManager/system-connections/*.nmconnection | sed 's/,/ /g' | sort`
[ "$CMD1" == "$CMD2" ] || (echo 'Há diferenças entre as rotas fixas e as rotas em memória'; false)
