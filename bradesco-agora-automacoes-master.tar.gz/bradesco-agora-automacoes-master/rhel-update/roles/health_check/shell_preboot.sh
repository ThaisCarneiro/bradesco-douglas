CMD1=`awk '!/^#|\snfs\s|\scifs\s/ {print $2 " " $3}' /etc/fstab | sort`
CMD2=`lsblk -o MOUNTPOINT,FSTYPE | awk '!/FSTYPE|^\s*$/' | tr -s ' ' | sort`
[ "$CMD1" != "$CMD2" ] && echo 'Os pontos de montagem atuais possuem sistemas de arquivos diferentes dos de /etc/fstab'

CMD1=`mount | awk '/^\/dev/ {print $3}' | sort`
CMD2=`awk '!/^#|^\s*$/ {print $2}' /etc/fstab | sort`
[ "$CMD1" != "$CMD2" ] && echo 'Dispositivos montados não presentes em /etc/fstab'

CMD1=`mount | awk '/\snfs[0-9]?\s|\scifs\s/ {print $3}' | sort`
CMD2=`awk '/\snfs[0-9]?\s|\scifs\s/ {print $2}' /etc/fstab | sort`
[ "$CMD1" != "$CMD2" ] && echo 'NFS/CIFS montados mas não presentes em /etc/fstab'

awk '!/^#|^\s*$|\/proc|\/sys|\sswap\s/ {print $2}' /etc/fstab | while read LINE; do
mount | grep -E "\s$LINE\s"
[ "$?" != 0 ] && echo "A entrada $LINE em /etc/fstab não está montada"
done
