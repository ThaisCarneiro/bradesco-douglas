# As perguntas são realizadas ao contrário do que se espera.
# Lê-se: se espaço em / for maior ou igual que 2000 faça nada, caso contrário exiba o erro.

CMD=`df --output=avail / | tail -n1`
[ "$CMD" -ge 2000000 ] || (echo 'O / precisa ter ao menos 2GB livres'; false)

CMD=`df --output=avail /boot | tail -n1`
[ "$CMD" -ge 50000 ] || (echo 'O /boot precisa ter ao menos 50MB livres'; false)

CMD=`df --output=avail /var | tail -n1`
[ "$CMD" -ge 2000000 ] || (echo 'O /var precisa ter ao menos 2GB livres'; false)

CMD=`df --output=avail /tmp | tail -n1`
[ "$CMD" -ge 2000000 ] || (echo 'O /tmp precisa ter ao menos 2GB livres'; false)

CMD=`df --output=avail /opt | tail -n1`
[ "$CMD" -ge 6000000 ] || (echo 'O /opt precisa ter ao menos 6GB livres'; false)

CMD=`grep -i 'permitrootlogin yes' /etc/ssh/sshd_config`
[ "$CMD" == '' ] || (echo 'O usuário root não deve se logar com senha, modifique /etc/ssh/sshd_config'; false)

lscpu | grep Hypervisor | awk '{print $3}' | grep -Ei 'kvm|vmware' > /dev/null
[ "$?" -eq 0 ] || (echo 'O servidor deve ser uma máquina virtual'; false)

# Verifica se determinados pacotes estão instalados
rpm -qa > /tmp/rpm-qa
while read PACKAGE; do
    grep -i $PACKAGE /tmp/rpm-qa > /dev/null
    if [ "$?" -eq 0 ]; then
        echo "O $PACKAGE não deve estar instalado"
        PACKAGE_FOUND=1
        break
    fi
done <<EOF
cluster-glue
corosync
fence-agents
gpfs.base
lucci
mysql-server
oracle-database
pacemaker
resource-agents
rgmanager
ricci
VRTSvxfs
EOF
rm -f /tmp/rpm-qa
[ "$PACKAGE_FOUND" != '1' ]
