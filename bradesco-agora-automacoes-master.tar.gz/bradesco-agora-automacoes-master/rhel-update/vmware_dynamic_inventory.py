#!/usr/bin/env python

'''
Create a customized dynamic inventory from multiple VMware Vcenters
'''

import argparse
import json
import yaml

from pyVim import connect
from pyVmomi import vim

VCENTER_DATA_PATH = '/home/daniel/safe/vcenters.yml'
DYNAMIC_INV_PATH = 'vmware_dynamic_inventory.ini'


class ParseUtils:

    @staticmethod
    def parse_vms_data_hostvars(vms, vcenter):
        # Iterate over VMs and print some information
        hostvars = {}

        for virtual_machine in vms:
            data = {}
            for nic in virtual_machine.guest.net:
                if len(nic.ipAddress) > 0:
                    data['ansible_host'] = nic.ipAddress[0]
                    break

            hostvars[virtual_machine.name] = {}
            data['Name'] = virtual_machine.name
            data['Guest_Full_Name'] = virtual_machine.summary.config.guestFullName
            data['VCenter'] = vcenter
            data['Power_State'] = virtual_machine.runtime.powerState
            data['Memory_Size'] = virtual_machine.config.hardware.memoryMB
            data['CPU'] = virtual_machine.config.hardware.numCPU
            data['CPU_Hot_Add_Enabled'] = virtual_machine.config.cpuHotAddEnabled
            data['CPU_Hot_Remove_Enabled'] = virtual_machine.config.cpuHotRemoveEnabled
            data['CPU_Hot_Memory_Enabled'] = virtual_machine.config.memoryHotAddEnabled
            data['Template'] = virtual_machine.config.template
            hostvars[virtual_machine.name] = data

        return hostvars

    @staticmethod
    def get_vm_name_list(vms):
        return [vm.name for vm in vms]


class VMWareConnection():
    def __init__(self, endpoint, user, passwd) -> None:
        self.endpoint = endpoint
        self.user = user
        self.passwd = passwd
        self.connection = None

    def __enter__(self):
        self.connection = connect.SmartConnect(
            host=self.endpoint, user=self.user,
            pwd=self.passwd, disableSslCertValidation=True)
        return self.connection

    def __exit__(self, type_, value_, traceback_):
        connect.Disconnect(self.connection)


class VMwareInventory():

    def __init__(self, vmware_connection):
        self.all_hosts = {}
        self.inventory = {}

        self.vmware_connection = vmware_connection

        if args.list:  # --list
            self.inventory = self.construct_inventory()
        elif args.host:
            self.inventory = self.empty_inventory()
        else:
            self.inventory = self.empty_inventory()

    def construct_inventory(self):

        with self.vmware_connection as conn:
            vm_view = conn.content.viewManager.CreateContainerView(
                conn.content.rootFolder, [vim.VirtualMachine], True)
            vms = vm_view.view

            hostvars = ParseUtils.parse_vms_data_hostvars(
                vms, self.vmware_connection.endpoint)
            host_list = ParseUtils.get_vm_name_list(vms)

        return {
            'all': host_list,
            '_meta': {
                'hostvars': hostvars
            }
        }

    # Empty inventory for testing.
    def empty_inventory(self):
        return {'_meta': {'hostvars': {}}}


def main():

    vcenters = get_vcenters_data(VCENTER_DATA_PATH)
    inventories = get_all_inventories(vcenters)
    concatenated_invs = concatenate_inventory(inventories)

    if args.ini:
        create_ini_file(concatenated_invs)

    # Return an ansible-inventory in print style
    print(json.dumps(concatenated_invs))


def get_vcenters_data(path):
    with open(path, 'r', encoding="utf-8") as file_:
        return yaml.safe_load(file_)


def get_all_inventories(vcenters: dict):

    inventories = []
    for vcenter, auth in vcenters['vcenters'].items():
        inventory = VMwareInventory(
            VMWareConnection(vcenter, auth['user'], auth['passwd'])).inventory
        inventories.append(inventory)

    return inventories


def concatenate_inventory(concatenated_invs):
    host_list = []
    hostvars = {}

    for inventory in concatenated_invs:
        host_list.extend(inventory['all'])
        hostvars.update(inventory['_meta']['hostvars'])

    return {
        'all': host_list,
        '_meta': {
            'hostvars': hostvars
        }
    }


def create_ini_file(concatenated_invs):

    with open(DYNAMIC_INV_PATH, 'w', encoding="utf-8") as file_:
        file_.write('[all]\n')

        for host in concatenated_invs['all']:
            file_.write(f"{host} ")

            host_data = concatenated_invs['_meta']['hostvars'][host]
            for key, value in host_data.items():
                file_.write(f"{key}='{value}' ")
            file_.write("\n")


def read_cli_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--ini', action='store_true')
    parser.add_argument('--host', action='store')
    return parser.parse_args()


if __name__ == "__main__":
    args = read_cli_args()
    main()
