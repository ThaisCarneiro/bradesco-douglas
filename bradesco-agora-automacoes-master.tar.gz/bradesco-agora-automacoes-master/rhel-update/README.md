# RHEL Update Inplace

Essa playbook atualiza o RHEL entre *major* versions através do LEAPP.

Atente-se às versoẽs suportadas, por exemplo:

| System    | Version  | End of support     |
|-----------|----------|--------------------|
| RHEL 8.8  | RHEL 9.2 | May 31, 2025 (EUS) |
| RHEL 8.10 | RHEL 9.4 | May 31, 2026       |
<style>
.my_div {text-align: center;}
tr:nth-child(even) {
  background-color: #f4f4f4!important;
  color: black!important;
}
</style>
<div class="my_div">
<h3><img align="left" width="55px" src="https://assets.b9.com.br/wp-content/uploads/2018/11/Bradesco-novo-logo1-1280x677.jpg" />Upgrade Inplace Red Hat 6 to Red Hat 7 (Em Desenvolvimento)
<img align="right" width="55px" src="https://s7d1.scene7.com/is/image/kyndryl/kyndryl-logo?ts=1649177108645&$SVG-Transparency$&dpr=off" />
</h3>
</div>

___

- [1. Descrição](#1-descrição)
- [2. Pré Requisitos](#2-pré-requisitos)
- [3. Casos de Uso](#3-casos-de-uso)
- [4. Variáveis de Dados dos Vcenters](#4-variáveis-de-dados-dos-vcenters)
- [5. Inventário Dinâmico](#5-inventário-dinâmico)
  - [5.1. Aplicado diretamente no ansible.cfg](#51-aplicado-diretamente-no-ansiblecfg)
  - [5.2. Aplicado em máquina remota e pegar output](#52-aplicado-em-máquina-remota-e-pegar-output)
- [6. Variáveis](#6-variáveis)
- [7. Execução](#7-execução)


___

## 1. Descrição

Este playbook é capaz de suportar upgrade in place de Red Hat versão 6 para versão 7 com algumas costumizações como criação de snapshots, backup de arquivos importante e validações.

Esta versão foi refatorada de uma versão existente adicionando capacidades para torná-los mais abrangemente, como inclusão de segurança para credencias, inventário dinâmico para múltiplos VCenters, organização de variáveis para poder ser executado por ambientes com diferentes pré requisitos.

Essa versão foi criada a pedido para ser executado localmente, em caso, de futura necessidade de ser executada a partir do Tower, então deverá ser criado um Execution Environment com Ansible 2.9, além de outros pré requisitos definidos no arquivo de requirements.txt e requirements.yml.

## 2. Pré Requisitos

- Inventário
- PyVmomi para Inventário Dinâmico
- Pacotes básicos Ansible defiinidos em requirements.txt
- community.vmware (collection para execução de módulos)
- Arquivo (preferencialmente) encriptado com informação de credencias dos Vcenters
  - Ver template vars/vcenter_unprotected.yml
- Os seguintes arquivos devem existir no seguinte diretório roles/upgrade/files
  - cfg2html-6.43.2.20.gd437b3b-1.git202302181252.noarch.rpm
  - rhel-server-7.9-x86_64-dvd.iso

## 3. Casos de Uso

- [ ] Inventário Dinâmico
- [ ] Health Check
- [ ] Pre update de pacotes
- [ ] Validação de Release
- [ ] Snapshots
- [ ] Upgrade
- [ ] Pos Operacoes
- [ ] Pos Update de Pacotes
- [ ] Validacao de Conectividade

## 4. Variáveis de Dados dos Vcenters

As informações de Vcenter devem ser construídas no seguinte modelo.
Trocando vcenter_a e vcenter_b por nomes reais, assim como user and pass.

```yaml
---
vcenters:
  vcenter_a:
    user: user
    passwd: pass

  vcenter_b:
    user: user
    passwd: pass
```

## 5. Inventário Dinâmico

Dependência Python3 e PyVmomi
Alterar no arquivo Python o local de onde se encontra o arquivo de dados do Vcenter
```py
VCENTER_DATA_PATH = '/home/daniel/safe/vcenters.yml'
```

### 5.1. Aplicado diretamente no ansible.cfg

```ini
[defaults]
inventory = vmware_dynamic_inventory.py
```

### 5.2. Aplicado em máquina remota e pegar output

Caso não seja possível executar o inventário dinâmico na própria máquina do Ansible, ainda é possible executar em outro servidor e trazer o output para máquina do Ansible.

- Executar

```bash
python3 vmware_dynamic_inventory.py --list --ini
```

- Copiar Arquivo Ini para máquina Ansible

```
vmware_dynamic_inventory.ini
```

- Configurar ansible.cfg para utilizar arquivo ini

```ini
[defaults]
inventory = vmware_dynamic_inventory.ini
```


## 6. Variáveis

Dentro do diretório vars/ se encontram diversas variáveis separadas por fase da execução.

- health_check.yml
- snapshot.yml
- upgrade.yml
- vcenters.yml


## 7. Execução

Em upgrade_controller.yml

```yaml
---
Stages:
  - health_check
  - reboot
  - snapshot
  - update_packages
  - clean_kernels
  - pre_upgrade
```

- Definir hosts nas sessão hosts:
- Definir os estágios de execução na sessão roles:

**Executando**

- Health Check

```bash
ansible-playbook upgrade_controller.yml -e stages=health_check
```


- Reboot

```bash
ansible-playbook upgrade_controller.yml -e stages=health_check,reboot
```

- Todos os estágios até o momento

```bash
ansible-playbook upgrade_controller.yml -e stages=health_check,reboot,snapshot,update_packages,clean_kernels,pre_upgrade
```

- Fluxo completo usando `all`

```bash
ansible-playbook upgrade_controller.yml -e stages=all
```
