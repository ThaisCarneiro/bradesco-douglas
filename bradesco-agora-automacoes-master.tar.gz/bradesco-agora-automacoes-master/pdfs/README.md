# PDF Copy

Estas playbooks realizam a cópia de arquivos PDFs entre a origem e o seus destinos em produção e homologação.
Cada playbook executa um passo, a primeira copia da origem para produção, e a segunda de produção para homologação.

A ideia é que estas playbooks estejam conectadas em um **workflow** do Ansible Automation Platform.

A autenticação com o CIFS é feita diretamente pelo usuário do Ansible.

## Variáveis

### 01-orig-to-prod.yml 

- `pdf_sftp_user`, uma string, o usuário de conexão com o SFTP de origen, ex: `agr_sftp_usr`;
- `pdf_sftp_password`, uma string, a senha do usuário de conexão do SFTP, ex: `123`;
- `pdf_sftp_host`, uma string, o endereço do SFTP, ex: `192.168.150.118`;
- `pdf_sftp_path`, uma string, o caminho que será copiado, ex: `/pg_dump/dtkeynes/ipo`;
- `pdf_cifs_path`, uma string, o endereço do CIFS que receberá a cópia, ex: `//ag-mz-vv-fs-002.corp.bradesco.com.br/apps/NitroCrawlers`;
- `pdf_cifs_mount_dir`, uma string, o caminho onde o CIFS será montado, ex: `/mnt/prod-pdfs`.

### 02-prod-to-hml.yml

- `pdf_cifs_prod_path`, uma string, o CIFS de produção, ex: `//ag-mz-vv-fs-002.corp.bradesco.com.br/apps/NitroCrawlers`;
- `pdf_cifs_prod_mount_dir`, uma string, o diretório de montagem do CIFS de produção, ex: `/mnt/prod-pdfs`;
- `pdf_cifs_hml_path`, uma string, o CIFS de homologação, ex: `//ag-ah-vv-fs-001.agorasenior.corp/apps/NitroCrawlers`;
- `pdf_cifs_hml_mount_dir`, uma string, o diretório de monagem do CIFS de homologação, ex: `/mnt/hml-pdfs`.

## Exemplo

```bash
ansible-playbook -i localhost,
-e ansible_user=Administrator \
-e ansible_password=123 \
-e pdf_sftp_user=root \
-e pdf_sftp_password=123 \
-e pdf_sftp_host=192.168.122.100 \
-e pdf_sftp_path=/opt/files \
-e pdf_cifs_path=//maquina.windows/files \
-e pdf_cifs_mount_dir=/mnt/pdfs \
-v 01-orig-to-prod.yml
```
