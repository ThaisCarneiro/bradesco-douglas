# Workflow Error

Esta playbook captura os erros anteriores na cadeia do workflow. Para isso, a playbook consulta a API do AAP.
A diferença entre usar esta playbook e a própria função de "notification" do AAP é exibir o erro no corpo do email.

## Variáveis

- `aap_url`, uma string, o endereço do AAP/AWX.
- `aap_user`, uma string, o usuário de acesso ao AAP/AWX.
- `aap_password`, uma string, a senha do usuário.
