# Projects

Esta playbook cria projetos dentro de vários clusters Openshift com algumas especificações como `roles` e `rolebindings`.
O diretório `yamls` contém os templates utilizados para a criação dos objetos.

Existem vários clusters definidos na variável `ocp_clusters` porém o cluster a ser utilizado é definido na variável `ocp_cluster`.

- tutihofix
- producao
- dr

## Replicação

Caso o cluster utilizado seja `producao` ou `dr` os objetos criados serão replicados no cluster oposto.

## Variáveis

A variável `ocp_projects_tutihofix`, quando definida, criará uma lista chamada `ocp_projects_suffix` que será utilizada como **sufixo** dos objetos a serem criados e implementará a criação de vários destes objetos em diferentes namespaces. Este comportamento não deve acontecer nos clusters de `producao` e `dr`, mas a definição da variável `ocp_projects_tutihofix` fica a critério do executor.

Dentro dos arquivos `yaml` existe a definição de `zone` que é calculada com base na presença do **sufixo** e no caso do sufixo ser `th`, ele será trocado por `ho`, como podemos observar no trecho abaixo:

```
zone={{ suffix|replace("-","")|replace("th","ho") if suffix != "" else ocp_projects_zone|lower|trim
```

As outras variáveis são autoexplicativas: 

```yml
# variaveis genaricas para usar como custom credential
ocp_user: kubeadmin
ocp_password: rGIqb-JeJqJ-6WIhh-aUr34
# enderecos de clusters disponiveis
ocp_clusters:
  local: https://api.crc.testing:6443 
# variaveis da playbook
ocp_cluster: local
ocp_projects_name: centos
ocp_projects_region: valemobi
ocp_projects_zone: th
ocp_projects_roles:
- pod_delete
ocp_projects_role_bindings:
- scc_anyuid
- pod_delete
```

## Exemplo

```bash
ansible-navigator run playbook.yml -e @vars.yml -v
```
