# LDAP

Esta playbook recebe uma lista de servidores LDAP `ldap_servers` e os verifica fazendo uma simples consulta.
Ao final da execução, uma variável chamada `send_mail_body` é criada com a intenção de ser o corpo do email do próximo passo do workflow.

## Variáveis

A única variável é sugestiva:

```yaml
ldap_servers:
- ldap://CO-AH-VV-DC-001.agorasenior.corp:389
```

## Exemplo

```bash
ansible-playbook -i localhost \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v playbook.yml
```
