# OCP Volumes

Esta playbook facilita a criação de volumes dentro do Openshift.
Todo volume criado em **produção** também será criado em **dr**.

## Variáveis

- `ocp_volumes_type`, uma string, pode ser `nfs` ou `cifs`.
- `ocp_volumes_pv_name`, uma string, define o nome do PV.
- `ocp_volumes_pvc_name`, uma string, define o nome do PVC.
- `ocp_volumes_size`, uma string, é preciso informá-la no formato reconhecido pelo Kubernetes, ex: `10Gi`.
- `ocp_volumes_host`, uma string, o endereço do servidor NFS ou CIFS, ex: `10.100.4.12`, `//ag-ah-vv-fs-001.agorasenior.corp`.
- `ocp_volumes_path`, uma string, o caminho do diretório a ser compartilhado no servidor NFS ou CIFS, ex: `/vol/vol_datakeynes/pv1`, `/Apps/up2data`.
- `ocp_volumes_namespace`, uma string, define o namespace onde os PVCs serão criados.

## Exemplo

```bash
ansible-playbook -i localhost, -e @vars.yml \
-e ocp_volumes_cluster=local \
-e ocp_volumes_type=cifs \
-e ocp_volumes_pv_name=teste \
-e ocp_volumes_pvc_name=teste \
-e ocp_volumes_size=1Gi \
-e ocp_volumes_host=10.0.0.1 \
-e ocp_volumes_path=/srv/nfs \
-e ocp_volumes_namespace=default \
playbook.yml
```
