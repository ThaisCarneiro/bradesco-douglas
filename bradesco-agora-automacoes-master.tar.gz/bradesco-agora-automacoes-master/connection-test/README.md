# Connection Test

Esta playbook realiza 4 testes de conexão utilizando uma máquina de origem (linux ou windows) e um número arbitrário de destinos.

Existem quatro tipos de teste, baseados nos nomes dos binários do Linux:

- telnet - No linux é utilizado `bash -c '</dev/tcp/<endereco>:<porta>'` e no windows `test-netconnection`;
- curl - No linux é utilizado o `curl` e no windows `invoke-webrequest`;
- ping - Em ambos os sistemas o comando é o mesmo.
- tracepath - No linux é utilizado `tracepath` e no windows `tracert`.

## Exemplo

```bash
ansible-playbook \
-e connection_test_type=telnet \
-e connection_test_host=192.168.122.100 \
-e connection_test_destiny=192.168.122.100:80,192.168.122.100:22 \
-e awx_job_id=1 \
-e awx_job_template_name=Teste \
-v playbook.yml
```
