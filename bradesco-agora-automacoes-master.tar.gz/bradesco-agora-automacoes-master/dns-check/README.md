# DNS

Esta playbook recebe uma lista de domínios em uma variável chamada `dns_records` e os verifica em cada item da lista `dns_servers` indicado nas variáveis.
Ao final da execução, uma variável chamada `send_mail_body` é criada com a intenção de ser o corpo do email do próximo passo do workflow.

## Variáveis

As variáveis são sugestivas:

```yaml
dns_servers:
- 8.8.8.8
- 208.67.222.222
dns_records:
- redhat.com
- bradesco.com.br
- anything.invalid
- debian.org
```

## Exemplo

```bash
ansible-playbook -i localhost \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v playbook.yml
```
