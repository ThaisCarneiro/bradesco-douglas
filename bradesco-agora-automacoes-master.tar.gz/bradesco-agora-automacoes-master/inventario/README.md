# Atualização de Inventário

Esta playbook baixa um arquivo CSV do sistema de inventário e atualiza um arquivo XLS comparando linha a linha através de um script em python.
As folhas **Worksheet** e **Servidores** são as únicas atualizadas, sendo a primeira uma cópia do csv e a segunda, alimentada por esta.

A planilha a ser atualizada é adquirida atrás de um CIFS, porém este CIFS não é montado como um diretório, para baixar e subir o arquivo utilizamos
o comando `smbclient`.

## Dependências

Esta playbook utiliza um script em python chamado `updater.py` que depende da biblioteca `openpyxl` e também do binário `smbclient`.

Os pacotes e seus repositórios são os seguintes:

| Pacote                   | Repositório                                            |
|--------------------------|--------------------------------------------------------|
| samba-client             | rhel-8-for-x86_64-baseos-rpms                          |
| python39-openpyxl.noarch | ansible-automation-platform-2.3-for-rhel-8-x86_64-rpms |

## Variáveis

- `url` - uma string, o endereço do sistema que gera o csv, exemplo: `http://localhost:8080`;
- `cifs_user` - uma string, o usuário que acessa o sistema, se não for especificado o padrão será o usuário do ansible;
- `cifs_password` - uma string, a senha do usuário, se não for especificada a senha será a mesma do usuário do ansible;
- `csv_path` - uma string, o caminho onde o csv será salvo, exemplo: `/tmp/planilha.csv`;
- `xls_path` - uma string, o caminho onde o xml a ser atualizado está, exemplo: `/tmp/planilha.xls`;
- `cifs_path` - uma string, o diretório CIFS compartilhado, ex: `//AG-MZ-VV-FS-002.corp.bradesco.com.br/Apps/`;
- `cifs_domain` - uma string, o domínio do CIFS, ex: `agorasenior.corp`.

### Atenção

É importante distinguir o diretório compartilhado dos diretórios subsequentes, neste exemplo o diretório compartilhado
é `Apps/` e dentro dele podemos encontrar `Ansible/inventario`. Neste caso o comando para baixar a planilha é o seguinte:

```bash
smbclient '//AG-MZ-VV-FS-002.corp.bradesco.com.br/Apps/' -c 'cd Ansible/inventario ; get file.xlsm /tmp/file.xlsm'
```

> Este comando está simplificado para melhor leitura.

## Exemplo

Dentro do diretório `files` existe um exemplo do arquivo csv e do arquivo xls.

Para testar esta playbook um script dentro do diretório `server` inicia um contêiner capaz de simular - de maneira bastante simplista - as requisições do ambiente do Bradesco.

```bash
cd server
bash run.sh
```

Com o servidor rodando, na porta `8080` por exemplo, podemos executar a playbook da seguinte forma:

```bash
ansible-playbook \
-e url=http://localhost:8080 \
-e cifs_user=ansible \
-e cifs_password=redhat \
-e cifs_domain=192.168.122.104 \
-e csv_path=/tmp/planilha.csv \
-e xls_path=/tmp/planilha.xls \
-v playbook.yml
```
