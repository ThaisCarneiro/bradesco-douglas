#!/usr/bin/python3

import csv, unicodedata, sys, argparse
from openpyxl import load_workbook
from openpyxl.styles import Border, Side, Font
from datetime import datetime

parser=argparse.ArgumentParser(description='Update a xls file with values extracted from a csv.')
parser.add_argument("--csv-path", help="The csv file path, the file with new values. Ex: /tmp/lines.csv", required=True)
parser.add_argument("--xls-path", help="The xls file path, the file to be updated. Ex: /tmp/data.xls", required=True)
args=parser.parse_args()

border = Border(
  left=Side(border_style='thin', color='FF000000'),
  right=Side(border_style='thin', color='FF000000'),
  top=Side(border_style='thin', color='FF000000'),
  bottom=Side(border_style='thin', color='FF000000')
)
font = Font(name='Bradesco Sans', size=6.5)

csv_lines = []
with open(args.csv_path) as csv_file:
  lines = csv.reader(csv_file, delimiter=';', skipinitialspace=True)
  for i, line in enumerate(lines):
    if i != 0:
      csv_lines.append(line)

wb = load_workbook(filename = args.xls_path, keep_vba=True)
worksheet = wb['Worksheet']
servidores = wb['Servidores']

hosts = worksheet['A1':'BH{}'.format(worksheet.max_row)]
for n, csv_line in enumerate(csv_lines, start=1):
  for cell in hosts:
    if csv_line[0].strip() == \
    cell[0].value.strip():
      for i in range(1, 60): #A1 - BH1
        try:
          if isinstance(cell[i].value, datetime):
            cell_value = cell[i].value.strftime('%d/%m/%Y %H:%M:%S')
          else:
            cell_value = cell[i].value
          if csv_line[i] != str(cell_value or ''):
            print(f'{n} - {csv_line[0]} - Diferente\n{csv_line[i]} != {cell_value}')
            for v, value in enumerate(csv_line):
              cell[v].value = value
            break
        except IndexError:
          pass
      break
  else:
    print(f'{n} - {csv_line[0]} - Novo')
    worksheet.append(csv_line)
    if csv_line[1] == 'Servidor':
      i = servidores.max_row + 1
      servidores.append([csv_line[0], '=IF(OR(ISBLANK(#REF!),ISBLANK(#REF!),ISBLANK(#REF!)),IF(ISBLANK(#REF!),"Verificar interfaces de rede (todas)","Verificar interfaces de rede (NOC,SOC,BKP)"),IF(ISBLANK(#REF!),"Verificar interface de rede (DADOS)",""))', '=IF(COUNTIF(L2,"*ou*"),IF(COUNTIF(AC2,"*N/A*"),"Confirmar versão SO/Preencher domínio","Confirmar versão SO"),IF(COUNTIF(AC2,"*N/A*"),"Preencher domínio",""))', '=IF(ISBLANK(#REF!),"Inserir CPU/Memória","")', '=IF(ISBLANK(H2),"Preencher Empresa","")', '', '', '', '', f'=VLOOKUP(A{i},Worksheet!A:BH,19,FALSE)', '', f'=VLOOKUP(A{i},Worksheet!A:BH,4,FALSE)', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', f'=VLOOKUP(A{i},Worksheet!A:BH,5,FALSE)', f'=VLOOKUP(A{i},Worksheet!A:BH,7,FALSE)', ''])
      cell = servidores[f'A{i}:AE{i}']
      for z in range(0, 31):
        cell[0][z].border = border
        cell[0][z].font = font

wb.save(args.xls_path)
