#!/bin/sh

podman run -dti --rm --name php -p 8080:80 -v ./:/php:z docker.io/php:8.2-cli \
sh -c 'apt-get update && apt-get install -y libzip-dev && docker-php-ext-install zip && php -S 0.0.0.0:80 -t /php'
