<?php

ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL & ~E_NOTICE);
session_start();

if (!empty($_GET['login']) && !empty($_GET['password'])) {
  if ($_GET['login'] == 'ansible' && $_GET['password'] == 'redhat') {
    session_regenerate_id();
		$_SESSION['username'] = $_GET['login'];
    echo 'Logged in';
  }
} else if (!empty($_POST['acao']) && $_POST['acao'] == 'exportarCSV') {
  $data = array('arquivo' => 'dados.csv');
  header("Content-Type: application/json");
  echo json_encode($data);
} else if (!empty($_GET['acao']) && $_GET['acao'] == 'downloadCSV' && !empty($_GET['arquivo'])) {
  echo file_get_contents($_GET['arquivo']); 
}
