# Replicação Portal

Esta playbook faz a sincronia de arquivos - neste caso de um webserver - entre uma máquina e outro, utilizando o comando `robocopy`.

## Variáveis

- `replicacao_portal_origem`, uma string, o caminho/diretório a ser copiado da máquina na qual o Ansible se conectou, ex: `D:\Pages`;
- `replicacao_portal_destino`, uma sting, o destino - normalmente uma outra máquina com seu próprio caminho/diretório - para onde a cópia irá, ex: `\\portal05\d$\pages`;
- `replicacao_portal_robocopy_flags` uma lista de string com os parâmetros do comando `robocopy`, ex: `["/R:1", "/W:5"]`.

## Robocopy

O `robocopy` é uma espécie de `rsync` para o Windows. Os parâmetros utilizados pelo `robocopy` nos arquivos analisados são os seguintes:

- `/R` - numero de tentativas em caso de falha;
- `/W` - tempo a esperar durante as tentativas;
- `/MIR` - espelha um diretório (/E copia subdiretórios, inclusive os vazios, /PURGE deleta os diretórios que não existem na fonte);
- `/NDL` - não exibe o log da cópia de diretórios;
- `/NP` - não exibe o progresso;
- `/XD` - exclui determinados diretórios;
- `/XF` - exclui determinados arquivos.

```bash
ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=Zaq1Xsw2 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v playbook.yml
```
