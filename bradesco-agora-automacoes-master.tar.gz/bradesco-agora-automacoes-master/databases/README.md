# Databases

Esta playbook executa queries em diferentes SGBDs, enviando os resultados por email, diretamente no corpo ou através de anexos.

## Anexos

Para criar anexos é preciso implementar a lógica de criação do CSV na própria query ou no cliente do banco. Nos casos do MySQL e do Oracle, toda a query que deseja gerar um arquivo CSV deve possuir uma "variável" chamada `@@csv@@` que será utilizada pelo Ansible para a localização do arquivo.

### Postgres

```sql
SELECT * FROM actor LIMIT 10;
```

No caso do Postgres, o parâmetro `--csv` no cliente é utilizado para salvar o resultado em algum lugar.

### MySQL

Todos os arquivos CSV são gerados no diretório `/var/lib/mysql-files/` graças a uma política de segurança do MySQL, mas este fato é transparente para os usuários da playbook.

```sql
USE mysql_employees;
SELECT *
INTO OUTFILE '@@csv@@'
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
FROM employee
LIMIT 10;
```

No caso do MySQL, a sintaxe `INTO OUT FILE` é utilizada para salvar o resultado em algum lugar. Importante ressaltar que o usuário que executa a query deve ter a permissão `FILE` ou ser um usário `SUPER`.

A seguir temos um exemplo da configuração da permissão global `FILE` para o usuário em questão:

```sql
GRANT FILE ON *.* TO ansible@'%';
```

### Oracle

Para o Oracle é preciso habilitar o `markup csv` além de utilizar `spool` para salvar o resultado em algum lugar.

```sql
set markup csv on
spool @@csv@@
select * from dba_objects a where a.status = 'INVALID';
```

## Variáveis

- `databases_type` uma string, define o tipo de SGDB, por exemplo postgres, oracle, sqlserver ou mysql.
- `databases_shared_folder` uma string, define o diretório onde os arquivos temporários serão salvos e compartilhados entre os passos do workflow, o padrão é `/opt/ansiblefiles/files`.
- `databases_query_files` uma lsita, define os arquivos com queries a serem executadas no servidor, exemplo `["queries/postgres-02.sql","queries/postgres-03.sql"]`.
- `databases_username` uma string, define o usuário de conexão com o banco de dados.
- `databases_password` uma string, define a senha de conexão com o banco de dados.
- `databases_database` uma string, define a base a ser utilizada.
- `databases_attach` um booleano, define se o resultado deverá ou não ser enviado como anexo. Para que isto funcione, o arquivo da query deverá ser capaz de gerar o CSV.

O Oracle utiliza algumas outras variáveis:

- `oracle_sid` é uma string, por exemplo `AGRHMLN1`.
- `oracle_home` é uma string, por exemplo `/u01/app/oracle/product/19.3.0.0/dbhome_1`.
- `oracle_base` é uma string, por exemplo `/u01/app/oracle`, normalmente esta variável não é necessária.

## Postgres

Este exemplo utiliza anexos graças a variável `databases_attach` além da própria query executada com `COPY`.

```bash
ansible-playbook -i 192.168.122.101, \
  -e databases_type=postgres \
  -e databases_port=5432 \
  -e '{"databases_query_files" : ["queries/postgres-02.sql", "queries/postgres-03.sql"]}' \
  -e databases_shared_folder=/opt/ansiblefiles/files \
  -e databases_username=ansible \
  -e databases_password=redhat \
  -e databases_database=dvdrental \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -e databases_attach=true \
  -v execute-query.yml
```

## MySQL

Este exemplo utiliza anexos graças a variável `databases_attach` além da própria query executada com `INTO OUTFILE`. 

```bash
ansible-playbook -i 192.168.122.101, \
  -e databases_type=mysql \
  -e '{"databases_query_files" : ["queries/mysql-02.sql"]}' \
  -e databases_shared_folder=/opt/ansiblefiles/files \
  -e databases_user=ansible \
  -e databases_password=redhat \
  -e databases_database=mysql_employees \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -e databases_shared_folder=/var/lib/mysql-files/ \
  -v execute-query.yml
```

## Oracle

Este exemplo utiliza anexos graças a variável `databases_attach` além da própria query executada com `set markup csv on` e `spool @@csv@@`.

```bash
ansible-playbook -i oracle-server, \
  -e databases_type=oracle \
  -e '{"databases_query_files" : ["queries/oracle-02.sql"]}' \
  -e databases_shared_folder=/opt/ansiblefiles/files \
  -e oracle_sid=AGRHMLN1 \
  -e oracle_base='/u01/app/oracle' \
  -e oracle_home='/u01/app/oracle/product/19.3.0.0/dbhome_1' \
  -e databases_user=ansible \
  -e databases_password=redhat \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -e databases_attach=true \
  -v playbook.yml
```

## SQL Server

Este exemplo utiliza anexos graças a variável `databases_attach`. Diferente dos outros bancos, não é necessário modificar a query para enviar a saída para um arquivo CSV.

```bash
cat >> inventory <<EOF
192.168.122.103 ansible_connection=winrm ansible_port=5985 ansible_winrm_transport=ntlm ansible_user=Administrator ansible_password=Zaq1Xsw2
EOF

ansible-playbook -i inventory \
  -e databases_type=sqlserver \
  -e '{"databases_query_files" : ["queries/sqlserver-01.sql"]}' \
  -e databases_attach=true \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v execute-query.yml
```
