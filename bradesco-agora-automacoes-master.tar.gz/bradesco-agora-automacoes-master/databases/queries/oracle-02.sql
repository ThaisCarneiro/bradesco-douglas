-- Verifica se as packages estão compiladas.
set markup csv on
spool @@csv@@
select * from dba_objects a where a.status = 'INVALIDZ';
