-- Lista os atores
SELECT * FROM actors LIMIT 10;
