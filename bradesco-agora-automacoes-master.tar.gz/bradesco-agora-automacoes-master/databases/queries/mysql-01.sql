-- Lista dos países
USE mysql_employees;
SELECT * FROM country LIMIT 10;
