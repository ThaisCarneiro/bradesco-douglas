-- Lista de usuarios
USE mysql_employees;
SELECT *
INTO OUTFILE '@@csv@@'
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
FROM employee
LIMIT 10;
