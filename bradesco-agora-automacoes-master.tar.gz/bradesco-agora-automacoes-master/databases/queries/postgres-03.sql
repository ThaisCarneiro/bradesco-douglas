-- Lista os filmes
SELECT * FROM film LIMIT 5;
