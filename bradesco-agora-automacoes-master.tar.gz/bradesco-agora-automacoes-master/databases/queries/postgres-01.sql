-- Lista os atores
SELECT * FROM actor LIMIT 5;
