-- seleciona tudo de sys.databases
select * from sys.databases;
