-- Verifica se as packages estão compiladas.

select 'OBJETOS INVALIDOS: ' AS INFRA, CASE  WHEN COUNT(*) >= 1 THEN 'NÃO OK' ELSE 'OK' END AS STATUS
  from dba_objects a
 where a.status = 'INVALID'
   and object_type in ('PACKAGE BODY','PACKAGE','PROCEDURE','FUNCTION','VIEW','TRIGGER')
   and owner not in ('QUEST',
                     'SYS',
                     'SYSTEM',
                     'HOME',
                     'AGR_SECUR',
                     'CFI',
                     'IMOBILIARIA',
                     'MONITORAMENTO',
                     'PERFSTAT',
                     'PUBLIC',
                     'SENIOR',
                     'MERCADORIAS')
UNION 
     select 'REPLICACAO ORACLE: ',
            CASE
              WHEN COUNT(*) >= 1 THEN
               'NÃO OK'
              ELSE
               'OK'
            END
       from gv$archived_log
      where first_time >= sysdate - 1 / 24
        and applied = 'NO'
        AND COMPLETION_TIME <= SYSDATE - 1 / 96
        AND STANDBY_DEST = 'YES'
UNION        
SELECT   'BACKUP: ' , DECODE(STATUS, 'COMPLETED','OK',
                   DECODE(STATUS, 'COMPLETED WITH WARNINGS', 'WARNING',
                   DECODE(STATUS, 'FAILED', 'NÃO OK','OK'))) AS STATUS
                   FROM V$RMAN_BACKUP_JOB_DETAILS C1
                  WHERE C1.END_TIME > SYSDATE - 1
                  AND INPUT_TYPE = 'DB INCR'
UNION
select 'JANELA DE BACKUP: ',DECODE(STATUS,'RUNNING','NOK',
                          DECODE(STATUS, 'RUNNING WITH WARNINGS', 'RUNNING WARNING', 'OK')) from V$RMAN_BACKUP_JOB_DETAILS
where start_time > sysdate-1
and INPUT_type = 'DB INCR'
UNION
SELECT 'BLOQUEIO DE USUARIOS: ',
            CASE
              WHEN COUNT(*) >= 1 THEN
               'NÃO OK'
              ELSE
               'OK'
            END
                  FROM DBA_USERS
                 WHERE LOCK_DATE > SYSDATE-1
                 AND ACCOUNT_STATUS <> 'OPEN'
UNION
-- o trecho comentado abaixo só se aplica para a Ágora
/*
SELECT 'ORDENS AGENDADAS: ',
            CASE
              WHEN COUNT(*) >= 1 THEN
               'NÃO OK'
              ELSE
               'OK'
            END
  FROM MEGABOLSA.ORDENSESPECIAIS
WHERE DT_PREGAO > (SELECT DT_DATMOV FROM CORRWIN.TBOPARAM)
UNION
*/
SELECT 'QUERIES ETD: ',DECODE(STATUS,'SUCCEEDED','OK','NÃO OK')
FROM dba_scheduler_job_log 
WHERE JOB_NAME='JBGERAQUERIESETDAGORA'
AND LOG_DATE > SYSDATE-1
UNION
select 'JOB EXPURGO BMF: ',DECODE(STATUS,'SUCCEEDED','OK','NÃO OK')
from dba_scheduler_job_log
where job_name = 'JBEXPURGODCBMF'
AND LOG_DATE > SYSDATE-1
UNION
select 'ESTATISTICAS: ',
            CASE
              WHEN COUNT(*) >= 1 THEN
               'NÃO OK'
              ELSE
               'OK'
            END
  from dba_tab_statistics o
WHERE o.owner = 'CORRWIN'
   and (o.TABLE_NAME in ('TMFTARI_TX_REG_EMOL',
                        'TMFTARI_TX_REG_EMOL_01',
                        'TMFTARI_TX_REG_EMOL_02',
                        'TMFTARI_TX_REG_EMOL_03',
                        'TMFTARI_TX_REG_EMOL_BULK',
                        'TMALRPSS',
                        'TMALPROT_NEG',
                        'TMALNEG_ALOC',
                        'TORCBL0602',
                        'TBOINFO_ANLT_IRRF',
                        'ABOFINA_PROS',
                        'TGEFAIXAIR',
                        'ABONEG_RATEO'
                        ) AND STALE_STATS = 'YES' or LAST_ANALYZED < SYSDATE-1)
                          OR  (o.TABLE_NAME IN ('TORCOMI',
                        'TORNEGD',
                        'ACFCONS_POSI') AND LAST_ANALYZED < SYSDATE-1 and OWNER =  'CORRWIN')
UNION
select 'INVALID INDEX: ' AS INFRA, CASE  WHEN COUNT(*) >= 1 THEN 'NÃO OK' ELSE 'OK' END AS STATUS
  from  all_indexes
where
  owner not in ('SYS', 'SYSTEM')
  and
  status != 'VALID'
  and (
    status != 'N/A'
    or
    index_name in (
      select
        index_name
      from
        all_ind_partitions
      where
        status != 'USABLE'
        and (
          status != 'N/A'
          or
          index_name in (
            select
              index_name
            from
              all_ind_subpartitions
            where
              status != 'USABLE'
          )
        )
    )
)
