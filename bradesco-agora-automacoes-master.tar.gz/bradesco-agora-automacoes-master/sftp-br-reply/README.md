# SFTP Copy

Esta tarefa é dividida em 5 passos, porém em duas partes, cada parte é um workflow. A separação em 4 passos é necessária pois cada máquina utiliza uma `credential` dentro do APP, e infelizmente só é possível especificar uma credencial por template.

- Passo 1 - Verifica arquivo no servidor Linux (sftp)
- Passo 2 - Verifica arquivo no servidor Windows
- Passo 3 - Faz cópias do arquivo do servidor Windows em diretórios de backup e baixa para máquina local
- Passo 4 - Copia os arquivos da máquina local para o servidor Linux e os remove
- Passo 5 - Limpa os arquivos do servidor Windows

Dentro das playbooks existe a referência a **host_destination** para o Linux (sftp) e **host_origin** para o Windows, de onde o arquivo origina-se.

Estas playbooks utilizam **artefatos** gerados pelos passos anteriores, isso torna a execução fora do APP um pouco complexa.

Workflow 1 (verificar e disparar email se necessário):

```
                                                     ┌-> (ok) -> fim
[ 01-verify-linux.yml ] -> [ 02-verify-windows.yml ] ┤
                                                     └-> (erro) -> [ email de erro ] -> fim
```

Workflow 2 (verificar e gerar arquivos se necessário):

```
                                                     ┌ -> (ok) -> fim
[ 01-verify-linux.yml ] -> [ 02-verify-windows.yml ] ┤
                                                     └-> (erro) -> [ 03-copy-windows.yml ] -> [ 04-copy-linux.yml ] -> [ 05-copy-windows.yml ] -> fim
```

## Inventário

```ini
host_destination ansible_host=192.168.122.101
host_origin ansible_host=192.168.122.103 ansible_connection=winrm ansible_user=Administrator ansible_password=123 ansible_winrm_transport=ntlm ansible_port=5985
```

## Primeira parte - Verificar se o arquivo existe

Os primeiros dois passos verificam se o arquivo existe no servidor de destino e no servidor de origem. A ideia é utilizar estas playbooks nos dois workflows distintos.

- No primeiro deles, apenas a verificação do arquivo é feita em ambas as máquinas para então disparar um email para uma equipe específica caso o arquivo não esteja presente em ambas. Este envio de email será executado por uma tarefa no Workflow do Automation Platform, porém a mensagem é gerada nesta playbook.
- Na outra execução, os passos para gerar o arquivo presente nas playbooks 03 e 04 serão executados ao invés de disparar um email.

## Variáveis

- `br_reply_destination_dir` o diretório do destino final do arquivo.
- `br_reply_origin_dir` o diretório na máquina de origem onde o arquivo deve estar.

## Exemplo

```bash
ansible-playbook -i inventory -e br_reply_destination_dir=/sftp/newedge 01-verify-linux.yml

ansible-playbook -i inventory  -e br_reply_origin_dir='C:\\Usuario\\9007-AGORA\\fechamento\\Backup' -e '{"step1_br_reply_file_stat" : {"stat" : {"exists" : false }}}' -e awx_job_id=1 -e awx_job_template_name=Teste -v 02-verify-windows.yml
```

# Segunda parte - Copiar e gerar arquivo criptografado

A playbook `03-copy-windows.yml` é responsável pelas cópias dos arquivos `BR_reply` e deve ser executada após a verificação da playbook `02-verify-windows.yml`. Para evitar utilização de shell, os arquivos são copiados e então apagados, pois não é possível mover arquivos através de outros módulos do Ansible.
Por alguma razão, existem duas cópias destes arquivos na máquina de origem (windows):

- `\\mz-vv-fs-065.corp.bradesco.com.br\Usuario\9007-AGORA\fechamento\Backup`
- `E:\Schedule\NewEdge\bkp\newedge`

A cópia para a máquina Linux é feita através de um binário chamado `pscp` pois não há como salvar arquivos em a.

Após todas as cópias e movimentações, os arquivos originais são apagados.

## Variáveis

- `br_reply_dir` - Controla o diretório base onde os arquivos são encontrados, o valor padrão é `\\mz-vv-fs-065.corp.bradesco.com.br\Usuario\9007-AGORA`. O primeiro diretório de backup está dentro deste diretório em `\fechamento\Backup`.
- `br_reply_bkp_dir` - Controla o segundo diretório onde uma cópia do arquivo é salva, o valor padrão é `E:\Schedule\NewEdge\bkp\newedge`.
- `br_reply_dir_separator` - Utilizado para evitar confusão na quebra de cadeias de string de diretórios do Windows utilizando escape, o valor padrão é `\`.
- `br_reply_local_dir` - Diretório utilizado para compartilhar arquivos entre execuções, o valor padrão é `/opt/ansiblefiles/files`.

## Exemplo

```bash
ansible-playbook -i inventory -e br_reply_dir='C:\\Usuario\\9007-AGORA' -e br_reply_bkp_dir='C:\\Schedule\\NewEdge\\bkp\\newedge' -e awx_job_id=1 -e awx_job_template_name=Teste -v 03-copy-windows.yml

ansible-playbook -i inventory -e awx_job_id=1 -e awx_job_template_name=Teste -e '{"step3_br_reply_files" : [{"path": "C:\\Usuario\\9007-AGORA\\BR_reply.20230714"}, {"path": "C:\\Usuario\\9007-AGORA\\BR_reply.20230715"}]}' -v 04-copy-linux.yml

ansible-playbook -i inventory -e br_reply_dir='C:\\Usuario\\9007-AGORA' -e awx_job_id=1 -e awx_job_template_name=Teste -v 05-copy-windows.yml
```
