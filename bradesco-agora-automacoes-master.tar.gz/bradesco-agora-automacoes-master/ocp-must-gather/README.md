# OCP must-gather

Esta playbook extrai e compacta o "must-gather" do Openshift diretamente dentro de um ponto de montagem compartilhado, evitando problemas nos discos locais. O ponto de montagem é um CIFS e o usuário e senha utilizado para sua autenticação é o mesmo usuário e senha do inventário do Ansible.

Além da extração, esta playbook é capaz de enviar o must-gather resultante para o sftp da Red Hat.

## Variáveis

Existem algumas variáveis, a maioria é autoexplicativa. A variável `ocp_must_gather_clusters` contém uma lista de clusters disponíveis e o cluster a ser utilizado é definido na variável `ocp_must_gather_cluster`.

```yaml
ocp_must_gather_cifs_path: //192.168.122.27/shared
ocp_must_gather_cifs_mount_dir: /mnt/must-gather
ocp_must_gather_clusters:
  local: https://api.crc.testing:6443
ocp_must_gather_cluster: local
ocp_must_gather_user: kubeadmin
ocp_must_gather_password: mEYbG-kYeZb-TgMhB-LuLo8 
```

## Exemplo

```bash
ansible-playbook -i localhost, \
-e ansible_user=root \
-e ansible_password=123 \
-e @vars.yml \
playbook.yml
```
