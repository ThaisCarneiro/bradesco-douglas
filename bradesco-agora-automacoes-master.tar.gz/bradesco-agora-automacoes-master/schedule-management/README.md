# Schedule Management

Esta playbook modifica o estado dos schedules do Ansible Automation Platform.

## Variáveis

Existem seis variáveis, todas são obrigatórias. De preferência, a `schedule_management_ansible_user` e a `schedule_management_ansible_password` devem ser adicionadas em um `custom credential type` para evitar que seus valores fiquem expostos no template.

- `schedule_management_ansible_url` é o endereço do próprio AAP sem sufixos, ex: https://192.168.122.100.
- `schedule_management_ansible_user` o usuário que a playbook utilizará para executar comandos.
- `schedule_management_ansible_password` a senha do usuário. 
- `schedule_management_names` uma string ou uma lista de nomes de schedules a serem modificadas.
- `schedule_management_reason` uma descrição breve sobre o porquê da modificação.
- `schedule_management_enabled` um booleano, pode ser "true", "false", "yes", "no", etc.

