#!/bin/bash

# Estes comandos devem ser executados em um container dentro do Openshift.
# Para os laboratórios utilizamods um memcached e port-forward.
# O memcached precisou do SCC privileged para instalar o binário do telnet.

read -r -d '' VALUE <<EOF
LISTA CANAIS
PROCESSOR-CANAL-001 T: true DELTA: 10
PROCESSOR-CANAL-002 T: true DELTA: 31
PROCESSOR-CANAL-010 T: true DELTA: 5
PROCESSOR-CANAL-020 T: true DELTA: 40
PROCESSOR-CANAL-080 T: true DELTA: 500
EOF

SIZE=$(echo -n "$VALUE" | wc -c)

echo -e "set list 0 0 $SIZE\r\n$VALUE\r" | nc 127.0.0.1 8080
