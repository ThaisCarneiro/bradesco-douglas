# Machine State

Esta playbook desliga ou reinicia servidores Linux/Windows. Existe uma única variável chamada `action` que pode receber os valores `shutdown` ou `restart`.

## Exemplo

### Linux

```bash
ansible-playbook -i 192.168.122.102, \
  -e action=shutdown \
  -v shutdown-restart-linux.yml
```

### Windows

```bash
ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=123 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e action=shutdown \
  -v shutdown-restart-windows.yml
```
