# Postgres Restore dbcvm

Este projeto restora um banco de dados postgres chamado **dbcvm**. Este banco de dados é extraído de uma outra base de dados externa ao bradesco e inicializada no ambiente interno. Por questões de segurança uma réplica não pôde ser utilizada.

Existem duas partes a serem executadas neste projeto:

- `sftp.yml` - Baixa o arquivo do SFTP em um CIFS para ser analisado por um antivírus e faz uma cópia para o CIFS de produção.
- `restore.yml` - Copia o arquivo do CIFS para a máquina do postgres e restaura o banco a partir do arquivo local.

## sftp.yml

Esta playbook baixa o diretório de restauração do postgres `dbcvm.dump` de um SFTP contendo o arquivo `toc.dat` e os demais `.gz` em um diretório compartilhado do tipo CIFS.
A cópia é iniciada somente se o arquivo `finalizado.YYYYMMDD` com o dia anterior existir no mesmo diretório. Este arquivo indica que a cópia disponível está completa e é seguro iniciar a restauração do banco.

Antes da cópia da acontecer, os arquivos existentes no CIFS são apagados.

Ao final da execução artefatos são criados com o horário de início e fim da cópia dos arquivos.

### Variáveis

- `pg_restore_aap_host`, uma string, o endereço do APP para o email, ex: `https://192.168.122.100`;
- `pg_restore_sftp_user`, uma string, o usuário de acesso ao SFTP, ex: `ansible`;
- `pg_restore_sftp_password`, uma string, a senha de acesso ao SFTP, ex: `ansible`;
- `pg_restore_sftp_host`, uma string, o endereço do SFTP, ex: `192.168.150.118`;
- `pg_restore_sftp_path`, uma string, o caminho do SFTP que contém o diretório `dbcvm.dump`, ex: `/arquivos/`;
- `pg_restore_cifs_path`, uma string, o endereço para montar o CIFS, ex: `//ag-ah-vv-fs-001.agorasenior.corp/Apps/Ansible/dbcvm_restore`;
- `pg_restore_cifs_path_prod`, uma string, o endereço de produção para montar o CIFS, ex: `//ag-mz-vv-fs-002.corp.bradesco.com.br/Apps/Ansible/dbcvm_restore`;
- `pg_restore_cifs_mount_dir`, uma string, o diretório para montagem do CIFS, ex: `/tmp/dbcvm_restore`;
- `pg_restore_cifs_mount_dir_prod`, uma string, o diretório para montagem do CIFS de produção, ex: `/tmp/dbcvm_restore_prod`.

## restore.yml

Esta playbook baixa o diretório de restauração do CIFS, copia para a máquina do postgres e faz a restauração local. Além da restauração comum, uma série de outras etapas são executadas durante a restauração, como, criação de permissões, materialized views, renomeação de tabelas (somente em produção), etc.

Nos ambientes que não são produção, a tabela original é descartada antes da importação, já em produção elas são renomeadas para garantir o funcionamento pelo maior tempo possível. A variável que controla esse comportamento é `pg_restore_drop`.

Ao final da execução, queries para exibir o tamanho do banco são feitas e deixadas para a próxima etapa em forma de artefatos para serem enviadas por email.

### Variáveis

- `pg_restore_temp_folder`, uma string, o caminho onde o diretório de backup será copiada, ex: `/backup/dbcvm_restore`;
- `pg_restore_dblink`, uma string, a conexão utilizada pela função `dblink_connect_u` no postgres, ex: `dbname=valemobi port=5433 host=10.222.80.28 user=Valemobi password=paquetata`;
- `pg_restore_cifs_path`, uma string, o endereço para montar o CIFS, ex: `//ag-ah-vv-fs-001.agorasenior.corp/Apps/Ansible/dbcvm_restore`;
- `pg_restore_cifs_mount_dir`, uma string, o diretório para montagem do CIFS, ex: `/tmp/dbcvm_restore`;
- `pg_restore_drop`, uma booleano, indica se o banco de dados deve ser descartado ou não durante a importação, ex: `false`;
