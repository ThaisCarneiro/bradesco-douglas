# IIS Restart

Esta playbook possui dois arquivos:

- `playbook.yaml` é o principal e utuliza um loop baseado na lista informada de serviços a serem reiniciados.
- `loop_pools_restart.yaml` é o trecho chamado dentro do loop, utilizando o nome de cada serviço para executar as tarefas.

Caso um pool não exista, ele será ignorado, portanto este tipo de problema poderá ser detectado apenas analisando os logs de execução.

## Variáveis

Existem duas variáveis para a playbook:

- `iis_pool_force_restart` é um valor **booleano** (true, false, yes, no) e controla se o pool deve ser reiniciado independente de estar rodando ou não. A playbook já inclui esta variável com o valor `false`.
- `iis_pools` é uma **lista** dos pools a serem verificados pela playbook.

A definição das variáveis em YAML é a seguinte:

```yaml
iis_pool_force_restart: false
iis_pools:
- PAC
- RiskManager
- Subscricao
```

## Testes

Para testar a playbook, o seguinte comando pode ser utilizado:

```bash
ansible-playbook -i 192.168.122.104, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=123 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e iis_pool_force_restart=true \ 
  -e iis_pools='["RiskManager","PAC"]' \
  playbook.yaml
```
