# Network Execute

Esta playbook executa uma serie de comandos em equipamentos de rede.
Existem dois arquivos que controlam que tipo de equipamento estamos lidando - `inventory.yml` - e quais comandos devemos executar em cada equipamento - `commands.yml`.

O controle da ordem de execução dos comandos é feito pelo arquivo `commands.yml`, mesmo que se comente ou limite a execução dos hosts será preciso comentar os mesmos em `commands.yml`, do contrário a playbook apresentará um erro para cada host especificado em commands não presente na execução atual.

Ao final das execuções um corpo de email é gerado para ser enviado na próxima tarefa do workflow.

Os equipamentos e comandos são consultados no `inventory.yml`:

```yaml
all:
  vars:
    ansible_python_interpreter: python

machines:
  hosts:
    controller:
      ansible_host: 192.168.122.100
    execution:
      ansible_host: 192.168.122.102
  vars:
    ansible_python_interpreter: python3

ios:
  hosts:
    cisco7200:
      ansible_host: 192.168.122.29
  vars:
    ansible_network_os: cisco.ios.ios
    ansible_connection: ansible.netcommon.network_cli
```

Note que neste inventário e no inventário oficial, existem variáveis específicas para controlar como o Ansible se conecta a estes equipamentos como `ansible_network_os` e `ansible_connection`.
Atualmente existem alguns tipos de equipamentos reconhecidos pela playbook, cada tipo possui um arquivo equivalente no diretório `types`:

- checkpoint - Equipamentos da checkpoint.
- huawei - Equipamentos da Huawei baseados em CloudEngine.
- ios - Equipamentos da Cisco baseados em ios.
- machines - Máquinas comuns - físicas ou virtuais.
- others - Equipamentos que não aceitarem nenhum módulo mas aceitam conexão ssh a partir de localhost.

Os comandos de cada equipamento estão presentes em `commands.yml`:

```yaml
equipments:
- host: controller
  commands:
  - hostname
  - ip -br a
- host: execution
  commands:
  - hostname
- host: cisco7200
  commands:
  - show ip interface brief
  - show logging
```
