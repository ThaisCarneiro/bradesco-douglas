# NTP Verify

Este projeto possui duas playbooks, `client.yml` e `server.yml`.

## server.yml

Esta playbook é utilizada para verificar a sincronia de horário nos servidores.

Executa o comando `timedatectl` e verifica se o serviço de NTP está rodando e o relógio está sincronizado, além de executar o comando `chronyc -4n sources` e analisar sua saída.
Três campos são analisados, o offset, o reach e o status. Todos estes campos são armazenados em variáveis baseadas no próprio `man` do `chronyc`.

Caso uma das condições baixo forem verdadeiras, um corpo de email será gerado com os status problemáticos e a saída completa do comando:

- Se `offset` for maior ou igual a 1 segundo, aquela fonte está muito atrasada.
- Se "reach" for igual a 376, aquela fonte está com problemas na última requisição.
- Se `s` for x, ~ ou ?, aquela fonte está com problemas.

Abaixo está o trecho editado do manual que trata sobre esses campos:

```
MS Name/IP address         Stratum Poll Reach LastRx Last sample
===============================================================================
#* GPS0                          0   4   377    11   -479ns[ -621ns] +/-  134ns
^? foo.example.net               2   6   377    23   -923us[ -924us] +/-   43ms
^+ bar.example.net               1   6   377    21  -2629us[-2619us] +/-   86ms

As colunas são as seguintes (omitido as colunas não utilizadas):

S
    Esta coluna indica o estado de seleção da fonte.

    •   * indica a melhor fonte selecionada atualmente para a sincronização.

    •   + indica outras fontes selecionadas para sincronização, as quais são combinadas com a melhor delas.

    •   - indica que a fonte é considerada para ser selecionada para sincronização, mas não foi selecionada atualmente.

    •   x indica que a fonte é considerada pelo chronyd como "falseticker". (ex. está inconsistente com a maioria das outras fontes ou do grupo de confiança - trust).

    •   ~ indica que a fonte parece estar variando demais.

    •   ? indica que a fonte não é considerada para sincronização por outros motivos (ex. inalcançãvel, não sincronizada, ou não há medições suficientes).

    O comando selectdata pode ser utilizado para obter mais detalhes sobre o estado de seleção.

Reach
    Esta coluna demonstra o registro de alcançabilidade exibido como um número octal. O registro tem 8 bits e é atualizada a cada pacote recebido ou perdido da fonte. Um valor de 377 indica que aquele período recebeu uma resposta válida de todas as últimas oito transmissões.

Last sample
    Esta coluna demonstra a diferença entre o relógio local e a fonte na última medição. O número dentro dos colchetes mostra a diferença atual medida. Este valor pode ter o sufixo ns (nanosegundos), us (microsegundos), ms (milissegundos) ou s (segundo). O número à esquerda dos colchetes mostra a medida original, ajustada para qualquer variação aplicada ao relógio local. O número seguido pelo indicador +/- demonstra a margem de erro da medição. Diferenças positivas indicam que o relógio local está à frente da fonte.
```

## client.yml

Esta playbook é utilizada para verificar a sincronia de horário nos clientes.
Executa o comando `timedatectl` e verifica se o serviço de NTP está rodando e o relógio está sincronizado.
