# Cert and Key validation

Esta playbook verifica se um determinado certificado pertence a uma determinada chave.

## Variáveis

Existem apenas duas variáveis, como elas são muito grandes e possuem muitas linhas a melhor forma de configurá-las é atrás da interface do AAP ou mesmo de um arquivo de variáveis:

- `verify_key_content`, uma string, contém a chave.
- `verify_cert_content`, uma string, contém o certificado.

**vars.yml**

```yaml
verify_cert_content: |
  -----BEGIN CERTIFICATE-----
  MIIFYDCCBEigAwIBAgISA7gNZeDBqWC69zozoNfOLaWyMA0GCSqGSIb3DQEBCwUA
  MDIxCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1MZXQncyBFbmNyeXB0MQswCQYDVQQD
  EwJSMzAeFw0yMzExMDgxNzQ3MjBaFw0yNDAyMDYxNzQ3MTlaMCMxITAfBgNVBAMT
  -----END CERTIFICATE-----
verify_key_content: |
  -----BEGIN PRIVATE KEY-----
  cjvhvcI0hlBlWEoM2dOKjC0lOwwVlMTKFYE2tVEhg1PO6G4cTIgUT8zXSyULpMP/
  mGPygx/Cafu1qHRVBpRVYLjcfoYeVugOQZnohWeoo2sqSEnxRqTHoeYW1fhvx42D
  IZAnOxCuvGiWiHFYr7hJ1fLx
  -----END PRIVATE KEY-----
```

## Exemplo

```bash
ansible-playbook -i localhost, \
-e @vars.yml \ 
playbook.yml -v
```
