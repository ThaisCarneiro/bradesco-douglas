# Certificate

Esta playbook utiliza as informações obtidas pelas variáveis para criar uma chave privada e um arquivo .csr.

## Variáveis

Existem quatro variáveis, três delas são obrigatórias pois estão relacionadas com a criação do .csr:

- `certificate_name` uma string, o primeiro valor do CN - domínio - do certificado, por exemplo `teste`.
- `certificate_city` uma string, indica o valor de L - location/city - do certificado, atualmente existem apenas dois valores utilizados `osasco` e `alphaville`.
- `certificate_domain` uma string, o restante do CN - domínio - do certificado, por exemplo `example.com`.
- `certificate_alt_names` uma lista, todos os nomes extras além do CN, por exemplo `["teste", "apps"]`, todos estes nomes serão prefixo do `certificate_domain`, exemplo `apps.example.com`.
- `certificate_temp_folder` uma string, indica o diretório compartilhado entre as execuções em uma mesma máquina, padrão `/opt/ansiblefiles/files`.

Para manter a ciência das configurações originais, caso existam `certificate_alt_names`, um dos seus valores deverá ser obrigatoriamente `certificate_name`.

## Exemplo

```bash
ansible-playbook -i localhost, \
  -e certificate_name=teste \
  -e certificate_domain=example.com \
  -e certificate_alt_names=teste,apps \
  -e certificate_city=osasco \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v playbook.yml
```
