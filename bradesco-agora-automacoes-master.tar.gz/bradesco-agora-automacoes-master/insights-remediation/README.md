# Insights Remediation 

Esta playbook aplica todas as CVEs disponíveis no Insights da Red Hat para determinadas máquinas especificadas pelo prefixo de seus hostnames.

É possível utilizar `tags` para fazer uma filtragem inicial mais performática, para isso utilizamos as tags presentes em cada máquina no arquivo `/etc/insights-client/tags.yaml`. Após as tags serem configuradas, é necessário rodar o comando `insights-client` para atualizar as informações no Insights.

As máquinas são filtradas pelo nome, isso significa que caso a primeira consulta - principalmente sem as `tags` - retornar mil máquinas, as mil máquinas terão seus nomes verificados.

Após as máquinas serem filtradas, uma ou mais requisições são feitas para a consulta de CVEs afetando a máquina em questão e após todas as máquinas serem verificadas as CVEs são finalmente aplicadas através do comando `dnf upgrade -v -y --cve <CVE1> <CVE2> ...`.

## Data

É possível especificar uma data limite para aplicação dos CVEs através da variáveo `insights_until_date`, por exemplo, especificar `01/01/2022` fará com que todas as CVEs até esta data sejam aplicadas.

## Tags

Tags do Insights podem ser utilizadas para realizar uma filtragem inicial e evitar que muito mais máquinas do que o necessário sejam analisadas.

## Reinicialização

As máquinas saberão se precisam ser reinicializadas após a execução do `dnf upgrade` com base na saída do comando `needs-restarting -r`, a lista com as máquinas a serem reinicializadas é enviada por email.

## Exemplo

```bash
ansible-playbook -e insights_machine_prefix='automation' -e insights_until_date=01/01/2022 -e insights_user='<email>' -e insights_password='<senha>' -e insights_tags=tags=insights-client/consultant=hvidosil cves-search.yml
```
