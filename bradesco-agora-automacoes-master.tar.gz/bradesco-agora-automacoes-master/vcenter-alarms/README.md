# VCenter Alarms

Esta playbook verifica se há algum tipo de alarme disparado em todos os datacenters do VCenter e caso exista algum, um email é enviado.
Infelizmente a mensagem do alerta não é muito clara e a criticidade é basada em cores como verde, amarelo e vermelho.

## Variáveis

Existem três variáveis que devem ser informadas, todas são autoexplicativas:

- `vcenter_hostname` uma string, o endereço do VCenter, ex: `192.168.122.130`;
- `vcenter_username` uma string, o usuário para acessar o VCenter, ex: `administrator@vsphere.local`;
- `vcenter_password` uma string, a senha para acessar o VCenter, ex: `Zaq1Xsw@`;

## Exemplo

```bash
ansible-playbook -i localhost, \
-e awx_job_id=1 \
-e awx_job_template_name=Teste \
-v playbook.yml
```
