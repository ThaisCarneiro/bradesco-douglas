# Copy Files

Esta playbook copia os arquivos de um diretório base para outros localizações variadas. Essa cópia acontece por grupos, cada grupo possui seus diretórios de destino e também seus filtros opcionais especificados por "file glob" `(*.txt, ansi*.yml)`.
Desta forma é possível copiar diferentes arquivos para diferentes diretórios.

## Variáveis

Existem três variáveis, duas delas são string (`copy_files_source`, `copy_files_age`) e uma delas é uma lista (`copy_files_list`).
A variável `copy_files_list` possui duas propriedades:
- `destiny` é uma lista de diretórios destino, para onde os arquivos serão copiados;
- `glob` é o padrão que será utilizado para a cópia dos arquivos, se omitido, todos os arquivos do diretório de origem serão copiados.

```yaml
copy_files_source: C:\Usuario\9007-AGORA\fechamento\Backup
copy_files_age: -9999
copy_files_list:
- destiny:
  - C:\dir1
  - C:\dir2
  glob:
  - 'ansi*.txt'
  - '*.rtf'
- destiny:
  - C:\dir3
```

## Exemplo

```bash
ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=Zaq1Xsw2 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e @vars-test.yml \
  -v playbook.yml
```
