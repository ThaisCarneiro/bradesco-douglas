WITH base_calendar AS
  (SELECT (date_trunc('day', dd):: date) AS dt_reference ,
          0 AS valor
   FROM generate_series ((CURRENT_TIMESTAMP - INTERVAL '3 DAY') , CURRENT_TIMESTAMP , '1 day'::interval) dd),
     base_data AS
  ( SELECT tb_order_event.dh_creation_event::date AS dt_reference,
       coalesce(count(1), 0) total
FROM tb_order_event
INNER JOIN tb_order ON (tb_order_event.id_order) = (tb_order.id_order)
INNER JOIN tb_stock ON (tb_order.id_stock) = (tb_stock.id_stock)
WHERE tb_order_event.dh_creation_event BETWEEN (CURRENT_TIMESTAMP - INTERVAL '3 DAY') AND CURRENT_TIMESTAMP
  AND cd_segment != '9999'
  AND ds_channel = 'Android Smartphone'
  AND seq = 1
GROUP BY 1 ),
     base_data_hist AS
  ( SELECT tb_order_event_hist.dh_creation_event::date AS dt_reference,
       coalesce(count(1), 0) total
FROM tb_order_event_hist
INNER JOIN tb_order_hist ON (tb_order_event_hist.id_order) = (tb_order_hist.id_order)
INNER JOIN tb_stock ON (tb_order_hist.id_stock) = (tb_stock.id_stock)
WHERE tb_order_event_hist.dh_creation_event BETWEEN (CURRENT_TIMESTAMP - INTERVAL '3 DAY') AND CURRENT_TIMESTAMP
  AND cd_segment != '9999'
  AND ds_channel = 'Android Smartphone'
  AND seq = 1
GROUP BY 1  ),
     data_sum AS
  (SELECT coalesce(base_data.dt_reference, base_data_hist.dt_reference) AS dt_reference,
          coalesce(base_data_hist.total, 0) + coalesce(base_data.total, 0) AS total
   FROM base_data
   INNER JOIN base_data_hist ON base_data_hist.dt_reference = base_data.dt_reference),
     data_without_hist AS
  (SELECT base_data.*
   FROM base_data
   LEFT JOIN base_data_hist ON base_data_hist.dt_reference = base_data.dt_reference
   WHERE base_data_hist.dt_reference IS NULL),
     data_without_base AS
  (SELECT base_data_hist.*
   FROM base_data_hist
   LEFT JOIN base_data ON base_data_hist.dt_reference = base_data.dt_reference
   WHERE base_data.dt_reference IS NULL),
     base_data_union_all AS
  (SELECT *
   FROM data_sum
   UNION ALL SELECT *
   FROM data_without_hist
   UNION ALL SELECT *
   FROM data_without_base
   ORDER BY 1)
SELECT to_char(coalesce (base_data_union_all.dt_reference, base_calendar.dt_reference), 'DD/MM/YYYY') AS dt_reference,
       coalesce(total, 0) AS total
FROM base_calendar
LEFT JOIN base_data_union_all ON base_data_union_all.dt_reference = base_calendar.dt_reference;
