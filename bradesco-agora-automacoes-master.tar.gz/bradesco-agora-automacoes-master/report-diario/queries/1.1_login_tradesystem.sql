WITH base_calendar AS
  ( SELECT (date_trunc('day', dd):: date) AS dt_reference ,
           0 AS valor
   FROM generate_series ((CURRENT_TIMESTAMP - INTERVAL '3 DAY') , CURRENT_TIMESTAMP , '1 day'::interval) dd) ,
     base_data AS
  (SELECT dh_login::date AS dt_reference,
          coalesce (count(1), 0) AS total
   FROM tb_log_investor_access
   WHERE id_contract = 39
     AND tb_log_investor_access.dh_login BETWEEN (CURRENT_TIMESTAMP - INTERVAL '3 DAY') AND CURRENT_TIMESTAMP
     AND in_login_sucessfull
     AND cd_channel = '14'
   GROUP BY 1)
SELECT to_char(coalesce (base_data.dt_reference, base_calendar.dt_reference), 'DD/MM/YYYY') AS dt_reference,
       coalesce(total, 0) AS total
FROM base_calendar
LEFT JOIN base_data ON base_data.dt_reference = base_calendar.dt_reference;
