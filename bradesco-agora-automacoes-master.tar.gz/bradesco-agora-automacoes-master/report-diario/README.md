# Report Diário

Esta playbook executa uma série de consultas em um PostgreSQL e retorna as queries por email em um formato facilitado para que uma pessoa preencha um sistema com os valores recebidos. 
As consultas são feitas a partir do ponto de execução - contêiner ou máquina - esta playbook **não se conecta via SSH na máquina banco de dados**.
Todas as queries estão presentes no diretório `queries` e são executadas em sequência.

Dos resultados obtidos, apenas o dia anterior é considerado.

## Variáveis

Além das variáveis automáticas do próprio AAP como `awx_job_id` e `awx_job_template_name`, temos:

- `db_host` - uma string, o endereço do banco de dados, ex: `192.168.122.99`;
- `db_database` - uma string, a base de dados a ser consultada, ex: `test`;
- `db_port` - um inteiro, o porta do banco de dados a ser consultada, o valor padrão é `5432`;
- `db_username` - uma string, o nome do usuário de acesso ao banco, ex: `ansible`; 
- `db_password` - uma string, a senha do usuaŕio de acesso ao banco, ex: `@password`;

## Dependências

- community.postgresql

## Queries de Exemplo

Para testar essa playbook não é necessário uma base de dados idêntica a original, apenas duas queries como estas em arquivos diferentes são suficientes:

**1.1_query.sql**

```sql
SELECT '15/01/2024' as dt_reference, '100' as total;
```

**2.1_query.sql**

```sql
SELECT '15/01/2024' as dt_reference, '200' as total;
```

## Exemplos

```bash
ansible-playbook -i localhost, \
-e db_host=192.168.122.99 \
-e db_database=test \
-e db_port=5432 \
-e db_username=ansible \
-e db_password=@password \
-e awx_job_id=1 \
-e awx_job_template_name=Teste \
-v playbook.yml
```
