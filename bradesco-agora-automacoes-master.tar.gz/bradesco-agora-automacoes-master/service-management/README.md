# Service Management

Estas playbooks controlam o estado de serviços (running, restarted, stopped, reloaded) em Linux e Windows.
Caso o serviço não exista ele será ignorado, já os serviços com problemas terão seus erros ignorados mas salvos em um lista de erros.
Todos os erros serão acumulados em uma lista, ao final da playbook um corpo de email será gerado com base nessa lista e sua falha será forçada caso existam erros.

Estas playbooks devem ser conectadas a uma outra playbok de envio de email que deverá ser executada sempre que ocorrer uma falha.

## Linux

Esta playbook para Linux controla o estado dos serviços.

### Variáveis

- `lsm_state` é um string e deve ser preenchida com os estados válidos de serviço (running, restarted, stopped, reloaded), o valor padrão é **running**. Esta variável controla o estado que será aplicado em todos os serviços da lista.
- `lsm_services` é uma lista dos serviços a serem gerenciados.

A definição das variáveis em YAML é a seguinte:

```yaml
lsm_state: started
lsm_services:
- crond
- chronyd
```

### Testes

Para testar a playbook, o seguinte comando pode ser utilizado:

```bash
ansible-playbook -i 192.168.122.101, \
  -e '{"lsm_services" : ["crond","auditd"]}' \
  -e lsm_state=started \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v linux-playbook.yml
```

## Windows - Serviços Comuns

A playbook para Windows controla o estado dos serviços, mas por padrão considera apenas os serviços que iniciam como `auto` ou `delayed`.

### Variáveis

- `wsm_services` uma lista de serviços a serem gerenciados, por exemplo: `["W32Time","WSearch","wuauserv"]`.
- `wsm_state` o estado em que o serviço deve estar, o padrão é `started`.
- `wsm_start_mode` o modo, ou modos separados por vírgulas, que um serviço deve ser inicializado para ser considerado pela playbook, o padrão é `auto,delayed`.

Podemos definir as variáveis no formato YAML da seguinte forma:

```yaml
wsm_services:
- W32Time
- WSearch
- wuauserv
wsm_state: started
wsm_start_mode: auto,delayed
```

### Exemplo

```bash
ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=Zaq1Xsw2 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e 'wsm_services=["W32Time","WSearch","wuauserv"]' \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v windows-playbook.yml
```

## Windows - Serviços Cluster

A playbook para serviços do tipo cluster do Windows apenas **inicia ou para serviço** ao invés de gerenciá-lo como os demais.

### Variáveis

- `wsm_services` uma lista de serviços a serem gerenciados, por exemplo: `["W32Time","WSearch","wuauserv"]`.
- `wsm_state` pode receber o valor `started` ou `stopped`, o padrão é `started`.

Podemos definir as variáveis no formato YAML da seguinte forma:

```yaml
wsm_services:
- W32Time
- WSearch
- wuauserv
wsm_state: started # apenas started ou stopped
```

### Exemplo

```bash
ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=Zaq1Xsw2 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e 'wsm_services=["W32Time","WSearch","wuauserv","AppHostSvc"]' \
  -e wsm_state=started \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v windows-cluster-playbook.yml
```
