# LDAP User Verify

Esta playbook verifica se uma lista de usuários estão bloqueados de alguma forma em vários servidores LDAP através de `userAccountControl` ou `lockoutTime`.
Para fazer o **bind** no servidor LDAP a playbook itiliza o `ansible_password`.

## Variáveis

- `ldap_verify_servers`, um dicionário, as propriedades são as seguintes:
  - `uri`, uma string, o endereço de acesso ao LDAP, ex `ldap://192.168.122.103:389`;
  - `ldap_bind_dn`, uma string, a DN de autenticação, ex `CN=PUSRANSIMCA,CN=Users,DC=agorasenior,DC=corp`;
  - `ldap_base_dn`, uma string, a base a ser utilizada para as buscas, ex `OU=Agora,DC=bradesco,DC=com,DC=br`;
- `ldap_verify_users`, uma lista, as `sAMAccountName` dos usuários a serem verificados, ex `["jiddu", "paramahansa"]`;
- `ldap_unblock`, um booleano, indica se as contas serão desbloqueadas automaticamente, ex `false`.

## Exemplo

Considerando o arquivo de variáveis como o seguinte:

```yml
ldap_verify_servers:
- uri: ldap://192.168.122.103:389
  bind_dn: CN=Administrator,CN=Users,DC=windao,DC=local
  base_dn: CN=Users,DC=windao,DC=local
ldap_verify_users:
- jiddu
- paramahansa
ldap_unblock: false
awx_job_id: 1
awx_job_template_name: Teste
```

A execução pode ser feita da seguinte forma:

```bash
ansible-playbook \
-e @vars.yml \
-e ansible_password=Zaq1Xsw2 \
playbook.yml -v
```
