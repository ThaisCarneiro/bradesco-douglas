# Windows Upgrade - Inplace

Existem três playbooks neste repositório:

- Starter - dispara vários processos de atualização no AAP
- Pre - executa tarefas antes do snapshot (feito por outra playbook)
- Update - atualiza o windows

Este conjunto de playbooks atualiza o Windows através de uma ISO montada na própria instância. Dependendo da versão instalada do Windows um índice diferente de imagem deve ser utilizado, no Ágora existem duas versões do Windows a Standard com Desktop e a Datacenter com Desktop, a playbook detecta esta versão e escolhe um índice apropriado:

- ServerStandard - 2
- ServerDatacenter - 4

As edições existentes do Windows server são:

- Windows Server Standard
- Windows Server Standard with Desktop Experience
- Windows Server Datacenter
- Windows Server Datacenter with Desktop Experience

Existem várias playbooks, cada uma delas é responsável por algumas tarefas:

- `windows-update-starter.yml`;
- `windows-update-pre.yml`;
- `windows-update.yml`, que chama internamente a seguinte;
- `windows-update-wsus.yml`.

## Variáveis

As variáveis abaixo estão separadas por playbooks:

### Starter

- `aap_host`, uma string, o endereço da API do AAP, ex: `https://ansible.mca.corp/api/v2`;
- `aap_job_name`, uma string ou um inteiro, referência ao template de atualização do Windows, ex: `390`;
- `windows_update_wait`, um inteiro, o número de minutos a esperar antes de começar a atualização, ex: `60` (uma hora);
- `windows_hosts`, uma string, os FQDN dos windows a serem atualizados, separados por vírgula, ex: `windows1.bradesco.corp,windows2.bradesco.corp`.

### Pre

- `vm_fqdn`, uma string, o hostname completo da máquina que será atualizada;
- `win_update_password`, uma string, a senha a ser utilizada para os usuários locais, ex: `123`;
- `win_next_version`, uma string, a versão destino - em ano - do Windows, ex: `2022`;

### Update

- `vm_fqdn`, uma string, o hostname completo da máquina que será atualizada;
- `win_update_copy_iso`, um booleano, se a ISO deve ser copiada e montada ou montada diretamente, ex: `false`;
- `win_update_iso_path`, uma string, o caminho da ISO, exemplo: `D:\images\Windows-Server-2019.iso`;
- `win_update_info_path`, uma string, o caminho onde o resultado dos comandos de conferência são salvos, ex: `C:\Update`.

## Exemplo - windows-update.yml

```bash
ansible-playbook -i 192.168.122.104, \
-e ansible_connection=winrm \
-e ansible_user=Administrator \
-e ansible_password=Zaq1Xsw2 \
-e ansible_winrm_transport=ntlm \
-e ansible_port=5985 \
-e awx_job_id=1 \
-e awx_job_template_name=Teste \
-v windows-update-pre.yml
```
