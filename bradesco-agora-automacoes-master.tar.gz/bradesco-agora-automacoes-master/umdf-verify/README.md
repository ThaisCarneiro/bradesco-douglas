# Servidores UMDF

Esta playbook reinicia servidores UMDF com delta maiores do que 30. A leitura é feita através de telnet.

Existe um script chamado `insert-memcached.sh` que cria um contêiner baseado em **memcached** para que testes possam ser feitos. Para utilizá-lo basta alterar o comando `list` da playbook para `get list`, assim um output semelhante ao serviço original poderá ser obtido por telnet.

## Variáveis

Existem três variáveis importantes:

- `telnet_host` é o endereço de conexão com o servidor telnet, o padrão é `127.0.0.1`.
- `telnet_port` é a porta do serviço, o padrão é `23`.
- `telnet_sleep` é o tempo que o shell esperará antes de enviar um próximo comando, o padrão é `5`.

## Exemplo

```bash
ansible-playbook -i localhost, -e telnet_port=4050 -v playbook.yml
```
