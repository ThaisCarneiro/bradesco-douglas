#!/bin/bash

podman rm -f memcached || true
podman run -ti --rm -d -p 4050:11211 --name memcached memcached:alpine

read -r -d '' VALUE <<EOF
LISTA CANAIS
051 SYNC: true REP: false DELTA: 13
052 SYNC: true REP: false DELTA: 30
053 SYNC: true REP: false DELTA: 28
054 SYNC: true REP: false DELTA: 31
055 SYNC: true REP: false DELTA: 0
056 SYNC: true REP: false DELTA: 4
057 SYNC: true REP: false DELTA: 31
EOF

SIZE=$(echo -n "$VALUE" | wc -c)

echo -e "set list 0 0 $SIZE\r\n$VALUE\r" | nc 127.0.0.1 4050
