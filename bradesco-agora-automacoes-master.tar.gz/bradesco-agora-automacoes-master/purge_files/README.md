# Purge Files

Esta playbook recebe um dicionário com o tempo de existência e os diretórios a serem verificados, após essa verificação os arquivos com tempo de vida maior ou igual ao especificado serão removidos.

## Variáveis

```yaml
purge_list:
  10d:
  - D:\SECURECLIENT\39_SINACOR
  - D:\SECURECLIENT\39_BACKUP
  - \\asint008.agorasenior.corp\g\SINACOR\BOVESPA
  - \\asint008.agorasenior.corp\g\SINACOR\B3\RECEBIDOS
  - \\asint008.agorasenior.corp\G\Sinacor\B3-CERTIFICACAO\AGORA\RECEBIDOS_NOVA_AGORA
  45d:
  - \\asint008.agorasenior.corp\g\SINACOR\BOVESPA\HISTORICO\BKP
```

## Exemplo

```bash
ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=Zaq1Xsw2 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e @vars.yml \
  -v playbook.yml
```
