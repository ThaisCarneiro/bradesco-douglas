# Verify Mail Queue

Esta playbook é relativamente simples, sua execução verifica a quantidade de arquivos existentes em um diretório de relay de emails. Caso a quantidade de arquivos seja maior do que o definido na variável `mail_queue_treshold` um corpo de email será gerado.

## Variáveis

- `mail_queue_dir` - uma string, o diretório no qual os arquivos representando os emails estão, ex `C:\relay\queue`.
- `mail_queue_treshold` um inteiro, o número máximo de arquivos permitidos no diretório acima, ex `10`.

## Exemplos

```bash
ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=Zaq1Xsw2 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e awx_job_id=1 \
  -e awx_job_template_name=Teste \
  -v playbook.yml
```
