#!/bin/bash

PATH=$PATH:/root/openshift:/root/infracost

echo '# Passo 01 - Cria duas namespaces (openshift-logging + openshift-operators-redhat)'
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/logging/eo-namespace.yaml
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/logging/clo-namespace.yaml
sleep 05

oc get ns | grep openshift-logging
oc get ns | grep openshift-operators-redhat
sleep 05

echo '# Passo 02 - Configurar Storage (StorageClass thin)'
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/logging/create_storage_thin.yaml
oc get sc | grep thin
sleep 05

echo '# Passo 03 - Instalar Operator Group (OpenShift Elasticsearch)'
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/logging/eo-og.yaml
sleep 30
oc get operatorgroup -n openshift-operators-redhat
sleep 05

echo '# Passo 04 - Instalar (OpenShift Elasticsearch Operator + Subscription elasticsearch-operator)'
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/logging/eo-sub.yaml
sleep 30
oc get operators
oc get csv -A
oc get subscription -n openshift-operators-redhat
oc get operators -n openshift-marketplace

echo '# Passo 05 - Instalar (Cluster Logging Operator + Subscription Logging)'
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/logging/clo-og.yaml
sleep 60

oc get operatorgroup -n openshift-logging
sleep 05

oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/logging/clo-sub.yaml
sleep 60

echo '# Passo 06 - Install instance logging'
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/logging/clo-instance.yaml
sleep 60
oc get clusterlogging -n openshift-logging
sleep 05
