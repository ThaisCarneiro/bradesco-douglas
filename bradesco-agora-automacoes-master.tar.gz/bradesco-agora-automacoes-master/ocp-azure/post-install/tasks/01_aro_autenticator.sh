#!/bin/bash
set +x

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

export PATH=$PATH:/root/openshift:/root/infracost

# Main
print_ts "START - AZ ARO NameSpace"
az login --service-principal -u {{ aro_client_id }} -p {{ aro_client_secret }} --tenant {{ aro_tenant_id }}
if [ "$?" -eq 0 ];then
    print_ts "Command az login - OK"
else
    print_ts "Error to execute command az login"
    exit 171
fi

az account set --subscription {{ aro_subscription_id }}
if [ "$?" -eq 0 ];then
    print_ts "Command az account set - OK"
else
    print_ts "Error to execute command az account set"
    exit 171
fi

export OC_PASS=$(az aro list-credentials --name "{{ aro_cluster_name }}" --resource-group "{{ aro_resource_group }}" --query kubeadminPassword -o tsv)
oc login -u admin -p {{ aro_ocp_admin_password }} https://api.{{ aro_cluster_name }}.{{ aro_domain_name }}:6443 --insecure-skip-tls-verify
oc login -u kubeadmin -p "$OC_PASS" https://api.{{ aro_cluster_name }}.{{ aro_domain_name }}:6443 --insecure-skip-tls-verify
