#!/bin/bash

set +x

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

export CLUSTER_NAME={{ aro_cluster_name }}
export DOMAIN_NAME={{ aro_domain_name }}

# Main
PATH=$PATH:/root/openshift:/root/infracost

print_ts "Aplicando configuracoes identityProviders-AAD-htpasswd.yaml..."
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroOpenidHtpasswdKubeadmin/identityProviders-AAD-htpasswd.yaml
if [ "$?" -eq 0 ];then
    print_ts "Command oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroOpenidHtpasswdKubeadmin/identityProviders-AAD-htpasswd.yaml OK"
else
    print_ts "Error to execute command oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroOpenidHtpasswdKubeadmin/identityProviders-AAD-htpasswd.yaml"
    exit 171
fi

print_ts "Tempo para replicar as configuracoes..."
sleep 300
print_ts "Login com user admin htpasswd..."
oc login -u admin -p {{ aro_ocp_admin_password }} https://api.{{ aro_cluster_name }}.{{ aro_domain_name }}:6443 --insecure-skip-tls-verify
if [ "$?" -eq 0 ];then
    print_ts "Command oc login -u admin - OK"
    print_ts "Usuario conectado: admin - Removendo o kubeadmin"
    oc delete secrets kubeadmin -n kube-system
else
    print_ts "Error to execute command oc login -u admin"
    exit 171
fi
sleep 05

#ADICIONAR URL DE CALLBACK DO CLUSTER NO SPN DE AUTENTICAÇÃO DO ARO (SP-ARO-4250-PRD)
OUTPUTURL=`az ad app show --id be469f69-bd3a-41f6-a39d-fd4730d5a1a6 --query "web.redirectUris"`
EXPORTURL=$(echo "$OUTPUTURL" | grep -o 'https://[^"]*')
echo $EXPORTURL

az ad app update --id ffcedd95-7420-46a2-8c74-17766df94ea0 --web-redirect-uris $EXPORTURL https://oauth-openshift.apps.$CLUSTER_NAME.$DOMAIN_NAME/oauth2callback/AAD
