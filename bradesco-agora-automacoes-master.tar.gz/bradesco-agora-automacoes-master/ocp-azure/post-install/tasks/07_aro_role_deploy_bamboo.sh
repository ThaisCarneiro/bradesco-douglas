#!/bin/bash'

PATH=$PATH:/root/openshift:/root/infracost

# CRIAÇÃO DE ROLE CUSTOMIZADA PARA DEPLOY VIA SERVICE ACCOUNT DO BAMBOO
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/role_deploy_bamboo.yaml
sleep 05
oc get clusterrole -A | grep aro-deploy-custom-role
sleep 05
# Permissão de Role para ArgoCD
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/argocd/argocd-clusterreader.yaml
sleep 05
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/argocd/argocd-reader-clusterrole.yaml
sleep 05
