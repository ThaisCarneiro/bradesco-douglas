#!/bin/bash

PATH=$PATH:/root/openshift:/root/infracost

# LOCALIDADE=aro
# PRODUTO=aro
oc login -u kubeadmin -p {{ aro_ocp_mcm }} https://api.cticosprmcm01.producao.ibm.cloud:6443 --insecure-skip-tls-verify
sleep 5

oc new-project {{ aro_cluster_name }}

# nao utilizado depois do upgrade do ACM
#oc label namespace {{ aro_cluster_name }} cluster.open-cluster-management.io/managedCluster={{ aro_cluster_name }}

sleep 5

cat << EOF | oc create -f -
apiVersion: cluster.open-cluster-management.io/v1
kind: ManagedCluster
metadata:
  name: {{ aro_cluster_name }}
  labels:
    cloud: auto-detect
    vendor: auto-detect
    ldap: "false"
    produto: aro
    localidade: aro
    politica: "true"
    ambiente: {{ aro_environment }}
spec:
  hubAcceptsClient: true
EOF
sleep 5

oc get secret {{ aro_cluster_name }}-import -n {{ aro_cluster_name }} -o jsonpath={.data.crds\\.yaml} | base64 --decode > klusterlet-crd.yaml
oc get secret {{ aro_cluster_name }}-import -n {{ aro_cluster_name }} -o jsonpath={.data.import\\.yaml} | base64 --decode > import.yaml
sleep 5

cat <<EOF | oc create -f -
apiVersion: agent.open-cluster-management.io/v1
kind: KlusterletAddonConfig
metadata:
  name: {{ aro_cluster_name }}
  namespace: {{ aro_cluster_name }}
spec:
  applicationManager:
    enabled: true
  certPolicyController:
    enabled: true
  iamPolicyController:
    enabled: true
  policyController:
    enabled: true
  searchCollector:
    enabled: true
EOF
sleep 5

oc login -u admin -p {{ aro_ocp_admin_password }} {{ aro_cluster_api_url }} --insecure-skip-tls-verify
sleep 5
oc apply -f klusterlet-crd.yaml
sleep 5
oc apply -f import.yaml
