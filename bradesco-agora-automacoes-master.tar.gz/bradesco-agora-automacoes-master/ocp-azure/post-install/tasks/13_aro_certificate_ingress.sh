#!/bin/bash

set +ex

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

# Main
PATH=$PATH:/root/openshift:/root/infracost
print_ts "Login com keyvault admin"
az login --service-principal -u {{ aro_user_keyvault }} -p {{ aro_secret_keyvault }} --tenant {{ aro_tenant_id }} > /tmp/$$_output 2>&1
if [ $? -eq 0 ];then
    print_ts "Command az login - OK"
else
    print_ts "Error to execute command az login"
    cat /tmp/$$_output
    exit 171
fi

print_ts "Set da subscription do keyvault"
az account set --subscription {{ aro_subscription_id_keyvault }}
if [ $? -eq 0 ];then
    print_ts "Command az account set - OK"
else
    print_ts "Error to execute command az account set"
    exit 171
fi

export CLUSTERNAME={{ aro_cluster_name }}
if [ "{{ aro_environment }}" = "dv" ];then
    export CERTURL=apps.$CLUSTERNAME.{{ aro_domain_name }}
    print_ts "CERTURL = $CERTURL"
else
    if [ {{ aro_subscription_id_keyvault }} = {{ aro_subscription_id }} ];then
        export CERTURL=apps.$CLUSTERNAME.{{ aro_domain_name }}
        print_ts "CERTURL = $CERTURL"
    else
        export CERTURL=apps.$(print_ts $CLUSTERNAME | sed ''s ..$  '').{{ aro_domain_name }}
        print_ts "CERTURL = $CERTURL"
    fi
fi

print_ts "CLUSTERNAME = $CLUSTERNAME"

export CERTNAME=$(echo $CERTURL | sed 's/^\*\.//g' | sed 's/\./-/g')

print_ts "Download do certificado do cluster..."
az keyvault secret download --file {{ aro_cluster_name }}.pfx --encoding base64 --name $CERTNAME --vault-name {{ aro_keyvault }}
if [ $? -eq 0 ];then
    print_ts "Command az keyvault secret download - OK"
else
    print_ts "Error to execute command az keyvault secret download"
    exit 171
fi

print_ts "Converte PFX para PEM"
openssl pkcs12 -in {{ aro_cluster_name }}.pfx -passin pass: -out {{ aro_cluster_name }}.pem -nodes
if [ $? -eq 0 ];then
    print_ts "Command openssl pkcs12 - OK"
else
    print_ts "Error to execute command openssl pkcs12"
    exit 171
fi

print_ts "Extrai a chave privada"
openssl pkey -in {{ aro_cluster_name }}.pem -out {{ aro_cluster_name }}.key
if [ $? -eq 0 ];then
    print_ts "Command openssl pkey - OK"
else
    print_ts "Error to execute command openssl pkey"
    exit 171
fi

print_ts "Extrai a cadeia de certificados"
openssl crl2pkcs7 -nocrl -certfile {{ aro_cluster_name }}.pem | openssl pkcs7 -print_certs -out {{ aro_cluster_name }}-cadeia-completa.pem
if [ $? -eq 0 ];then
    print_ts "Command openssl crl2pkcs7 -nocrl - OK"
else
    print_ts "Error to execute command openssl crl2pkcs7 -nocrl"
    exit 171
fi
# remove os atributos do certificado
cat {{ aro_cluster_name }}-cadeia-completa.pem | egrep -v 'subject|issuer' > temp-{{ aro_cluster_name }}-cadeia-completa.pem
# separa os certificados

csplit -s -z -f certificado- temp-{{ aro_cluster_name }}-cadeia-completa.pem '/-----BEGIN CERTIFICATE-----/{*}'

# Verifica o CNAME do certificado e renomeia o arquivo
for CERTIFICADO in certificado-0*;do 
    CNAME=$(openssl x509 -in $CERTIFICADO -noout -subject 2> /dev/null)
    case $CNAME in
      *Root*)
          mv $CERTIFICADO certificado-root.crt
      ;;
      *Issuing*)
          mv $CERTIFICADO certificado-intermediario.crt
      ;;
      *.apps.*)
          mv $CERTIFICADO certificado-server.crt
      ;;
      *)
          continue
      ;;
    esac
done

# Coloca os certificados na ordem correta
cat certificado-server.crt certificado-intermediario.crt certificado-root.crt > {{ aro_cluster_name }}-cadeia-completa.pem

print_ts "Desabilitando o MCP para configurar certificado do ingress"
oc patch --type=merge --patch='{"spec":{"paused":true}}' machineconfigpool/worker
oc patch --type=merge --patch='{"spec":{"paused":true}}' machineconfigpool/master

print_ts "Criando configmap custom-ca..."
oc create configmap custom-ca --from-file=ca-bundle.crt=./cloud-portal-squad-iac-openshift/Aro_posinstall/certs/root.arocorpp.bradesco.com.br.crt -n openshift-config
if [ $? -eq 0 ];then
    print_ts "Command oc create configmap - OK"
else
    print_ts "Error to execute command oc create configmap"
    exit 171
fi

print_ts "Update the cluster-wide proxy configuration with the newly created configmap..."
oc patch proxy/cluster --type=merge --patch='{"spec":{"trustedCA":{"name":"custom-ca"}}}'
if [ $? -eq 0 ];then
    print_ts "Command oc patch proxy/cluster - OK"
else
    print_ts "Error to execute command oc patch proxy/cluster"
    exit 171
fi

print_ts "Create a secret that contains the wildcard certificate chain and key..."
oc create secret tls custom-cert-tls --cert={{ aro_cluster_name }}-cadeia-completa.pem --key={{ aro_cluster_name }}.key -n openshift-ingress
if [ $? -eq 0 ];then
    print_ts "Command oc create secret tls - OK"
else
    print_ts "Error to execute command oc create secret tls"
    exit 171
fi

print_ts "Update the Ingress Controller configuration with the newly created secret..."
oc patch ingresscontroller.operator default --type=merge -p '{"spec":{"defaultCertificate":{"name": "custom-cert-tls"}}}' -n openshift-ingress-operator
if [ $? -eq 0 ];then
    print_ts "Command oc patch ingresscontroller.operator - OK"
else
    print_ts "Error to execute command oc patch ingresscontroller.operator"
    exit 171
fi

print_ts "Habilitando o MCP para replicar as configuracoes"
oc patch --type=merge --patch='{"spec":{"paused":false}}' machineconfigpool/worker
oc patch --type=merge --patch='{"spec":{"paused":false}}' machineconfigpool/master

az login --service-principal -u {{ aro_client_id }} -p {{ aro_client_secret }} --tenant {{ aro_tenant_id }} > /tmp/$$_output 2>&1
if [ $? -eq 0 ];then
    print_ts "Command az login - OK"
else
    print_ts "Error to execute command az login"
    cat /tmp/$$_output
    exit 171
fi

az account set --subscription {{ aro_subscription_id }}
if [ $? -eq 0 ];then
    print_ts "Command az account set - OK"
else
    print_ts "Error to execute command az account set"
    exit 171
fi

sleep 60
