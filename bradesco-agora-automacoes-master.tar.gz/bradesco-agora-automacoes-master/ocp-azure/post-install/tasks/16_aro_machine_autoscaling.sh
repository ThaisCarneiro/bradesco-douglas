#!/bin/bash 

set -x
set +e

# Global variables
PATH=$PATH:/root/openshift:/root/infracost

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

oc login -u admin -p {{ aro_ocp_admin_password }} {{ aro_cluster_api_url }} --insecure-skip-tls-verify
if [ "$?" -eq 0 ];then
    print_ts "Command oc login -u admin - OK"
else
    print_ts "Error to execute command oc login -u admin"
    exit 171
fi

export CLUSTER_AZUREID=`oc get machineset -n openshift-machine-api | awk '{print $1}' | cut -d'-' -f2 | grep -iv name | head -1`;

cat <<EOF | oc apply -f -
apiVersion: autoscaling.openshift.io/v1
kind: ClusterAutoscaler
metadata:
  name: default
spec:
  balanceSimilarNodeGroups: true
  podPriorityThreshold: -10
  resourceLimits:
    cores:
      max: 480
      min: 48
    maxNodesTotal: 60
    memory:
      max: 1920
      min: 192
  scaleDown:
    delayAfterAdd: 1m
    delayAfterDelete: 90s
    delayAfterFailure: 90s
    enabled: true
    unneededTime: 90s
---
apiVersion: autoscaling.openshift.io/v1beta1
kind: MachineAutoscaler
metadata:
  name: machineautoscaler-{{ aro_cluster_name }}-brazilsouth1
  namespace: openshift-machine-api
spec:
  minReplicas: 2
  maxReplicas: 8
  scaleTargetRef:
    apiVersion: machine.openshift.io/v1beta1
    kind: MachineSet
    name: {{ aro_cluster_name }}-${CLUSTER_AZUREID}-worker-brazilsouth1
---
apiVersion: autoscaling.openshift.io/v1beta1
kind: MachineAutoscaler
metadata:
  name: machineautoscaler-{{ aro_cluster_name }}-brazilsouth2
  namespace: openshift-machine-api
spec:
  minReplicas: 2
  maxReplicas: 8
  scaleTargetRef:
    apiVersion: machine.openshift.io/v1beta1
    kind: MachineSet
    name: {{ aro_cluster_name }}-${CLUSTER_AZUREID}-worker-brazilsouth2
---
apiVersion: autoscaling.openshift.io/v1beta1
kind: MachineAutoscaler
metadata:
  name: machineautoscaler-{{ aro_cluster_name }}-brazilsouth3
  namespace: openshift-machine-api
spec:
  minReplicas: 2
  maxReplicas: 8
  scaleTargetRef:
    apiVersion: machine.openshift.io/v1beta1
    kind: MachineSet
    name: {{ aro_cluster_name }}-${CLUSTER_AZUREID}-worker-brazilsouth3
EOF
