#/bin/bash

PATH=$PATH:/root/openshift:/root/infracost

### 1- New ClusterRole
oc create clusterrole azure-secret-reader --verb=create,get --resource=secrets
sleep 5

### 2- Associate service account
oc adm policy add-cluster-role-to-user azure-secret-reader system:serviceaccount:kube-system:persistent-volume-binder
sleep 5

### 3- New storageclass
cat <<EOF | oc create -f -
kind: StorageClass
apiVersion: storage.k8s.io/v1
metadata:
  name: azure-file
provisioner: kubernetes.io/azure-file
parameters:
  location: brazilsouth
  secretNamespace: kube-system
  skuName: Standard_LRS
reclaimPolicy: Delete
allowVolumeExpansion: true
volumeBindingMode: Immediate
EOF

sleep 5

cat <<EOF | oc create -f -
kind: StorageClass
apiVersion: storage.k8s.io/v1
metadata:
  name: azure-disk
  annotations:
    storageclass.kubernetes.io/is-default-class: true
provisioner: kubernetes.io/azure-disk
parameters:
  location: brazilsouth
  skuName: StandardSSD_LRS
reclaimPolicy: Delete
allowVolumeExpansion: true
volumeBindingMode: Immediate
EOF

sleep 5

oc patch storageclass managed-csi -p '{"metadata": {"annotations":{"storageclass.kubernetes.io/is-default-class":"false"}}}'

sleep 5
