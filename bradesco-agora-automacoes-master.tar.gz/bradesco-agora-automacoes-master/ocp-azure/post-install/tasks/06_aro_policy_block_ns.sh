#!/bin/bash

PATH=$PATH:/root/openshift:/root/infracost

oc adm policy add-cluster-role-to-group self-provisioner system:authenticated:oauth
sleep 05
oc adm policy remove-cluster-role-from-group self-provisioner system:authenticated:oauth
sleep 05
