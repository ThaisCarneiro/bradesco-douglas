#!/bin/bash

set +x

PATH=$PATH:/root/openshift:/root/infracost

oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/csi/1-install_csi_driver.yaml
sleep 05
oc adm policy add-scc-to-user privileged system:serviceaccount:k8s-secrets-store-csi:secrets-store-csi-driver
sleep 05
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/csi/2-install_csi_azure_provider.yaml
sleep 05
oc adm policy add-scc-to-user privileged system:serviceaccount:k8s-secrets-store-csi:csi-secrets-store-provider-azure
sleep 05
oc patch scc restricted --type merge -p '{"volumes":["csi","configMap","downwardAPI","emptyDir","persistentVolumeClaim","projected","secret"]}'
sleep 05
oc patch scc anyuid --type merge -p '{"volumes":["csi","configMap","downwardAPI","emptyDir","persistentVolumeClaim","projected","secret"]}'
sleep 05
oc patch scc restricted-v2 --type=json -p '[{ "op": "add", "path":"/volumes/-", "value":"csi" }]'
