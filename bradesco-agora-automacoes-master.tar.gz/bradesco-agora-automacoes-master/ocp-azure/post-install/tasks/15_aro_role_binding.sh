#!/bin/bash

set +x

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

# Main
PATH=$PATH:/root/openshift:/root/infracost

print_ts 'Aplicando Rolebinding grupo de suporte OTI'
oc create clusterrolebinding GRP-AZU-BRAD-OPTI-GECL-CLIA_oti --clusterrole=cluster-admin --group=1a8cf957-63f2-490f-99c1-f6be46684a16
if [ "$?" -eq 0 ]; then
    print_ts 'Rolebinding aplicado com sucesso login - OK'
else
    print_ts 'Falha ao aplicar Rolebinding'
    exit 171
fi
