#!/bin/bash

PATH=$PATH:/usr/local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/root/openshift:/root/infracost
git clone https://{{ aro_bitbucket_user_engenharia_caas }}:{{ aro_bitbucket_password_engenharia_caas }}@bitbucket.bradesco.com.br:8443/scm/eiac/cloud-portal-squad-iac-openshift.git
