#!/bin/bash

set +ex

PATH=$PATH:/root/openshift:/root/infracost

function ocp_verify () {
    if [ $1 -eq 0 ];then
        echo "*** $2 ********** OK ******" >> result.txt
    else
        echo "*** $2 ********** Error ***" >> result.txt
    fi
}

### Script para check do pos-install #################
echo "=> Check cluster:" >> result.txt
echo "*** Cluster Name: {{ aro_cluster_name }}"
echo "*** api openshift: https://api.{{ aro_cluster_name }}.{{ aro_domain_name }}:6443" >> result.txt
echo "*** Resource group: {{ aro_resource_group }}" >> result.txt
echo "*** Version Cluster:" >> result.txt
oc get clusterversion >> result.txt

### STORAGECLASS #################
echo "\n=> Check Storageclass:" >> result.txt
oc get storageclass | grep kubernetes.io/azure-file
ocp_verify $? 'StorageClass azure-file'

oc get storageclass | grep "azure-disk (default)"
ocp_verify $? 'StorageClass azure-disk'

### NAMESPACE TOOLS #################
echo "\n=> Check NS Tools:" >> result.txt
oc get ns | grep tools
ocp_verify $? 'Namespace tools'

### SERVICE ACCOUNT #################
echo "\n=> Check ServiceAccount:" >> result.txt
oc get sa -A | grep bamboo
ocp_verify $? 'ServiceAccount bamboo'

oc get sa -A | grep axway
ocp_verify $? 'ServiceAccount axway'

### CLUSTER ROLE DEPLOY #################
echo "\n=> Check ClusterRole:" >> result.txt
oc get clusterrole | grep aro-deploy-custom-role
ocp_verify $? 'ClusterRole aro-deploy-custom-role'

oc get clusterrole | grep argocd-reader
ocp_verify $? 'ClusterRole argocd-reader'

oc get ClusterRoleBinding | grep argocd-reader
ocp_verify $? 'ClusterRoleBinding argocd-reader'

### CHECK CSI DRIVE #################
echo "\n=> Check CSI Drive Install:" >> result.txt
oc get ns | grep k8s-secrets-store-csi
ocp_verify $? 'Namespace k8s-secrets-store-csi'

oc get clusterrole | grep secretproviderclasses-role
ocp_verify $? 'ClusterRole secretproviderclasses-role'

oc get ClusterRoleBinding -A | grep secretproviderclasses-rolebinding
ocp_verify $? 'ClusterRoleBinding secretproviderclasses-rolebinding'

oc get ClusterRole  -A | grep secretproviderclasses-role
ocp_verify $? 'ClusterRole secretproviderclasses-role'

oc get ServiceAccount  -A | grep secrets-store-csi-driver
ocp_verify $? 'ServiceAccount secrets-store-csi-driver'

oc get ClusterRole  -A | grep secretproviderrotation-role
ocp_verify $? 'ClusterRole secretproviderrotation-role'

oc get ClusterRoleBinding  -A | grep secretproviderrotation-rolebinding
ocp_verify $? 'ClusterRoleBinding secretproviderrotation-rolebinding'

oc get ServiceAccount  -A | grep secrets-store-csi-driver
ocp_verify $? 'ServiceAccount secrets-store-csi-driver'

oc get CSIDriver  -A | grep secrets-store.csi.k8s.io
ocp_verify $? 'CSIDriver secrets-store.csi.k8s.io'

oc get CustomResourceDefinition  -A | grep secretproviderclasses.secrets-store.csi.x-k8s.io
ocp_verify $? 'CustomResourceDefinition secretproviderclasses.secrets-store.csi.x-k8s.io'

oc get CustomResourceDefinition  -A | grep secretproviderclasspodstatuses.secrets-store.csi.x-k8s.io
ocp_verify $? 'CustomResourceDefinition secretprovider***.secrets-store.csi.x-k8s.io'

oc get DaemonSet  -A | grep csi-secrets-store-secrets-store-csi-driver
ocp_verify $? 'DaemonSet csi-secrets-store-secrets-store-csi-driver'

### CHECK CSI #################
echo "\n=> Check CSI Azure Install:" >> result.txt
oc get ServiceAccount  -A | grep csi-secrets-store-provider-azure
ocp_verify $? 'ServiceAccount csi-secrets-store-provider-azure'

oc get ServiceAccount  -A | grep secrets-store-csi-driver
ocp_verify $? 'ServiceAccount secrets-store-csi-driver'

oc get ClusterRole  -A | grep psp:allow-csi-driver
ocp_verify $? 'ClusterRole psp:allow-csi-driver'

oc get ClusterRole  -A | grep psp:allow-csi-driver-provider-azure
ocp_verify $? 'ClusterRole psp:allow-csi-driver-provider-azure'

oc get ClusterRoleBinding  -A | grep k8s-secrets-store-csi:allow-csi-driver
ocp_verify $? 'ClusterRoleBinding k8s-secrets-store-csi:allow-csi-driver'

oc get ClusterRoleBinding  -A | grep k8s-secrets-store-csi:allow-csi-driver-provider-azure
ocp_verify $? 'ClusterRoleBinding k8s-secrets-store-csi:allow-csi-driver-provider-azure'

# oc get PodSecurityPolicy  -A | grep allow-csi-driver-provider-azure
#ocp_verify $? 'PodSecurityPolicy allow-csi-driver-provider-azure'

# oc get PodSecurityPolicy  -A | grep allow-csi-driver
#ocp_verify $? 'PodSecurityPolicy allow-csi-driver'

### CHECK SCC CSIDRIVER #################
echo "\n=> Check SCC CSIDriver:" >> result.txt
oc get scc | grep -i 'anyu'| grep -i 'csi'
ocp_verify $? 'scc anyu'

oc get scc | grep -i 'restricted'| grep -i 'csi'
ocp_verify $? 'scc restricted'

oc get scc | grep -i 'restricted-v2'
ocp_verify $? 'scc restricted-v'

### OPENSHIFT LOGGING #################
echo "\n=> Openshift Logging:" >> result.txt

oc get ns | grep openshift-logging
ocp_verify $? 'Namespace openshift-logging'

oc get ns | grep openshift-operators-redhat
ocp_verify $? 'Namespace openshift-operators-redhat'

oc get operatorgroup -n openshift-operators-redhat | grep openshift-operators-redhat
ocp_verify $? 'operatorgroup openshift-operators-redhat'

oc get operators | grep elasticsearch-operator.openshift-operators-redhat
ocp_verify $? 'operators elasticsearch-operator.openshift-operators-redhat'

oc get csv -A | grep elasticsearch-operator
ocp_verify $? 'csv elasticsearch-operator'

### AUDIT LOG #################
echo "\n=> Aro Enable Audit Log:" >> result.txt

oc get ClusterLogForwarder -n openshift-logging | grep instance
ocp_verify $? 'ClusterLogForwarder instance'

### ARO INTEGRATION NEXUS #################
echo "\n=> Aro Integration Nexus:" >> result.txt

oc get configmap -n openshift-config | grep registry-nexusrepository
ocp_verify $? 'configmap registry-nexusrepository'

oc describe configmap registry-nexusrepository -n openshift-config | grep nexusrepository.bradesco.com.br..8500
ocp_verify $? 'configmap nexusrepository.bradesco.com.br..8500'

oc describe configmap registry-nexusrepository -n openshift-config | grep nexusrepository.bradesco.com.br..8501
ocp_verify $? 'configmap nexusrepository.bradesco.com.br..8501'

oc describe configmap registry-nexusrepository -n openshift-config | grep nexusrepository.bradesco.com.br..8502
ocp_verify $? 'configmap nexusrepository.bradesco.com.br..8502'

oc describe configmap registry-nexusrepository -n openshift-config | grep nexusrepository.bradesco.com.br..8506
ocp_verify $? 'configmap nexusrepository.bradesco.com.br..8506'

oc describe image.config.openshift.io | grep  nexusrepository.bradesco.com.br
ocp_verify $? 'ImageRegistry nexusrepository.bradesco.com.br'


### OPENID HTPASSWD #################
echo "\n=> Aro Openid Htpasswd Kubeadmin:" >> result.txt

oc get secret -n openshift-config | grep htpasswd-aro
ocp_verify $? 'Secret htpasswd-aro'

oc get secret -n openshift-config | grep openid-client-secret
ocp_verify $? 'Secret openid-client-secret'

oc describe OAuth | grep htpasswd-aro
ocp_verify $? 'OAuth htpasswd'

oc get ClusterRoleBinding -n openshift-config | grep htpasswd-ocp-cluster-admin
ocp_verify $? 'ClusterRoleBinding htpasswd-ocp-cluster-admin'

oc get ClusterRole -n openshift-config | grep cluster-admin
oc get secret -n openshift-config | grep htpasswd-aro
ocp_verify $? 'ClusterRole cluster-admin'

### CERTIFICATE INGRESS #################
echo "\n=> Aro Certificate Ingress:" >> result.txt
oc describe configmap custom-ca -n openshift-config | grep ca-bundle.crt
ocp_verify $? 'Certificate custom-ca ca-bundle.crt'

oc get secret custom-cert-tls -n openshift-ingress
ocp_verify $? 'Secret cert-tls ca-bundle.crt'

### DYNATRACE #################
echo "\n=> Aro Dynatrace:" >> result.txt
oc get sa -n dynatrace | grep dynatrace-monitoring
ocp_verify $? 'Service Acoount dynatrace-monitoring'

oc get sa -n dynatrace | grep dynatrace-activegate
ocp_verify $? 'Service Acoount dynatrace-activegate'

oc get sa -n dynatrace | grep dynatrace-dynakube-oneagent
ocp_verify $? 'Service Acoount dynatrace-dynakube-oneagent'

oc get sa -n dynatrace | grep dynatrace-oneagent-csi-driver
ocp_verify $? 'Service Acoount dynatrace-oneagent-csi-driver'

oc get sa -n dynatrace | grep dynatrace-operator
ocp_verify $? 'Service Acoount dynatrace-operator'

oc get sa -n dynatrace | grep dynatrace-webhook
ocp_verify $? 'Service Acoount dynatrace-webhook'

oc get pods -n dynatrace | grep -i 'dynatrace-operator' | grep -i 'Running'
ocp_verify $? 'Operator dynatrace'

oc get pods -n dynatrace | grep -i 'dynatrace-oneagent-csi-driver' | grep -i 'Running'
ocp_verify $? 'DaemonSet dynatrace-csi'

oc get secret -n dynatrace | grep dynatrace-activegate
ocp_verify $? 'Secret dynatrace-activegate'

oc get secret -n dynatrace | grep dynatrace-dynakube-oneagent
ocp_verify $? 'Secret dynatrace-dynakube-oneagent'

oc get secret -n dynatrace | grep dynatrace-kubernetes-monitoring
ocp_verify $? 'Secret dynatrace-kubernetes-monitoring'

oc get secret -n dynatrace | grep dynatrace-monitoring
ocp_verify $? 'Secret dynatrace-monitoring'

oc get secret -n dynatrace | grep dynatrace-oneagent-csi-driver
ocp_verify $? 'Secret dynatrace-oneagent-csi-driver'

oc get secret -n dynatrace | grep dynatrace-webhook
ocp_verify $? 'Secret dynatrace-webhook'

oc get secret -n dynatrace | grep dynatrace-operator
ocp_verify $? 'Secret dynatrace-operator'

oc get pods -n dynatrace | grep -i 'worker-oneagent' | grep -i 'Running'
ocp_verify $? 'OneAgent Workers'

oc get pods -n dynatrace | grep -i 'master-oneagent' | grep -i 'Running'
ocp_verify $? 'OneAgent Masters'

oc describe clusterrole dynatrace-monitoring-cluster -n dynatrace | grep -i list | grep -i watch | grep -i get
ocp_verify $? 'ClusterRole "list,watch,get"'

### ROLEBINDING GRUPO OTI #################
echo "\n=> Rolebinding grupo de suporte OTI:" >> result.txt
oc get clusterrolebinding GRP-AZU-BRAD-OPTI-GECL-CLIA_oti
ocp_verify $? 'RoleBinding "GRP-AZU-BRAD-OPTI-GECL-CLIA_oti"'

### MACHINE AUTOSCALE #################
echo "\n=> Aro Machine AutoScaling:" >> result.txt
oc describe machineset -n openshift-machine-api | egrep 'brazilsouth1|brazilsouth2|brazilsouth3'
ocp_verify $? 'Machine AutoScaling "brazilsouth1,brazilsouth2,brazilsouth3"'

oc describe machineset -n openshift-machine-api | egrep 'cluster-api-autoscaler-node-group-min-size:2|cluster-api-autoscaler-node-group-max-size: 8'
ocp_verify $? 'Machine AutoScaling size "Min-02,Max-08"' 

### PROBE APPGATEWAY #################
echo "\n=> Aro Probe AppGateway:" >> result.txt
oc describe configmap probe-appgtw -n tools | grep 'PROBE APPLICATION GATEWAY APP'
ocp_verify $? 'Configmap appgtw' 

oc get pods -n tools | grep probe-appgtw
ocp_verify $? 'Probe appgtw' 

oc describe service probe-appgtw  -n tools | grep probe-appgtw
ocp_verify $? 'Service appgtw' 

oc describe route probe-appgtw-local -n tools | egrep 'edge|Allow|8080|Host'
ocp_verify $? 'Route Local "UrlHost,Edge,Port8080"' 

oc describe route probe-appgtw-master -n tools | egrep 'edge|Allow|8080|Host'
ocp_verify $? 'Route Master "UrlHost,Edge,Port8080"' 

### NAMESPACE DEVOPS #################
echo "\n=> Namespace DevopsLeap:" >> result.txt
oc get ns | grep devops-leap
ocp_verify $? 'Namespace Devops' 

oc get rolebinding -n devops-leap | grep bamboo-deploy-devops-leap
ocp_verify $? 'RoleBinding BambooDevops' 

oc describe quota  quota-devops-leap -n devops-leap | grep -i limits.cpu | grep -i 16
ocp_verify $? 'Quota "Limits-CPU,16"' 

oc describe quota  quota-devops-leap -n devops-leap | grep -i limits.memory | grep -i 32
ocp_verify $? 'Quota "Limits-Memory,32"' 

oc get networkpolicy -n devops-leap | grep netpolicy-devops
ocp_verify $? 'NetworkPolicy "allow,deny,labled"' 

### NAMESPACE AXWAY API #################
echo "\n=> Namespace AxwayApi:" >> result.txt
oc get ns | grep axway-api
ocp_verify $? 'Namespace Axway' 

oc get rolebinding -n axway-api | grep bamboo-deploy-axway-api
ocp_verify $? 'RoleBinding Axway-api' 

oc describe quota  quota-axway-api -n axway-api | grep -i limits.cpu | grep -i 10
ocp_verify $? 'Quota "Limits-CPU,10"' 

oc describe quota  quota-axway-api -n axway-api | grep -i limits.memory | grep -i 16
ocp_verify $? 'Quota "Limits-Memory,16"' 

oc get networkpolicy -n axway-api | grep netpolicy-axway-api
ocp_verify $? 'NetworkPolicy "allow,deny,labled"' 

### AZURE ARC BACKUP #################
echo "\n=> Aro Arc Backup:" >> result.txt
oc get pods -n azure-arc | grep extension
ocp_verify $? 'Azure Arc extension'

oc get pods -n azure-arc | grep operator
ocp_verify $? 'Azure Arc operator'

oc get pods -n azure-arc | grep logcollector
ocp_verify $? 'Azure Arc logcollector'

oc get pods -n azure-arc | grep metrics-agent
ocp_verify $? 'Azure Arc metrics-agent'

### ARO DEFENDER #################
echo "\n=> Aro Defender:" >> result.txt
oc get pod -n mdc | grep microsoft-defender-collectors
ocp_verify $? 'Azure Defender collectors'

oc get pod -n mdc | grep microsoft-defender-publisher
ocp_verify $? 'Azure Defender publisher'

### FLUENTD #################
echo "\n=> Aro Fluentd:" >> result.txt
oc get configmap -n openshift-logging | grep collector-fluentd-leap-elastic
ocp_verify $? 'Configmap collector-fluentd-elastic'

oc get daemonset -n openshift-logging | grep fluentd-leap-elastic
ocp_verify $? 'DaemonSet collector-fluentd-elastic'

oc get configmap -n openshift-logging | grep collector-fluentd-leap-kfc
ocp_verify $? 'Configmap collector-fluentd-Kafka'

oc get daemonset -n openshift-logging | grep fluentd-leap-kfc
ocp_verify $? 'DaemonSet collector-fluentd-Kafka'

oc get secret -n openshift-logging | grep collector-fluentd-leap-secret
ocp_verify $? 'Secret collector-fluentd'

## fim
sleep 02

cat result.txt
sleep 02
