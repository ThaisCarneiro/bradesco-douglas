#!/bin/bash

set -x
set +e

# Global variables
PATH=$PATH:/root/openshift:/root/infracost

# CRIAÇÃO DA NAMESPACE PADRÃO DA AXWAY (axway-api)

oc create namespace axway-api
sleep 30
oc create rolebinding bamboo-deploy-axway-api --clusterrole=admin --serviceaccount=tools:bamboo -n axway-api
oc create rolebinding axway-deploy-axway-api --clusterrole=admin --serviceaccount=tools:axway -n axway-api
oc create quota quota-axway-api --hard=cpu=10000m,memory=16384Mi,limits.cpu=10000m,limits.memory=16384Mi --scopes='NotTerminating' -n axway-api
oc create rolebinding GRP-AZU-BRAD-ARTI-DEOC-DSCA-axway-api --clusterrole=view --group=289ae7d3-0a03-4677-8583-531643b3fe34 -n axway-api
oc create rolebinding GRP-AZU-BRAD-ENGE-EPES-ESNA-axway-api --clusterrole=view --group=c8187da3-d377-4c6d-8754-ecd04e4a4132 -n axway-api
oc label namespaces axway-api team={{ aro_cluster_name }} --overwrite=true

cat << EOF | oc apply -f -
kind: LimitRange
apiVersion: v1
metadata:
  name: limit-range-axway-api
  namespace: axway-api
spec:
  limits:
  - type: Container
    default:
      cpu: 200m
      memory: 256Mi
    defaultRequest:
      cpu: 100m
      memory: 128Mi
---
kind: NetworkPolicy
apiVersion: networking.k8s.io/v1
metadata:
  name: netpolicy-axway-api-all-route-allow
  namespace: axway-api
spec:
  podSelector: {}
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          network.openshift.io/policy-group: ingress
  policyTypes:
  - Ingress
---
kind: NetworkPolicy
apiVersion: networking.k8s.io/v1
metadata:
  name: netpolicy-axway-api-all-route-deny
  namespace: axway-api
spec:
  podSelector: {}
  policyTypes:
  - Ingress
---
kind: NetworkPolicy
apiVersion: networking.k8s.io/v1
metadata:
  name: netpolicy-axway-api-all-route-labled
  namespace: axway-api
spec:
  podSelector: {}
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          team: {{ aro_cluster_name }}
  egress:
  - {}
  policyTypes:
  - Ingress
  - Egress
EOF
