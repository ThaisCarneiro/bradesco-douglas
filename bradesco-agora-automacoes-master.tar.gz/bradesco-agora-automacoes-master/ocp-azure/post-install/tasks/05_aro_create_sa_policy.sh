#!/bin/bash

set +x
PATH=$PATH:/root/openshift:/root/infracost

oc get namespace tools 
if [ "$?" -ne 0 ];then
    echo "Creating the namespace... \n"
    oc new-project tools
    if [ "$?" -eq 0 ];then
        echo "Command oc new-project - OK\n"
    else
        echo "Error to execute command oc new-project\n"
        exit 171
    fi
    sleep 05
else
    echo "Namespace tools found!\n"
fi

############### SA Axway
# Passo 03 - Create user
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/axway/service_account.yaml
sleep 05
############### SA Bamboo
# Passo 01 - Create user
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/bamboo/service_account.yaml
sleep 05

############### SA Bamboo
# Passo 02 - get token
TOKEN=$(oc extract secret/`oc describe sa bamboo -n tools | awk '/token/ {print $NF}'` --keys=token --to=-)
if [ -z "$TOKEN" ];then
    echo "Token do SA bamboo nao encontrado!"
    exit 171
fi

############### SA Bamboo
# Passo 03 - az login with SP-ARO-4250-PRD
az login --service-principal -u {{ aro_user_keyvault002 }} -p {{ aro_secret_keyvault002 }} --tenant {{ aro_tenant_id }}
if [ $? -eq 0 ];then
    echo "Command az login - OK\n"
else
    echo "Error to execute command az login\n"
    exit 171
fi

az account set --subscription {{ aro_subscription_id_keyvault002 }}
if [ $? -eq 0 ];then
    echo "Command az account set - OK\n"
else
    echo "Error to execute command az account set\n"
    exit 171
fi

az keyvault secret set --vault-name kvazuprbraaro002 --name "bamboo-{{ aro_cluster_name }}" --value "$TOKEN";
if [ $? -eq 0 ];then
    echo "Command az keyvault secret set - OK\n"
else
    echo "Error to execute command az keyvault secret set\n"
    exit 171
fi

############### SA Bamboo
# Passo 04 - az login with VRA user
az login --service-principal -u {{ aro_client_id }} -p {{ aro_client_secret }} --tenant {{ aro_tenant_id }} > /tmp/$$_output 2>&1
if [ $? -eq 0 ];then
    echo "Command az login - OK\n"
else
    echo "Error to execute command az login\n"
    cat /tmp/$$_output
    exit 171
fi

az account set --subscription {{ aro_subscription_id }}
if [ $? -eq 0 ];then
    echo "Command az account set - OK\n"
else
    echo "Error to execute command az account set\n"
    exit 171
fi
