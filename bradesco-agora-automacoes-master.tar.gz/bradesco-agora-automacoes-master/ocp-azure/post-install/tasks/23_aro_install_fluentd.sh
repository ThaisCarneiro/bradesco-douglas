#!/bin/bash
#
# Script by: squad infra-base
#
# Global variables

PATH=$PATH:/root/openshift:/root/infracost

set +ex

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

# Main
print_ts "START - AroInstallFluentd"

#1 Config de login
az login --service-principal -u {{ aro_client_id }} -p {{ aro_client_secret }} --tenant {{ aro_tenant_id }} > /tmp/$$_output 2>&1
if [ $? -eq 0 ];then
    print_ts "Command az login - OK"
else
    print_ts "Error to execute command az login"
    cat /tmp/$$_output
    exit 171
fi

az account set --subscription {{ aro_subscription_id }}
if [ $? -eq 0 ];then
    print_ts "Command az account set - OK"
else
    print_ts "Error to execute command az account set"
    exit 171
fi

oc login -u admin -p {{ aro_ocp_admin_password }} https://api.{{ aro_cluster_name }}.{{ aro_domain_name }}:6443 --insecure-skip-tls-verify
if [ $? -eq 0 ];then
    print_ts "Command oc login -u admin - OK"
else
    print_ts "Error to execute command oc login -u admin"
    exit 171
fi

#2 Create secret

export HOST_ELASTICSEARCH_APPS=$(print_ts {{ aro_host_elasticsearch_apps }} | base64 -w 0)
export USERNAME_ELASTISEARCH_APPS=$(print_ts {{ aro_username_elastisearch_apps }} | base64 -w 0)
export ELASTICSEARCH_LEAP_PASSWORD=$(az keyvault secret show --vault-name {{ aro_keyvault_elasticsearch_apps }} --name app-elastic-pwd --query "value" -o tsv | base64 -w 0)
export BROKER_KAFKA_APPS=$(print_ts {{ aro_broker_kafka_apps }} | base64 -w 0)
export USERNAME_KAFKA_APPS=$(print_ts {{ aro_username_kafka_apps }}  | base64 -w 0)
export TOPIC_KAFKA_APPS=$(print_ts {{ aro_topic_kafka_apps }} | base64 -w 0)
export KAFKA_LEAP_PASSWORD=$(az keyvault secret show --vault-name {{ aro_keyvault_kafka_apps }} --name API-secret --query "value" -o tsv | base64 -w 0)

cat <<CREATESECRET | oc apply -f -
kind: Secret
apiVersion: v1
metadata:
  name: collector-fluentd-leap-secret
  namespace: openshift-logging
data:
  ELASTICSEARCH_LEAP_HOST: $HOST_ELASTICSEARCH_APPS
  ELASTICSEARCH_LEAP_PASSWORD: $ELASTICSEARCH_LEAP_PASSWORD
  ELASTICSEARCH_LEAP_USER: $USERNAME_ELASTISEARCH_APPS
  KAFKA_LEAP_HOST: $BROKER_KAFKA_APPS
  KAFKA_LEAP_USER: $USERNAME_KAFKA_APPS
  KAFKA_LEAP_PASSWORD: $KAFKA_LEAP_PASSWORD
  KAFKA_LEAP_TOPIC: $TOPIC_KAFKA_APPS
type: Opaque
CREATESECRET

if [ $? -eq 0 ];then
    print_ts "Command oc create secret - OK"
    sleep 20
else
    print_ts "Error to execute command oc create secret"
    exit 171
fi


#3 Create ConfigMap - elastic and kafka
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroInstallFluentd/collector-fluentd-leap-elastic-cm.yaml
if [ $? -eq 0 ];then
    print_ts "Command to configmap elastic: oc apply  - OK"
else
    print_ts "Error to execute command to configmap elastic: oc apply"
    exit 171
fi

oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroInstallFluentd/collector-fluentd-leap-kfc-cm.yaml
if [ $? -eq 0 ];then
    print_ts "Command to configmap kafka: oc apply  - OK"
else
    print_ts "Error to execute command to configmap kafka: oc apply"
    exit 171
fi

sleep 30

#4 Create DaemonSet - elastic and kafka
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroInstallFluentd/collector-fluentd-leap-elastic-ds.yaml
if [ $? -eq 0 ];then
    print_ts "Command to DaemonSet elastic: oc apply  - OK"
else
    print_ts "Error to execute command to DaemonSet elastic: oc apply"
    exit 171
fi

oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroInstallFluentd/collector-fluentd-leap-kfc-ds.yaml
if [ $? -eq 0 ];then
    print_ts "Command to DaemonSet kafka: oc apply  - OK"
else
    print_ts "Error to execute command to DaemonSet kafka: oc apply"
    exit 171
fi

sleep 30

print_ts "FINISH - AroInstallFluentd"
