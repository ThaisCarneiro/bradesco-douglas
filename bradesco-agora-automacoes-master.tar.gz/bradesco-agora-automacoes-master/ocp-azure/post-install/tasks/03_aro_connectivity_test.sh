#!/bin/bash

PATH=$PATH:/root/openshift:/root/infracost

### New Workload
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/new_application_httpd.yaml
sleep 05
oc get pod -n default
sleep 05

### New Storage
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/pv_exemplo.yaml
sleep 10
oc get pv -A
sleep 05
oc get nodes
sleep 05

### Remove Workload
oc delete -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/new_application_httpd.yaml
sleep 05
oc get pod -n default
sleep 05

### Remove Storage
oc delete -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/pv_exemplo.yaml
sleep 05
