#!/bin/bash

PATH=$PATH:/root/openshift:/root/infracost

### Create NS
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynatrace-namespace.yaml
oc get ns | grep dynatrace
sleep 05

### Create SA
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynatrace-monitoring-service-account.yaml
sleep 10

oc get sa -n dynatrace | grep dynatrace-monitoring
sleep 05

### Install Operator v.10
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynatrace_install_v010.yaml
sleep 50

### Patch SCC system:serviceaccount: dynatrace
oc patch scc dynatrace-activegate --type merge -p '{"users":["system:serviceaccount:dynatrace:dynatrace-activegate","system:serviceaccount:dynatrace:dynatrace-kubernetes-monitoring","system:serviceaccount:dynatrace:dynatrace-oneagent-csi-driver"]}'
oc patch scc dynatrace-dynakube-oneagent-privileged --type merge -p '{"users":["system:serviceaccount:dynatrace:dynatrace-dynakube-oneagent-privileged","system:serviceaccount:dynatrace:dynatrace-oneagent-csi-driver"]}'
oc patch scc dynatrace-dynakube-oneagent-unprivileged --type merge -p '{"users":["system:serviceaccount:dynatrace:dynatrace-dynakube-oneagent-unprivileged","system:serviceaccount:dynatrace:dynatrace-oneagent-csi-driver"]}'
oc patch scc dynatrace-operator --type merge -p '{"users":["system:serviceaccount:dynatrace:dynatrace-operator","system:serviceaccount:dynatrace:dynatrace-oneagent-csi-driver"]}'
oc patch scc dynatrace-webhook --type merge -p '{"users":["system:serviceaccount:dynatrace:dynatrace-webhook","system:serviceaccount:dynatrace:dynatrace-oneagent-csi-driver"]}'
sleep 15

### Install DaemonSet CSI
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynatrace-csi_10_0.yaml
sleep 40

### Install Secret OneAgent
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynatrace-secret-oneagent-{{ aro_environment }}.yaml
sleep 10

### Install DaemonSet OneAgent
echo {{ aro_macro_domain }}
echo {{ aro_resource_group }}
echo {{ aro_cluster_name }}
sleep 3

### Variavel worker
cat cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-worker.yaml | grep api-monitoring-cluster-name
cat cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-worker.yaml | grep host-group
sleep 5
sed -i "s/XXXmacro_dominioXXX/{{ aro_macro_domain }}/g" cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-worker.yaml
sed -i "s/XXXresource_groupXXX/{{ aro_resource_group }}/g" cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-worker.yaml
sed -i "s/XXXname_clusterXXX/{{ aro_cluster_name }}/g" cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-worker.yaml
sleep 5
cat cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-worker.yaml | grep api-monitoring-cluster-name
cat cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-worker.yaml | grep host-group
sleep 5

### Variavel master
cat cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-master.yaml | grep api-monitoring-cluster-name
cat cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-master.yaml | grep host-group
sleep 5
sed -i "s/XXXmacro_dominioXXX/{{ aro_macro_domain }}/g" cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-master.yaml
sed -i "s/XXXresource_groupXXX/{{ aro_resource_group }}/g" cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-master.yaml
sed -i "s/XXXname_clusterXXX/{{ aro_cluster_name }}/g" cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-master.yaml
sleep 5
cat cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-master.yaml | grep api-monitoring-cluster-name
cat cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-master.yaml | grep host-group

### Aplicar worker e master oneagent-dynakube
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-worker.yaml
sleep 120
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynakube-{{ aro_environment }}-master.yaml
sleep 120

### Check Resource Dynatrace
oc get all -n dynatrace
sleep 5

### Install ClusterRole
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/dynatrace/dynatrace-monitoring-cluster.yaml
sleep 5

### Project Dynatrace
oc project dynatrace

TOKENdv=dt0c01.B3V3I3RGJIWKYDP2YGRLMQ64.VSSYUH4SDOSLM3HISMQ4HAFSZQ7IFZ6KIMJPYINOFFM6JM6P2AYHGEZSZV6XPLF4
TOKENho=dt0c01.YCPLRJY23KXF2JZRZ3WAJXXQ.LMLEJGPV4QPSBV2ACWHFPJXOI2BBQA5BJIZKXDPT2QNDO74LWNALTFO46LO6OJNG
TOKENpr=dt0c01.NEZODFPEWDKGXR2QQA263FFI.62HHUUVSFBE3LQ3KGEIMDXOYD6PJA5LM72KJFXA65K4IQJ45DBYFB3V7UC7ZKPJH
TENANTdv='https://dynatrace.ti.net.bradesco.com.br/e/facd5528-9eb9-4435-a909-434c2263b0da/api/v2/settings/objects'
TENANTho='https://dynatrace.hml.net.bradesco.com.br/e/ad544654-6b96-4f0c-b08a-2f6510b30384/api/v2/settings/objects'
TENANTpr='https://dynatrace.net.bradesco.com.br/e/050dfda1-e7ed-4b27-af7d-fff3b69bfc14/api/v2/settings/objects'

sleep 3

### Token dynatrace-kubernetes-monitoring
# tokensecret=`oc get secret $(oc get sa dynatrace-monitoring -o jsonpath=''{.secrets[0].name}' -n dynatrace) -o jsonpath=''{.data.token}'' -n dynatrace | base64 --decode`
secretsa=`oc get secret -n dynatrace | grep -i dynatrace-kubernetes-monitoring-token | head -1 | awk '{print $1}'`
tokensecret=`oc get secret $secretsa -n dynatrace -o yaml | grep token | awk '{print $2}' | head -1 | base64 -d`

### Integration API dynatrace send Token
curl -kv $TENANT{{ aro_environment }} \
-X POST \
-H 'Accept: application/json; charset=utf-8' \
-H 'Content-Type: application/json; charset=utf-8' \
-H "Authorization: Api-Token $TOKEN{{ aro_environment }}" \
-d '[{"schemaId":"builtin:cloud.kubernetes","value":{"enabled":true,"label":"{{ aro_macro_domain }}","clusterIdEnabled":false,"endpointUrl":"{{ aro_cluster_api_url }}","authToken":"$tokensecret","activeGateGroup":null,"certificateCheckEnabled":false,"hostnameVerificationEnabled":true,"cloudApplicationPipelineEnabled":true,"pvcMonitoringEnabled":false,"openMetricsPipelineEnabled":false,"openMetricsBuiltinEnabled":false,"eventProcessingActive":true,"filterEvents":false}}]'

# NameSpace Dynatrace OK
# ServiceAccount OK
# Operator v10 OK
# Patch SCC system:serviceaccount OK
# DaemonSet CSI OK
# Secret OneAgent OK
# DaemonSet OneAgent OK
# ClusterRole OK
# Imput Cluster API OK
