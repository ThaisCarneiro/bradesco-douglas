#!/bin/bash 

set -x
set +e

# Global variables
PATH=$PATH:/root/openshift:/root/infracost

# CRIAÇÃO DA NAMESPACE PADRÃO DO TIME DE DEVOPS (devops-leap)

oc create namespace devops-leap
sleep 30
oc create rolebinding bamboo-deploy-devops-leap --clusterrole=aro-deploy-custom-role --serviceaccount=tools:bamboo -n devops-leap
oc create quota quota-devops-leap --hard=cpu=4000m,memory=8192Mi,limits.cpu=4000m,limits.memory=8192Mi --scopes='NotTerminating' -n devops-leap
oc create rolebinding GRP-AZU-BRAD-ARTI-DEOC-DSCA-devops-leap --clusterrole=view --group=289ae7d3-0a03-4677-8583-531643b3fe34 -n devops-leap
oc label namespaces devops-leap team='{{ aro_cluster_name }}' --overwrite=true

cat << EOF | oc apply -f -
kind: LimitRange
apiVersion: v1
metadata:
  name: limit-range-devops-leap
  namespace: devops-leap
spec:
  limits:
  - type: Container
    default:
      cpu: 200m
      memory: 256Mi
    defaultRequest:
      cpu: 100m
      memory: 128Mi
---
kind: NetworkPolicy
apiVersion: networking.k8s.io/v1
metadata:
  name: netpolicy-devops-leap-all-route-allow
  namespace: devops-leap
spec:
  podSelector: {}
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          network.openshift.io/policy-group: ingress
  policyTypes:
  - Ingress
---
kind: NetworkPolicy
apiVersion: networking.k8s.io/v1
metadata:
  name: netpolicy-devops-leap-all-route-deny
  namespace: devops-leap
spec:
  podSelector: {}
  policyTypes:
  - Ingress
---
kind: NetworkPolicy
apiVersion: networking.k8s.io/v1
metadata:
  name: netpolicy-devops-leap-all-route-labled
  namespace: devops-leap
spec:
  podSelector: {}
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          team: {{ aro_cluster_name }}
  egress:
  - {}
  policyTypes:
  - Ingress
  - Egress
EOF
