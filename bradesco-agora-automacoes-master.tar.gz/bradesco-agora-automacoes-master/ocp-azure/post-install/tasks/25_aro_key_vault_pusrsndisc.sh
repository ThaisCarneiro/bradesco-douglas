#!/bin/bash

set +ex

PATH=$PATH:/root/openshift:/root/infracost

############### SA pusrsndisc 
# Passo 01 - Create user
oc create sa pusrsndisc -n tools
oc adm policy add-cluster-role-to-user cluster-reader -z pusrsndisc -n tools
sleep 05

############### SA pusrsndisc
# Passo 02 - get token
TOKEN=$(oc get secret $(oc describe sa pusrsndisc -n tools | grep pusrsndisc-token | awk '{print $NF}' | head -1) -o jsonpath='{.data.token}' -n tools | base64 --decode)
if [ -z $TOKEN ];then
    echo "Token do SA pusrsndisc nao encontrado!"
    exit 171
fi

############### SA pusrsndisc
# Passo 03 - az login with SP-ARO-4250-PRD
az login --service-principal -u {{ aro_user_keyvault002 }} -p {{ aro_secret_keyvault002 }} --tenant {{ aro_tenant_id }}
if [ $? -eq 0 ];then
    echo "Command az login - OK"
else
    echo "Error to execute command az login"
    exit 171
fi

az account set --subscription {{ aro_subscription_id_keyvault002 }}
if [ $? -eq 0 ];then
    echo "Command az account set - OK"
else
    echo "Error to execute command az account set"
    exit 171
fi

az keyvault secret set --vault-name kvazuprbraaro002 --name "pusrsndisc-{{ aro_cluster_name }}" --value "$TOKEN";
if [ $? -eq 0 ];then
    echo "Command az keyvault secret set - OK"
else
    echo "Error to execute command az keyvault secret set"
    exit 171
fi

############### SA pusrsndisc
# Passo 04 - az login with VRA user
az login --service-principal -u {{ aro_client_id }} -p {{ aro_client_secret }} --tenant {{ aro_tenant_id }} > /tmp/$$_output 2>&1
if [ $? -eq 0 ];then
    echo "Command az login - OK"
else
    echo "Error to execute command az login"
    cat /tmp/$$_output
    exit 171
fi

az account set --subscription {{ aro_subscription_id }}
if [ $? -eq 0 ];then
    echo "Command az account set - OK"
else
    echo "Error to execute command az account set"
    exit 171
fi
