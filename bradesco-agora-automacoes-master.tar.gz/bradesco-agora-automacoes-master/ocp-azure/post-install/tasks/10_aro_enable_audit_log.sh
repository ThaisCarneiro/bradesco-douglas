#!/bin/bash

set +x

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

# Main
PATH=$PATH:/root/openshift:/root/infracost
print_ts 'Habilitando o audit log...'
print_ts 'Configurando o apiserver com spec.audit.profile = WriteRequestBodies...'
oc patch apiserver cluster -p '{"spec": {"audit": {"profile": "WriteRequestBodies"}}}' --type merge

if [ $? -eq 0 ]; then
    print_ts 'Command oc patch apiserver cluster - OK'
else
    print_ts 'Error to execute command oc patch apiserver cluster'
    exit 171
fi

print_ts 'Aplicando config ClusterLogForwarder.yaml...'
oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroEnableAuditLog/ClusterLogForwarder_v3.yaml
if [ $? -eq 0 ]; then
    print_ts 'Command oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroEnableAuditLog/ClusterLogForwarder_v3.yaml OK'
else
    print_ts 'Error to execute command oc apply -f cloud-portal-squad-iac-openshift/Aro_posinstall/yamls/AroEnableAuditLog/ClusterLogForwarder_v3.yaml'
    exit 171
fi
sleep 60
