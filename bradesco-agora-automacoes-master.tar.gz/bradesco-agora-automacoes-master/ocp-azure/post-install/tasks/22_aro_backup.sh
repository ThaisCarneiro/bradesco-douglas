#!/bin/bash
#
# Script by: squad infra-base
#
# Global variables
export STORAGE_ACCOUNT_SUBSCRIPTION=717cce4c-28a1-4d71-ba56-17c0d44ba2ad

PATH=$PATH:/root/openshift:/root/infracost

set +ex

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

# Main
print_ts "START - ARO BACKUP"

#1 Config de login
az login --service-principal -u {{ aro_client_id }} -p {{ aro_client_secret }} --tenant {{ aro_tenant_id }} > /tmp/$$_output 2>&1
if [ $? -eq 0 ];then
    print_ts "Command az login - OK"
else
    print_ts "Error to execute command az login"
    cat /tmp/$$_output
    exit 171
fi

# Subscription de GERENCIAMENTO
az account set --subscription $STORAGE_ACCOUNT_SUBSCRIPTION
if [ $? -eq 0 ];then
    print_ts "Command az account set - OK"
else
    print_ts "Error to execute command az account set"
    exit 171
fi

oc login -u admin -p {{ aro_ocp_admin_password }} https://api.{{ aro_cluster_name }}.{{ aro_domain_name }}:6443 --insecure-skip-tls-verify
if [ $? -eq 0 ];then
    print_ts "Command oc login -u admin - OK"
else
    print_ts "Error to execute command oc login -u admin"
    exit 171
fi

# Set Variables
export STORAGE_ACCOUNT_RESOURCE_GROUP=rgprgerencaro
export STORAGE_ACCOUNT_NAME=stazuprbraarobkpvelero
export STORAGE_ACCOUNT_BLOB_CONTAINER={{ aro_cluster_name }}
{% raw %}
export AZURE_TENANT_ID=$(oc get secret/azure-credentials -n kube-system --template='{{.data.azure_tenant_id | base64decode}}')
export AZURE_CLIENT_ID=$(oc get secret/azure-credentials -n kube-system --template='{{.data.azure_client_id | base64decode}}')
export AZURE_CLIENT_SECRET=$(oc get secret/azure-credentials -n kube-system --template='{{.data.azure_client_secret | base64decode}}')
{% endraw %}
export STORAGE_ACCOUNT_ACCESS_KEY=$(az storage account keys list --account-name $STORAGE_ACCOUNT_NAME --query "[?keyName == 'key1'].value" -o tsv)

#2 Create namespace and secret
if [ "$(oc get namespace openshift-adp --output jsonpath={.metadata.name} 2> /dev/null)" = "openshift-adp" ];then
    print_ts "Namespace openshift-adp found!"
else
    oc create namespace openshift-adp
    if [ $? -eq 0 ];then
        print_ts "Command oc new-project openshift-adp - OK"
    else
        print_ts "Error to execute command oc new-project openshift-adp"
        exit 171
    fi
fi

cat << EOF > ./credentials-velero
AZURE_SUBSCRIPTION_ID=$STORAGE_ACCOUNT_SUBSCRIPTION
AZURE_RESOURCE_GROUP=rgprgerencaro
AZURE_STORAGE_ACCOUNT=$STORAGE_ACCOUNT_NAME
AZURE_TENANT_ID=$AZURE_TENANT_ID
AZURE_CLIENT_ID=$AZURE_CLIENT_ID
AZURE_CLIENT_SECRET=$AZURE_CLIENT_SECRET
AZURE_STORAGE_ACCOUNT_ACCESS_KEY=$STORAGE_ACCOUNT_ACCESS_KEY
AZURE_CLOUD_NAME=AzurePublicCloud
EOF

oc create secret generic cloud-credentials-azure -n openshift-adp --from-file cloud=credentials-velero
if [ $? -eq 0 ];then
    print_ts "Command oc create secret - OK"
else
    print_ts "Error to execute command oc create secret"
    exit 171
fi

#3 networkRules
export MASTERPROFILE_SUBNETID=$(az aro show --name {{ aro_cluster_name }} -g {{ aro_resource_group }} --subscription {{ aro_subscription_id }} --query masterProfile.subnetId -o tsv)
export WORKERPROFILES_SUBNETID=$(az aro show --name {{ aro_cluster_name }} -g {{ aro_resource_group }} --subscription {{ aro_subscription_id }} --query workerProfiles[0].subnetId -o tsv)

az storage account network-rule add -g $STORAGE_ACCOUNT_RESOURCE_GROUP -n $STORAGE_ACCOUNT_NAME --subnet $MASTERPROFILE_SUBNETID
if [ $? -eq 0 ];then
    print_ts "Command az storage account network-rule add MASTERPROFILE_SUBNETID OK"
else
    print_ts "Error to execute command az storage account network-rule add MASTERPROFILE_SUBNETID"
    exit 171
fi

az storage account network-rule add -g $STORAGE_ACCOUNT_RESOURCE_GROUP -n $STORAGE_ACCOUNT_NAME --subnet $WORKERPROFILES_SUBNETID
if [ $? -eq 0 ];then
    print_ts "Command az storage account network-rule add WORKERPROFILES_SUBNETID OK"
else
    print_ts "Error to execute command az storage account network-rule add WORKERPROFILES_SUBNETID"
    exit 171
fi

sleep 20


#4 Create container
az storage container create -n {{ aro_cluster_name }} --account-name $STORAGE_ACCOUNT_NAME  --public-access off
if [ $? -eq 0 ];then
    print_ts "Command az storage container create - OK"
else
    print_ts "Error to execute command az storage container create"
    exit 171
fi

#5 install-oadp
#cat << EOF > ./operatorgroup
cat <<INSTALLOP | oc apply -f -
apiVersion: operators.coreos.com/v1
kind: OperatorGroup
metadata:
  name: openshift-adp-aro
  namespace: openshift-adp
spec:
  targetNamespaces:
  - openshift-adp
INSTALLOP

#cat << EOF > ./oadpsubscription
cat <<INSTALLSUB | oc apply -f -
apiVersion: operators.coreos.com/v1alpha1
kind: Subscription
metadata:
  name: redhat-oadp-operator
  namespace: openshift-adp 
spec:
  channel: stable-1.1
  name: redhat-oadp-operator
  source: redhat-operators
  sourceNamespace: openshift-marketplace
  installPlanApproval: Manual
INSTALLSUB

sleep 30

oc patch installplan $(oc get ip -n openshift-adp -o=jsonpath='{.items[?(@.spec.approved==false)].metadata.name}') -n openshift-adp --type merge --patch '{"spec":{"approved":true}}'
if [ $? -eq 0 ];then
    print_ts "Command oc patch installplan - OK"
else
    print_ts "Error to execute command oc patch installplan"
    exit 171
fi

sleep 60

#6 install DPA
#cat << EOF > ./dataprotapp.yaml
cat <<DEPLOYDPA | oc apply -f -
apiVersion: oadp.openshift.io/v1alpha1
kind: DataProtectionApplication
metadata:
  name: dpa-openshift-adp
  namespace: openshift-adp
spec:
  configuration:
    velero:
      defaultPlugins:
        - azure
        - openshift 
        - csi
    restic:
      enable: true 
  backupLocations:
    - velero:
        config:
          resourceGroup: $STORAGE_ACCOUNT_RESOURCE_GROUP
          storageAccount: $STORAGE_ACCOUNT_NAME
          subscriptionId: $STORAGE_ACCOUNT_SUBSCRIPTION
          storageAccountKeyEnvVar: AZURE_STORAGE_ACCOUNT_ACCESS_KEY
        credential:
          key: cloud
          name: cloud-credentials-azure  
        provider: azure
        default: true
        objectStorage:
          bucket: $STORAGE_ACCOUNT_BLOB_CONTAINER
          prefix: velero 
  snapshotLocations: 
    - velero:
        config:
          resourceGroup: $STORAGE_ACCOUNT_RESOURCE_GROUP
          subscriptionId: $STORAGE_ACCOUNT_SUBSCRIPTION
          incremental: "true"
        name: default
        provider: azure
DEPLOYDPA

#6 Configure schedule
cat <<DEPLOYSCHEDULE | oc apply -f -
apiVersion: velero.io/v1
kind: Schedule
metadata:
  name: schedule
  namespace: openshift-adp
spec:
  schedule: ''0 6 * * *''
  template:
    csiSnapshotTimeout: 10m0s
    defaultVolumesToRestic: true
    excludedNamespaces:
      - azure-arc
      - azure-arc-release
      - default
      - dynatrace
      - gatekeeper-system
      - k8s-secrets-store-csi
      - kube-node-lease
      - kube-public
      - kube-system
      - mdc
      - open-cluster-management-addon-observability
      - open-cluster-management-agent
      - open-cluster-management-agent-addon
      - openshift
      - openshift-adp
      - openshift-apiserver
      - openshift-apiserver-operator
      - openshift-authentication
      - openshift-authentication-operator
      - openshift-azure-logging
      - openshift-azure-operator
      - openshift-cloud-controller-manager
      - openshift-cloud-controller-manager-operator
      - openshift-cloud-credential-operator
      - openshift-cloud-network-config-controller
      - openshift-cluster-csi-drivers
      - openshift-cluster-machine-approver
      - openshift-cluster-node-tuning-operator
      - openshift-cluster-samples-operator
      - openshift-cluster-storage-operator
      - openshift-cluster-version
      - openshift-compliance
      - openshift-config
      - openshift-config-managed
      - openshift-config-operator
      - openshift-console
      - openshift-console-operator
      - openshift-console-user-settings
      - openshift-controller-manager
      - openshift-controller-manager-operator
      - openshift-dns
      - openshift-dns-operator
      - openshift-etcd
      - openshift-etcd-operator
      - openshift-file-integrity
      - openshift-host-network
      - openshift-image-registry
      - openshift-infra
      - openshift-ingress
      - openshift-ingress-canary
      - openshift-ingress-operator
      - openshift-insights
      - openshift-kni-infra
      - openshift-kube-apiserver
      - openshift-kube-apiserver-operator
      - openshift-kube-controller-manager
      - openshift-kube-controller-manager-operator
      - openshift-kube-scheduler
      - openshift-kube-scheduler-operator
      - openshift-kube-storage-version-migrator
      - openshift-kube-storage-version-migrator-operator
      - openshift-logging
      - openshift-machine-api
      - openshift-machine-config-operator
      - openshift-managed-upgrade-operator
      - openshift-marketplace
      - openshift-monitoring
      - openshift-multus
      - openshift-network-diagnostics
      - openshift-network-operator
      - openshift-node
      - openshift-oauth-apiserver
      - openshift-openstack-infra
      - openshift-operator-lifecycle-manager
      - openshift-operators
      - openshift-operators-redhat
      - openshift-ovirt-infra
      - openshift-sdn
      - openshift-service-ca
      - openshift-service-ca-operator
      - openshift-user-workload-monitoring
      - openshift-vsphere-infra
    includedNamespaces:
      - '*'
    ttl: 96h0m0s
DEPLOYSCHEDULE

#5 Subscription Return
az account set --subscription {{ aro_subscription_id }}
if [ $? -eq 0 ];then
    print_ts "Command az account set - OK"
else
    print_ts "Error to execute command az account set"
    exit 171
fi

print_ts "FINISH - ARO BACKUP"
