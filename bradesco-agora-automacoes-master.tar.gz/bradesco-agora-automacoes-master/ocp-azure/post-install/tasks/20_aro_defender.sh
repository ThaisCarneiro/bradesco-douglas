#!/bin/bash

PATH=$PATH:/root/openshift:/root/infracost
set +ex

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

# Main
print_ts "START - AZ ARO DEFENDER"

#1 Config de login
az login --service-principal -u {{ aro_client_id }} -p {{ aro_client_secret }} --tenant {{ aro_tenant_id }} > /tmp/$$_output 2>&1
if [ $? -eq 0 ];then
    print_ts "Command az login - OK"
else
    print_ts "Error to execute command az login"
    cat /tmp/$$_output
    exit 171
fi

az account set --subscription {{ aro_subscription_id }}
if [ $? -eq 0 ];then
    print_ts "Command az account set - OK"
else
    print_ts "Error to execute command az account set"
    exit 171
fi

oc login -u admin -p {{ aro_ocp_admin_password }} https://api.{{ aro_cluster_name }}.{{ aro_domain_name }}:6443 --insecure-skip-tls-verify
if [ $? -eq 0 ];then
    print_ts "Command oc login -u admin - OK"
else
    print_ts "Error to execute command oc login -u admin"
    exit 171
fi

#2 Install Azure Arc k8s CLI extensions
print_ts "Checking if you have up-to-date Azure Arc AZ CLI connectedk8s extension..."
# az extension show --name "connectedk8s" &> extension_output
#if cat extension_output | grep -q "not installed"; then
if [ $(az extension show --name "connectedk8s" 2>&1 | grep "is not installed" | wc -l) -ne 0 ]; then
    print_ts "Installing connectedk8s extension..."
    az extension add --name "connectedk8s" --yes
else
    print_ts "Updating connectedk8s extension..."
    az extension update --name "connectedk8s"
fi

print_ts "Checking if you have up-to-date Azure Arc AZ CLI k8s-configuration extension..."
#az extension show --name "k8s-configuration" &> extension_output
#if cat extension_output | grep -q "not installed"; then
if [ $(az extension show --name "k8s-configuration" 2>&1 | grep "is not installed" | wc -l) -ne 0 ]; then
    print_ts "Installing k8s-configuration extension..."
    az extension add --name "k8s-configuration" --yes
else
    print_ts "Updating k8s-configuration extension..."
    az extension update --name "k8s-configuration"
fi

print_ts "Checking if you have up-to-date Azure Arc AZ CLI k8s-extension extension..."
#az extension show --name "k8s-extension" &> extension_output
#if cat extension_output | grep -q "not installed"; then
if [ $(az extension show --name "k8s-extension" 2>&1 | grep "is not installed" | wc -l) -ne 0 ]; then
    print_ts "Installing k8s-extension extension..."
    az extension add --name "k8s-extension" --yes
else
    print_ts "Updating k8s-extension extension..."
    az extension update --name "k8s-extension"
fi

#3 Create resource group and provider register
if [ $(az group list --query '[].name' -o tsv | grep -w rg{{ aro_environment }}defenderaro | wc -l) -eq 0 ];then
    print_ts "Resource group rg{{ aro_environment }}defenderaro not found!"
    print_ts "Creating the resource group... "
    az group create --location eastus --name rg{{ aro_environment }}defenderaro
    if [ $? -eq 0 ];then
        print_ts "Command az group create - OK"
    else
        print_ts "Error to execute command group create"
        exit 171
    fi
else
    print_ts "Resource group rg{{ aro_environment }}defenderaro found!"
fi

az provider register -n Microsoft.Kubernetes --wait
if [ $? -eq 0 ];then
    print_ts "Command az provider register -n Microsoft.Kubernetes - OK"
else
    print_ts "Error to execute command az provider register -n Microsoft.Kubernetes"
    exit 171
fi

az provider register -n Microsoft.KubernetesConfiguration --wait
if [ $? -eq 0 ];then
    print_ts "Command az provider register -n Microsoft.KubernetesConfiguration OK"
else
    print_ts "Error to execute command az provider register -n Microsoft.KubernetesConfiguration"
    exit 171
fi

az provider register -n Microsoft.ExtendedLocation --wait
if [ $? -eq 0 ];then
    print_ts "Command az provider register -n Microsoft.ExtendedLocation - OK"
else
    print_ts "Error to execute command az provider register -n Microsoft.ExtendedLocation"
    exit 171
fi

#4 Add policy to SA
oc adm policy add-scc-to-user privileged system:serviceaccount:azure-arc:azure-arc-kube-aad-proxy-sa
if [ $? -eq 0 ];then
    print_ts "Command oc adm policy - OK"
else
    print_ts "Error to execute command oc adm policy"
    exit 171
fi

oc adm policy add-scc-to-user privileged system:serviceaccount:azure-arc:azure-arc-operatorsa
if [ $? -eq 0 ];then
    print_ts "Command oc adm policy - OK"
else
    print_ts "Error to execute command oc adm policy"
    exit 171
fi

sleep 60

#5 Add cluster on Defender
az connectedk8s connect --name {{ aro_cluster_name }} --resource-group rg{{ aro_environment }}defenderaro --location eastus --correlation-id c18ab9d0-685e-48e7-ab55-12588447b0ed --distribution openshift --infrastructure azure
if [ $? -eq 0 ];then
    print_ts "Command az connectedk8s connect - OK"
else
    print_ts "Error to execute command az connectedk8s connect"
    exit 171
fi
sleep 60


#6 Change deploy security 
oc patch deploy/extension-manager -p '{"spec":{"template":{"spec":{"containers":[{"name":"manager","securityContext":{"privileged":true,"allowPrivilegeEscalation":true,"readOnlyRootFilesystem":false,"runAsUser":0}}]}}}}' -n azure-arc
if [ $? -eq 0 ];then
    print_ts "Command oc patch deploy - OK"
else
    print_ts "Error to execute command oc patch deploy"
    exit 171
fi

az k8s-extension create --cluster-type connectedClusters --cluster-name {{ aro_cluster_name }} --resource-group rg{{ aro_environment }}defenderaro --extension-type Microsoft.PolicyInsights --name azurepolicy --version 1.5.0
if [ $? -eq 0 ];then
    print_ts "Command az k8s-extension create- OK"
else
    print_ts "Error to execute command az k8s-extension create"
    exit 171
fi

#7 Tags apply
#RESOURCEGROUP=$(az aro list --query "[?name==''{{ aro_cluster_name }}''].{resourceGroup:resourceGroup}" -o tsv)
az aro show --name {{ aro_cluster_name }} -g {{ aro_resource_group }} > /tmp/{{ aro_cluster_name }}.json
if [ $? -eq 0 ];then
    print_ts "Command az aro show  - OK"
else
    print_ts "Error to execute command az aro show "
    exit 171
fi

BO=$(cat /tmp/{{ aro_cluster_name }}.json | jq -r .tags.bo)
CENTRO_DE_CUSTO=$(cat /tmp/{{ aro_cluster_name }}.json | jq -r .tags.centro_de_custo)
COMPONENTE=$(cat /tmp/{{ aro_cluster_name }}.json | jq -r .tags.componente)
DEPARTAMENTO=$(cat /tmp/{{ aro_cluster_name }}.json | jq -r .tags.departamento)
EMPRESA=$(cat /tmp/{{ aro_cluster_name }}.json | jq -r .tags.empresa)
TO=$(cat /tmp/{{ aro_cluster_name }}.json | jq -r .tags.to)

RESOURCE_ID=/subscriptions/{{ aro_subscription_id }}/resourceGroups/rg{{ aro_environment }}defenderaro/providers/Microsoft.Kubernetes/connectedClusters/{{ aro_cluster_name }}

az tag create --resource-id $RESOURCE_ID --tags ambiente={{ aro_environment }} app=defender bo=$BO centro_de_custo=$CENTRO_DE_CUSTO componente=$COMPONENTE departamento=$DEPARTAMENTO empresa=$EMPRESA gerenciamento=vra to=$TO
if [ $? -eq 0 ];then
    print_ts "Command az tag create - OK"
else
    print_ts "Error to execute command az tag create"
    exit 171
fi

print_ts "FINISH - AZ ARO DEFENDER"
