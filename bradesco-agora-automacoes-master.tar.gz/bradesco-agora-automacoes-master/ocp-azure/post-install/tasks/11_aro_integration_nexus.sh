#!/bin/bash

PATH=$PATH:/root/openshift:/root/infracost

# 1- Download da pull-secret e gravar em um arquivo:
oc extract secret/pull-secret -n openshift-config --to=- > pull_secret_location.json
sleep 05
# 2- Editar o arquivo json incluindo as URLs do nexus e o usuário e senha em base64:
sed -i 's/}}}/},"nexusrepository.bradesco.com.br:8500":{"auth":"cHVzcm5leHVzZGV2c2Vjb3BzOnljb2FHT1E="}}}/' pull_secret_location.json
sed -i 's/}}}/},"nexusrepository.bradesco.com.br:8501":{"auth":"cHVzcm5leHVzZGV2c2Vjb3BzOnljb2FHT1E="}}}/' pull_secret_location.json
sed -i 's/}}}/},"nexusrepository.bradesco.com.br:8502":{"auth":"cHVzcm5leHVzZGV2c2Vjb3BzOnljb2FHT1E="}}}/' pull_secret_location.json
sed -i 's/}}}/},"nexusrepository.bradesco.com.br:8506":{"auth":"cHVzcm5leHVzZGV2c2Vjb3BzOnljb2FHT1E="}}}/' pull_secret_location.json
sed -i 's/}}}/},"cloud.openshift.com":{"auth":"b3BlbnNoaWZ0LXJlbGVhc2UtZGV2K29jbV9hY2Nlc3NfMGQ5ODUwMDkyMmRmNGZhNjhmZjllYTZiMDkzN2FhNzY6SVpVUkhFSUFUMExBTlkwVzU4UkgzTE1QV0haVjNQQkk2NVVUVkxaR0RIQTBLWDVNQTBUOTNPME1XNEFVN05BTg==","email":"ditieciscaas@bradesco.com.br"}}}/' pull_secret_location.json
sleep 05

# 3- Conferir o resultado:
cat pull_secret_location.json
sleep 05

# 4- Atualizar a pull-secret:
oc set data secret/pull-secret -n openshift-config --from-file=.dockerconfigjson=pull_secret_location.json
sleep 10

# 5- Criar o configmap:
oc create configmap registry-nexusrepository \
--from-file=nexusrepository.bradesco.com.br..8500=cloud-portal-squad-iac-openshift/Aro_posinstall/certs/cert-root-intermediario.crt \
--from-file=nexusrepository.bradesco.com.br..8501=cloud-portal-squad-iac-openshift/Aro_posinstall/certs/cert-root-intermediario.crt \
--from-file=nexusrepository.bradesco.com.br..8502=cloud-portal-squad-iac-openshift/Aro_posinstall/certs/cert-root-intermediario.crt \
--from-file=nexusrepository.bradesco.com.br..8506=cloud-portal-squad-iac-openshift/Aro_posinstall/certs/cert-root-intermediario.crt \
-n openshift-config
sleep 10

# 6- Para configurar o "allowedRegistries" e não impactar o openshift-samples
oc patch configs.samples.operator.openshift.io cluster --type merge --patch '{"spec": {"samplesRegistry":"registry.redhat.io"}}'

# 7- Incluir no spec as informações do registry:
oc patch image.config.openshift.io/cluster --type merge --patch '
spec:
  additionalTrustedCA:
    name: registry-nexusrepository
  registrySources:
    allowedRegistries:
    - quay.io
    - registry.connect.redhat.com
    - registry.access.redhat.com
    - registry.redhat.io
    - mcr.microsoft.com
    - nexusrepository.bradesco.com.br:8500
    - nexusrepository.bradesco.com.br:8501
    - nexusrepository.bradesco.com.br:8502
    - nexusrepository.bradesco.com.br:8506
    - image-registry.openshift-image-registry.svc:5000
    - arosvc.azurecr.io
    - arosvc.brazilsouth.data.azurecr.io'
