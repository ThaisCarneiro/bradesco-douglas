#!/bin/bash 

set -x
set +e

# Global variables
PATH=$PATH:/root/openshift:/root/infracost
export CLUSTER_NAME_GTW=`echo {{ aro_cluster_name }} |sed 's/..$//'`

# print with timestamp
print_ts () {
    echo "$(date +'%F %T.%N') [PID: $$] - $1"
}

if [ "{{ aro_environment }}" != "pr" ];then
    export PROBE_ROTALOCAL=probe-appgtw.apps.{{ aro_cluster_name }}.arocorpp.bradesco.com.br
else
    export PROBE_ROTALOCAL=probe-appgtw.apps.{{ aro_cluster_name }}.arocorp.bradesco.com.br
fi    

if [ "{{ aro_environment }}" != "pr" ];then
    export PROBE_ROTAGTW=probe-appgtw.apps.$CLUSTER_NAME_GTW.arocorpp.bradesco.com.br
else
    export PROBE_ROTAGTW=probe-appgtw.apps.$CLUSTER_NAME_GTW.arocorp.bradesco.com.br
fi 

echo 'Logging into cluster:';
oc login -u admin -p {{ aro_ocp_admin_password }} "{{ aro_cluster_api_url }}" --insecure-skip-tls-verify
if [ $? -eq 0 ];then
    print_ts "Login Cluster OK \n"
else
    print_ts "Falha ao logar no cluster \n"
    exit 171
fi

cat <<EOF | oc apply -f -
kind: ConfigMap
apiVersion: v1
metadata:
  name: probe-appgtw
  namespace: tools
data:
  index.html: PROBE APPLICATION GATEWAY APP {{ aro_cluster_name }}
  probe: PROBE APPLICATION GATEWAY APP {{ aro_cluster_name }}
---
kind: Deployment
apiVersion: apps/v1
metadata:
  name: probe-appgtw
  namespace: tools
spec:
  replicas: 3
  selector:
    matchLabels:
      app: probe-appgtw
  template:
    metadata:
      creationTimestamp: null
      labels:
        app: probe-appgtw
    spec:
      volumes:
        - name: probe-appgtw
          configMap:
            name: probe-appgtw
            defaultMode: 420
      containers:
        - name: probe-appgtw
          image: nexusrepository.bradesco.com.br:8502/aro/probe/ubi8/httpd-24:1-248
          ports:
            - containerPort: 8080
              protocol: TCP
          resources:
            limits:
              memory: 256Mi
            requests:
              cpu: 100m
              memory: 256Mi
          volumeMounts:
            - name: probe-appgtw
              readOnly: true
              mountPath: /var/www/html
          terminationMessagePath: /dev/termination-log
          terminationMessagePolicy: File
          imagePullPolicy: Always
      restartPolicy: Always
      terminationGracePeriodSeconds: 30
      dnsPolicy: ClusterFirst
      securityContext: {}
      schedulerName: default-scheduler
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 25%
      maxSurge: 25%
  revisionHistoryLimit: 10
  progressDeadlineSeconds: 600
---
kind: Service
apiVersion: v1
metadata:
  name: probe-appgtw
  namespace: tools
spec:
  ipFamilies:
    - IPv4
  ports:
    - protocol: TCP
      port: 443
      targetPort: 8080
  internalTrafficPolicy: Cluster
  type: ClusterIP
  ipFamilyPolicy: SingleStack
  sessionAffinity: None
  selector:
    app: probe-appgtw
---
kind: Route
apiVersion: route.openshift.io/v1
metadata:
  name: probe-appgtw-local
  namespace: tools
spec:
  host: ${PROBE_ROTALOCAL}
  to:
    kind: Service
    name: probe-appgtw
    weight: 100
  port:
    targetPort: 8080
  tls:
    termination: edge
    insecureEdgeTerminationPolicy: Allow
  wildcardPolicy: None
---
kind: Route
apiVersion: route.openshift.io/v1
metadata:
  name: probe-appgtw-master
  namespace: tools
spec:
  host: ${PROBE_ROTAGTW}
  to:
    kind: Service
    name: probe-appgtw
    weight: 100
  port:
    targetPort: 8080
  tls:
    termination: edge
    insecureEdgeTerminationPolicy: Allow
  wildcardPolicy: None
EOF
