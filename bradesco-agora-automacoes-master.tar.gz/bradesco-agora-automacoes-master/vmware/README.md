# VMware - Snapshot & Hardware

Neste repositório há duas playbooks:

- **snapshot** - Esta playbook é responsável por fazer um snapshot da máquina virtual.
- **hardware update** - Esta playbook é responsável por atualizar o hardware da máquina virtual.

## Snapshot

Para fazer o snapshot da máquina precisamos do nome da VM dentro do vCenter, como esta playbook faz parte de uma esteira o nome é um **FQDN** que será dividido por "." e utilizado apenas a primeira parte. Caso um FQDN não seja informado, a playbook continuará a funcionar.

O usuário utilizado para **autenticação** é o próprio usuário do Ansible.

### Variáveis

- `vm_fqdn` - uma string, o nome completo da máquina, embora não seja necessário - ex: `maquina.bradesco.local`;
- `vcenter_hostname` - uma string, o hostname/url do vcenter - ex: `vcenter.bradesco.local`.

O `datacenter` é definido com base em `vcenter_hostname`, se `vcenter.agorasenior.corp` será `MEC_OSASCO`, caso contrário `MEC_ALPHAVILLE`.

## Hardware Update

Para realizar o update do hardware da máquina virtual precisamos do nome da VM dentro do vCenter, como esta playbook faz parte de uma esteira o nome é um **FQDN** que será dividido por "." e utilizado apenas a primeira parte. Caso um FQDN não seja informado, a playbook continuará a funcionar.

O usuário utilizado para **autenticação** é o próprio usuário do Ansible.

Processo de atualização de hardware acontece após o desligamento limpo (soft) completo da máquina virtual. Inicialmente um pedido para atualização de hardware é criado e após isso a VM é desligada e iniciada.

### Variáveis

- `vm_fqdn` - uma string, o nome completo da máquina, embora não seja necessário - ex: `maquina.bradesco.local`;
- `vcenter_hostname` - uma string, o hostname/url do vcenter - ex: `vcenter.bradesco.local`.

Não é necessário definir um datacenter.
