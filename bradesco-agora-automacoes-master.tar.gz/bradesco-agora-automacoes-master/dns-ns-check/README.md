# DNS Nameserver Check

Esta playbook testa se todos os nameservers para o domínio **agorainvestimentos.com.br** está funcionando.
Caso um dos nameservers apresente um timeout, uma mensagem é enviada por email.

## Variáveis

Há uma variável utilizada para definir o DNS externo a ser utilizado:

- `dns` - um endereço IP, exemplo: `208.67.222.222`. 

## Dependências

Esta playbook depende de uma collection chamada `` e um módulo do python ``.

```bash
ansible-galaxy collection install community.dns
pip3 install dnspython
```

## Exemplo

```bash
ansible-navigator \
run playbook.yml \
--eei localhost/ee-supported-community \
-v
```
