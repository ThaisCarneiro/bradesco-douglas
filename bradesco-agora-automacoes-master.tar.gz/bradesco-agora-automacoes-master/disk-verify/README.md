# Verify Disks

Estas duas playbooks verificam os discos do Linux e do Windows e com base na variável `verify_disk_treshold` - de valor padrão 30 - gera artefatos para serem utilizados no próximo workflow do Automation Platform em um disparo de email.

Por padrão, a lógica pergunta se os discos possuem mais espaço livre do que 30%, caso não, os artefatos são gerados em uma variável chamada `send_mail_body`.

## Exemplos

```bash
ansible-playbook -i 127.0.0.1, \
  -e verify_disk_treshold=99 \
  -v verify_disk_linux.yml

ansible-playbook -i 192.168.122.103, \
  -e ansible_connection=winrm \
  -e ansible_user=Administrator \
  -e ansible_password=123 \
  -e ansible_winrm_transport=ntlm \
  -e ansible_port=5985 \
  -e verify_disk_treshold=99 \
  -v verify_disk_windows.yml
```
